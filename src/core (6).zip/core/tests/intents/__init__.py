"""
Tests for core intent definitions and boundary enforcement.
"""

