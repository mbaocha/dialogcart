"""
Rendering Layer Tests

Tests for rendering layer functionality:
- WhatsApp renderer tests
- Template tests
- WhatsApp channel tests
"""

