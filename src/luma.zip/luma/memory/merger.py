"""
Memory Merger

Implements merge logic for combining new input with existing memory state.
"""

from typing import Dict, Any, Optional
from datetime import datetime, timezone


def merge_booking_state(
    memory_state: Optional[Dict[str, Any]],
    current_intent: str,
    current_booking: Dict[str, Any],
    current_clarification: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Merge current input with memory state.
    
    Args:
        memory_state: Existing memory state (None if no memory)
        current_intent: Intent from current input
        current_booking: Booking state from current input (from calendar binding)
        current_clarification: Clarification from current input (if any)
        
    Returns:
        Merged memory state dict
    """
    # If intent changes, clear memory
    if memory_state and memory_state.get("intent") != current_intent:
        memory_state = None
    
    # Start with empty state if no memory
    if memory_state is None:
        merged_state = {
            "intent": current_intent,
            "booking_state": {
                "services": current_booking.get("services", []),
                "datetime_range": current_booking.get("datetime_range"),
                "duration": current_booking.get("duration")
            },
            "clarification": current_clarification,
            "last_updated": datetime.now(timezone.utc).isoformat()
        }
    else:
        # Merge onto existing memory
        merged_booking = _merge_booking_slots(
            memory_state.get("booking_state", {}),
            current_booking
        )
        
        # Handle clarification
        merged_clarification = _merge_clarification(
            memory_state.get("clarification"),
            current_clarification
        )
        
        merged_state = {
            "intent": current_intent,
            "booking_state": merged_booking,
            "clarification": merged_clarification,
            "last_updated": datetime.now(timezone.utc).isoformat()
        }
    
    return merged_state


def _merge_booking_slots(
    memory_booking: Dict[str, Any],
    current_booking: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Merge booking slots according to rules:
    
    SERVICES:
    - If services mentioned in input → REPLACE
    - Else → KEEP from memory
    
    DATETIME:
    - If input resolves datetime_range → REPLACE
    - If input partially resolves (date or time):
        - If memory has datetime_range → rebuild it
        - Else → require clarification (handled upstream)
    - If input mentions no temporal info → KEEP
    
    DURATION:
    - If mentioned → REPLACE
    - Else → KEEP
    """
    merged = {}
    
    # SERVICES: Replace if mentioned, else keep from memory
    current_services = current_booking.get("services", [])
    if current_services:
        merged["services"] = current_services
    else:
        merged["services"] = memory_booking.get("services", [])
    
    # DATETIME: Replace if fully resolved, else merge partial updates
    current_datetime_range = current_booking.get("datetime_range")
    memory_datetime_range = memory_booking.get("datetime_range")
    
    if current_datetime_range is not None:
        # Input fully resolved datetime → REPLACE
        merged["datetime_range"] = current_datetime_range
    elif memory_datetime_range is not None:
        # Input has no datetime, memory has one → KEEP
        merged["datetime_range"] = memory_datetime_range
    else:
        # Neither has datetime → None
        merged["datetime_range"] = None
    
    # DURATION: Replace if mentioned, else keep from memory
    current_duration = current_booking.get("duration")
    if current_duration is not None:
        merged["duration"] = current_duration
    else:
        merged["duration"] = memory_booking.get("duration")
    
    return merged


def _merge_clarification(
    memory_clarification: Optional[Dict[str, Any]],
    current_clarification: Optional[Dict[str, Any]]
) -> Optional[Dict[str, Any]]:
    """
    Merge clarification state.
    
    Rules:
    - If new clarification detected → REPLACE old
    - If existing clarification is resolved by input → CLEAR
    - Never store more than one clarification
    """
    # If current input has clarification, use it (replaces old)
    if current_clarification is not None:
        return current_clarification
    
    # If current input has no clarification but memory has one,
    # keep it (user hasn't resolved it yet)
    return memory_clarification


def extract_memory_state_for_response(
    memory_state: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Extract production-ready booking state from memory.
    
    Returns only the fields needed for the response:
    - services
    - datetime_range
    - duration
    """
    booking_state = memory_state.get("booking_state", {})
    return {
        "services": booking_state.get("services", []),
        "datetime_range": booking_state.get("datetime_range"),
        "duration": booking_state.get("duration")
    }

