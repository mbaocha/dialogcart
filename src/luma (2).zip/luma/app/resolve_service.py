"""
Service for resolving conversational input and resolving intent/state.

This module contains the core resolution logic extracted from api.py.
"""
import re
import time
from typing import Dict, Any, Optional, List
from datetime import datetime, timezone as dt_timezone

from flask import jsonify

from luma.calendar.calendar_binder import bind_calendar, bind_times, combine_datetime_range, get_timezone, get_booking_policy, CalendarBindingResult
from luma.pipeline import LumaPipeline
from luma.decision import decide_booking_status
from luma.memory.merger import merge_booking_state, extract_memory_state_for_response
from luma.memory.policy import (
    # Legacy functions (deprecated, kept for backward compatibility but not used)
    is_active_booking,
    is_partial_booking,
    maybe_persist_draft,
    should_clear_memory,
    should_persist_memory,
    prepare_memory_for_persistence,
    get_final_memory_state,
    # New state-first model functions
    state_exists,
    is_new_task,
    get_state_intent,
    merge_slots_for_followup
)
from luma.resolution.semantic_resolver import SemanticResolutionResult
from luma.perf import StageTimer
from luma.config.temporal import APPOINTMENT_TEMPORAL_TYPE, INTENT_TEMPORAL_SHAPE
from luma.trace_contract import validate_stable_fields


# CONTEXTUAL_UPDATE constant removed - no longer used in state-first model


def _normalize_service_canonical_to_display(canonical: str) -> str:
    """
    Convert canonical service ID to display name.
    
    Examples:
    - "beauty_and_wellness.beard_grooming" → "beard grooming"
    - "hospitality.suite" → "suite"
    - "hospitality.room" → "room"
    
    Args:
        canonical: Service canonical ID in format "category.service_name"
        
    Returns:
        Display name with underscores replaced by spaces and category prefix removed
    """
    if not canonical or "." not in canonical:
        return canonical
    
    # Split category.service_name
    parts = canonical.split(".", 1)
    if len(parts) == 2:
        service_name = parts[1]
        # Replace underscores with spaces
        display_name = service_name.replace("_", " ")
        return display_name
    
    return canonical


def _convert_time_ref_to_24h(time_text: str) -> Optional[str]:
    """
    Convert time text to 24-hour format (HH:MM), preserving am/pm semantics.
    Helper for Bug B: deriving time_constraint from time_refs.
    
    Examples:
    - "4pm" → "16:00"
    - "10am" → "10:00"
    - "12:30pm" → "12:30"
    - "14:00" → "14:00" (already 24-hour)
    """
    time_lower = time_text.lower().strip()
    
    # Check if already 24-hour format (HH:MM or HH.MM)
    if re.match(r'^([01]?[0-9]|2[0-3])[:.][0-5][0-9]$', time_text):
        # Already 24-hour, return as-is
        return time_text.replace('.', ':')
    
    # Extract hour, minutes, and meridiem
    match = re.match(r'^(\d{1,2})(?:[:.](\d{2}))?\s*(am|pm)?$', time_lower)
    if not match:
        return None
    
    hour = int(match.group(1))
    minutes = int(match.group(2)) if match.group(2) else 0
    meridiem = match.group(3)
    
    # Convert to 24-hour format
    if meridiem == "pm" and hour != 12:
        hour = hour + 12
    elif meridiem == "am" and hour == 12:
        hour = 0
    
    return f"{hour:02d}:{minutes:02d}"


def resolve_message(
    # Flask request globals
    g,
    request,
    
    # Module globals
    intent_resolver,
    memory_store,
    logger,
    
    # Constants
    APPOINTMENT_TEMPORAL_TYPE_CONST,
    INTENT_TEMPORAL_SHAPE_CONST,
    MEMORY_TTL,
    
    # Helper functions
    _merge_semantic_results,
    _localize_datetime,
    find_normalization_dir,
    _get_business_categories,
    _count_mutable_slots_modified,
    _has_booking_verb,
    validate_required_slots,
    _build_issues,
    _format_service_for_response,
    plan_clarification,
    _log_stage,
):
    """
    Process conversational input and resolve intent/state.
    
    This is the extracted body of the /resolve handler from api.py.
    All dependencies are passed as parameters.
    """
    request_id = g.request_id if hasattr(g, 'request_id') else 'unknown'
    booking_payload: Optional[Dict[str, Any]] = None
    calendar_booking: Dict[str, Any] = {}

    if intent_resolver is None:
        logger.error("Pipeline not initialized",
                     extra={'request_id': request_id})
        return jsonify({
            "success": False,
            "error": "Pipeline not initialized"
        }), 503

    # Parse request
    try:
        data = request.get_json()
        if not data:
            logger.warning("Missing request body", extra={
                           'request_id': request_id})
            return jsonify({
                "success": False,
                "error": "Missing request body"
            }), 400

        # Require user_id
        if "user_id" not in data:
            logger.warning("Missing 'user_id' parameter",
                           extra={'request_id': request_id})
            return jsonify({
                "success": False,
                "error": "Missing 'user_id' parameter in request body"
            }), 400

        user_id = data["user_id"]
        if not user_id or not isinstance(user_id, str):
            logger.warning("Invalid user_id parameter",
                           extra={'request_id': request_id})
            return jsonify({
                "success": False,
                "error": "'user_id' must be a non-empty string"
            }), 400

        if "text" not in data:
            logger.warning("Missing 'text' parameter",
                           extra={'request_id': request_id})
            return jsonify({
                "success": False,
                "error": "Missing 'text' parameter in request body"
            }), 400

        text = data["text"]
        domain = data.get("domain", "service")
        timezone = data.get("timezone", "UTC")
        # Optional tenant context with aliases
        tenant_context = data.get("tenant_context")

        # Log tenant_context for debugging
        if tenant_context:
            aliases_count = len(tenant_context.get("aliases", {})) if isinstance(
                tenant_context.get("aliases"), dict) else 0
            logger.info(
                f"Received tenant_context with {aliases_count} aliases",
                extra={'request_id': request_id,
                       'aliases_count': aliases_count}
            )

        if not text or not isinstance(text, str):
            logger.warning("Invalid text parameter", extra={
                           'request_id': request_id})
            return jsonify({
                "success": False,
                "error": "'text' must be a non-empty string"
            }), 400

        # Load memory state
        memory_state = None
        # Initialize execution_trace early for memory timing
        execution_trace = {"timings": {}}

        if memory_store:
            try:
                # Time memory read operation
                with StageTimer(execution_trace, "memory", request_id=request_id):
                    memory_state = memory_store.get(user_id, domain)
            except Exception as e:  # noqa: BLE001
                logger.warning(f"Failed to load memory: {e}", extra={
                               'request_id': request_id})

        # Removed per-stage logging - consolidated trace emitted at end

    except Exception as e:  # noqa: BLE001
        logger.error(
            f"Invalid request format: {str(e)}",
            extra={'request_id': request_id},
            exc_info=True
        )
        return jsonify({
            "success": False,
            "error": f"Invalid request format: {str(e)}"
        }), 400

    # Process conversational input
    try:
        start_time = time.perf_counter()

        # Find normalization directory
        normalization_dir = find_normalization_dir()
        if not normalization_dir:
            return jsonify({
                "success": False,
                "error": "Normalization directory not found"
            }), 500

        entity_file = str(normalization_dir / "101.v1.json")

        # Initialize now datetime
        now = datetime.now()
        now = _localize_datetime(now, timezone)

        results = {
            "input": {
                "sentence": text,
                "domain": domain,
                "timezone": timezone,
                "now": now.isoformat()
            },
            "stages": {}
        }

        # Execute pipeline to get execution_trace
        try:
            pipeline = LumaPipeline(
                domain=domain, entity_file=entity_file, intent_resolver=intent_resolver)
            booking_mode_for_pipeline = "service"
            if tenant_context and isinstance(tenant_context, dict):
                booking_mode_for_pipeline = tenant_context.get(
                    "booking_mode", "service") or "service"

            # Determine debug mode for pipeline contract validation
            debug_flag = str(request.args.get("debug", "0")).lower()
            pipeline_debug_mode = debug_flag in {"1", "true", "yes"}

            # Initialize execution_trace with timings dict for stage-level timing
            execution_trace = {"timings": {}}

            pipeline_results = pipeline.run(
                text=text,
                now=now,
                timezone=timezone,
                tenant_context=tenant_context,
                booking_mode=booking_mode_for_pipeline,
                request_id=request_id,
                debug_mode=pipeline_debug_mode
            )

            # Extract stage results and execution_trace from pipeline
            extraction_result = pipeline_results["stages"]["extraction"]
            intent_resp = pipeline_results["stages"]["intent"]
            structure_dict = pipeline_results["stages"]["structure"]
            grouped_result = pipeline_results["stages"]["grouping"]
            semantic_result = pipeline_results["stages"]["semantic"]
            # Merge pipeline's execution_trace into our trace (preserves timings)
            pipeline_trace = pipeline_results["execution_trace"]
            execution_trace.update(pipeline_trace)

            # Store stage results
            results["stages"]["extraction"] = extraction_result
            results["stages"]["intent"] = intent_resp
            results["stages"]["structure"] = structure_dict
            results["stages"]["grouping"] = grouped_result
            results["stages"]["semantic"] = semantic_result.to_dict()

            # Expose backward-compatible fields
            classifier_intent = intent_resp["intent"]
            confidence = intent_resp["confidence"]

            # NEW STATE-FIRST MODEL: Determine if this is a new task or follow-up
            state_exists_flag = state_exists(memory_state)
            is_new_task_flag = is_new_task(
                input_text=text,
                extraction_result=extraction_result,
                intent_result={"intent": classifier_intent, "confidence": confidence},
                state_exists_flag=state_exists_flag
            )
            
            # CRITICAL INVARIANT: UNKNOWN intent must NEVER start a new task when memory_state exists
            # This safeguard ensures memory is preserved for follow-ups even if is_new_task returns True
            if state_exists_flag and classifier_intent == "UNKNOWN":
                is_new_task_flag = False
                logger.debug(
                    f"Override: UNKNOWN intent with existing state treated as follow-up for user {user_id}",
                    extra={'request_id': request_id, 'classifier_intent': classifier_intent}
                )

            # Apply state-first behavior
            if is_new_task_flag:
                # New task: discard previous state, use classifier intent
                memory_state = None
                state_exists_flag = False
                intent = classifier_intent
                logger.debug(
                    f"New task detected for user {user_id}",
                    extra={'request_id': request_id, 'classifier_intent': classifier_intent}
                )
            else:
                # Follow-up: keep previous intent from state, classifier intent is advisory only
                state_intent = get_state_intent(memory_state)
                if state_intent:
                    intent = state_intent
                    logger.debug(
                        f"Follow-up detected for user {user_id}, using state intent: {intent}",
                        extra={'request_id': request_id, 'classifier_intent': classifier_intent, 'state_intent': intent}
                    )
                else:
                    # State exists but intent field is missing (e.g., legacy memory)
                    # Treat as continuation of active booking task, infer intent from domain
                    intent = "CREATE_BOOKING"  # Normalized internal intent for active booking
                    logger.debug(
                        f"Follow-up detected but state intent is None for user {user_id}, inferring CREATE_BOOKING from domain",
                        extra={'request_id': request_id, 'classifier_intent': classifier_intent, 'domain': domain, 'inferred_intent': intent}
                    )

            # Determine external_intent for decision layer
            # If intent is CREATE_BOOKING (normalized), infer external_intent from domain
            external_intent = intent
            if intent == "CREATE_BOOKING":
                # Infer external_intent from domain for follow-ups
                if domain == "service":
                    external_intent = "CREATE_APPOINTMENT"
                elif domain == "reservation":
                    external_intent = "CREATE_RESERVATION"
                else:
                    # Fallback: use domain as-is (shouldn't happen normally)
                    external_intent = intent
            elif intent in {"CREATE_APPOINTMENT", "CREATE_RESERVATION"}:
                external_intent = intent
                intent = "CREATE_BOOKING"  # Normalize for internal use
            
            # Store external_intent in results for decision layer and response
            # Always store it if it's one of the external intents, otherwise store None explicitly
            if external_intent in {"CREATE_APPOINTMENT", "CREATE_RESERVATION"}:
                results["stages"]["intent"]["external_intent"] = external_intent
            else:
                # Clear it if not valid (shouldn't happen, but be explicit)
                results["stages"]["intent"]["external_intent"] = None
            
            # Store state-first model decision in results for debugging
            results["stages"]["intent"]["state_first"] = {
                "is_new_task": is_new_task_flag,
                "state_exists": state_exists_flag,
                "classifier_intent": classifier_intent,
                "effective_intent": intent
            }

        except Exception as e:
            # Fallback to individual stage execution on pipeline error
            logger.error(f"Pipeline execution failed: {e}", extra={
                         'request_id': request_id}, exc_info=True)
            results["stages"]["extraction"] = {"error": str(e)}
            return jsonify({"success": False, "data": results}), 500

        # Fix 1: Infer reservation service from nouns if missing
        # For reservations, if services are empty, infer from reservation nouns in text
        if (domain == "reservation" and semantic_result and 
            (not semantic_result.resolved_booking.get("services") or 
             len(semantic_result.resolved_booking.get("services", [])) == 0)):
            # Check for common reservation nouns: suite, room, deluxe room, etc.
            text_lower = text.lower()
            reservation_nouns = {
                "deluxe room": {"text": "deluxe room", "canonical": "hospitality.room"},
                "standard room": {"text": "standard room", "canonical": "hospitality.room"},
                "suite": {"text": "suite", "canonical": "hospitality.suite"},
                "room": {"text": "room", "canonical": "hospitality.room"}
            }
            # Check in order (longest first to match "deluxe room" before "room")
            for noun_phrase, service_dict in sorted(reservation_nouns.items(), key=lambda x: len(x[0]), reverse=True):
                if noun_phrase in text_lower:
                    # Infer service from reservation noun
                    resolved_booking = semantic_result.resolved_booking.copy()
                    resolved_booking["services"] = [service_dict]
                    # Update semantic_result with inferred service
                    semantic_result = SemanticResolutionResult(
                        resolved_booking=resolved_booking,
                        needs_clarification=semantic_result.needs_clarification,
                        clarification=semantic_result.clarification
                    )
                    logger.debug(
                        f"Inferred reservation service '{noun_phrase}' from text for user {user_id}",
                        extra={'request_id': request_id, 'inferred_service': noun_phrase}
                    )
                    break
        
        # NEW STATE-FIRST MODEL: Semantic result handling
        # For follow-ups, merge semantic slots BEFORE decision layer
        # This ensures decision/completeness checking sees the merged state
        if not is_new_task_flag and memory_state and semantic_result:
            # Merge slots from memory into current semantic result BEFORE decision
            current_resolved_booking = semantic_result.resolved_booking or {}
            
            # Check for semantic fields in memory (preferred source)
            memory_semantic_booking = memory_state.get("resolved_booking_semantics", {})
            memory_booking_state = memory_state.get("booking_state", {})
            
            # Merge at semantic level (services, date_refs, time_refs, duration)
            merged_resolved_booking = current_resolved_booking.copy()
            
            # SERVICES: Replace if mentioned in current, else keep from memory
            current_services = current_resolved_booking.get("services", [])
            if not current_services:
                # Prefer semantic booking, fallback to booking_state
                memory_services = memory_semantic_booking.get("services") or memory_booking_state.get("services", [])
                if memory_services:
                    merged_resolved_booking["services"] = memory_services
            
            # DATE_REFS: Replace if current has date_refs, else keep from memory
            current_date_refs = current_resolved_booking.get("date_refs", [])
            memory_date_refs = memory_semantic_booking.get("date_refs", [])
            memory_date_mode = memory_semantic_booking.get("date_mode")
            
            # Bug A: For reservations, detect directional language ("to", "until", "through") 
            # and merge single_day dates into a range
            if (current_date_refs and memory_date_refs and 
                memory_date_mode == "single_day" and len(memory_date_refs) == 1):
                # Check if input text contains directional language indicating end date
                # Handle both start-of-string cases ("to october 9th") and middle cases ("from X to Y")
                text_lower = text.lower()
                directional_markers = ["to ", "until ", "through ", "thru ", "till "]
                has_directional_marker = (
                    any(text_lower.startswith(marker) for marker in directional_markers) or
                    any(f" {marker}" in text_lower for marker in directional_markers)
                )
                
                # Check if intent is reservation (requires date_range)
                # Use domain to infer intent if external_intent not yet available
                is_reservation = (domain == "reservation" or 
                                  intent == "CREATE_RESERVATION" or
                                  (results.get("stages", {}).get("intent", {}).get("external_intent") == "CREATE_RESERVATION"))
                
                if has_directional_marker and is_reservation and len(current_date_refs) == 1:
                    # Merge: memory date_ref → start, current date_ref → end, mode → range
                    merged_resolved_booking["date_refs"] = memory_date_refs + current_date_refs
                    merged_resolved_booking["date_mode"] = "range"
                else:
                    # Default behavior: replace if current has date_refs (preserve current date_mode from semantic result)
                    merged_resolved_booking["date_refs"] = current_date_refs
                    # Preserve date_mode from current semantic result if available
                    current_date_mode = current_resolved_booking.get("date_mode")
                    if current_date_mode:
                        merged_resolved_booking["date_mode"] = current_date_mode
            elif not current_date_refs:
                # No current date_refs: keep from memory
                if memory_date_refs:
                    merged_resolved_booking["date_refs"] = memory_date_refs
                    if memory_date_mode:
                        merged_resolved_booking["date_mode"] = memory_date_mode
            else:
                # Current has date_refs: replace (default behavior)
                merged_resolved_booking["date_refs"] = current_date_refs
                # date_mode should already be preserved from current_resolved_booking.copy() above
                # but explicitly ensure it's set if present
                current_date_mode = current_resolved_booking.get("date_mode")
                if current_date_mode:
                    merged_resolved_booking["date_mode"] = current_date_mode
            
            # TIME_REFS: Replace if current has time_refs, else keep from memory
            current_time_refs = current_resolved_booking.get("time_refs", [])
            if not current_time_refs:
                memory_time_refs = memory_semantic_booking.get("time_refs", [])
                if memory_time_refs:
                    merged_resolved_booking["time_refs"] = memory_time_refs
                    # Also preserve time_mode if available
                    memory_time_mode = memory_semantic_booking.get("time_mode")
                    if memory_time_mode:
                        merged_resolved_booking["time_mode"] = memory_time_mode
            
            # Bug B: TIME_CONSTRAINT: Merge from memory if current doesn't have it
            # The binder needs time_constraint to build time_range/datetime_range
            current_time_constraint = current_resolved_booking.get("time_constraint")
            if not current_time_constraint:
                memory_time_constraint = memory_semantic_booking.get("time_constraint")
                if memory_time_constraint:
                    merged_resolved_booking["time_constraint"] = memory_time_constraint
            
            # Bug B: If time_refs exist but time_constraint is still missing, derive it
            # This handles cases where time_constraint wasn't stored in memory but time_refs were
            if (not merged_resolved_booking.get("time_constraint") and 
                merged_resolved_booking.get("time_refs") and 
                merged_resolved_booking.get("time_mode") == "exact"):
                # Derive time_constraint from time_refs using simple conversion
                time_ref = merged_resolved_booking["time_refs"][0]
                time_24h = _convert_time_ref_to_24h(str(time_ref))
                if time_24h:
                    merged_resolved_booking["time_constraint"] = {
                        "mode": "exact",
                        "start": time_24h,
                        "end": time_24h,
                        "label": None
                    }
            
            # DURATION: Replace if mentioned, else keep from memory
            current_duration = current_resolved_booking.get("duration")
            if current_duration is None:
                memory_duration = memory_semantic_booking.get("duration") or memory_booking_state.get("duration")
                if memory_duration is not None:
                    merged_resolved_booking["duration"] = memory_duration
            
            # Create merged semantic result
            merged_semantic_result = SemanticResolutionResult(
                resolved_booking=merged_resolved_booking,
                needs_clarification=semantic_result.needs_clarification,
                clarification=semantic_result.clarification
            )
            
            logger.debug(
                f"Merged semantic slots for follow-up (before decision) for user {user_id}",
                extra={
                    'request_id': request_id,
                    'merged_keys': list(merged_resolved_booking.keys()),
                    'has_services': bool(merged_resolved_booking.get("services")),
                    'has_date_refs': bool(merged_resolved_booking.get("date_refs")),
                    'has_time_refs': bool(merged_resolved_booking.get("time_refs"))
                }
            )
        else:
            # New task: use current semantic result as-is
            merged_semantic_result = semantic_result
        
        # OLD CONTINUATION LOGIC REMOVED - replaced by state-first model
        # All contextual update detection logic removed (handled by slot merge before decision)

        # Decision / Policy Layer - ACTIVE
        # Decision layer determines if clarification is needed BEFORE calendar binding
        # Policy operates ONLY on semantic roles, never on raw text or regex
        decision_result = None
        # Initialize semantic_for_decision before try block to ensure it's always defined
        semantic_for_decision = merged_semantic_result.resolved_booking if merged_semantic_result else {}
        
        try:
            # Load booking policy from config
            booking_policy = get_booking_policy()

            # OLD CONTINUATION LOGIC REMOVED - replaced by state-first model
            # The old contextual update detection logic has been removed.
            # Slot merging now happens after calendar binding via merge_slots_for_followup()

            # CRITICAL INVARIANT: decision must see fully merged semantics
            # If there is an active booking, the semantic object passed to decision
            # MUST be the merged semantic booking, not the current fragment
            # Attach booking_mode for decision policy (service vs reservation)
            if isinstance(semantic_for_decision, dict):
                semantic_for_decision["booking_mode"] = domain

            # Get intent_name for temporal shape validation
            # Use external_intent if available (CREATE_APPOINTMENT/CREATE_RESERVATION),
            # otherwise use normalized intent
            intent_name_for_decision = results["stages"]["intent"].get(
                "external_intent"
            ) or intent

            # Time decision re-run (with merged semantic result)
            with StageTimer(execution_trace, "decision", request_id=request_id):
                decision_result, decision_trace = decide_booking_status(
                    semantic_for_decision,
                    entities=extraction_result,
                    policy=booking_policy,
                    intent_name=intent_name_for_decision
                )

            # Store decision result in results
            results["stages"]["decision"] = {
                "status": decision_result.status,
                "reason": decision_result.reason,
                "effective_time": decision_result.effective_time
            }
            # Update execution_trace with decision trace (overwrites pipeline's trace with merged semantic result)
            execution_trace.update(decision_trace)

            # Fail fast guardrail: If temporal_shape == datetime_range and missing slots, ensure binder is skipped
            expected_shape = decision_trace.get(
                "decision", {}).get("expected_temporal_shape")
            if expected_shape == APPOINTMENT_TEMPORAL_TYPE_CONST:
                missing = decision_trace.get(
                    "decision", {}).get("missing_slots", [])
                if missing and decision_result.status == "RESOLVED":
                    # This is an invariant violation - should not happen
                    # Force NEEDS_CLARIFICATION
                    decision_result.status = "NEEDS_CLARIFICATION"
                    decision_result.reason = "temporal_shape_not_satisfied"
                    execution_trace["decision"]["state"] = "NEEDS_CLARIFICATION"
                    execution_trace["decision"]["reason"] = "temporal_shape_not_satisfied"
                    execution_trace["decision"]["temporal_shape_satisfied"] = False
                    execution_trace["decision"]["rule_enforced"] = "temporal_shape_guardrail"
                    execution_trace["decision"]["missing_slots"] = missing

            # Decision is RESOLVED - proceed to calendar binding unconditionally
            # Calendar binding will assume inputs are already approved

        except Exception as e:  # noqa: BLE001
            # Decision layer failure should not block - log and continue
            logger.error(
                f"[DECISION] Decision layer failed: {e}",
                extra={'request_id': request_id},
                exc_info=True
            )
            results["stages"]["decision"] = {"error": str(e)}
            # Continue to calendar binding on error (fallback behavior)

        # NEW STATE-FIRST MODEL: Effective intent is just the intent we determined
        # OLD CONTEXTUAL_UPDATE logic bypassed (kept for reference but not used in state-first model)
        effective_intent = intent
        
        # OLD LOGIC (bypassed):
        # effective_intent = detect_contextual_update(...)

        # Stage 6: Required slots validation (before calendar binding)
        intent_name_for_slots_raw = intent or effective_intent
        intent_name_for_slots = intent_name_for_slots_raw.get("name") if isinstance(
            intent_name_for_slots_raw, dict) else intent_name_for_slots_raw
        missing_required = []
        if intent_name_for_slots:
            missing_required = validate_required_slots(
                intent_name_for_slots,
                merged_semantic_result.resolved_booking if merged_semantic_result else {},
                extraction_result or {}
            )
        skip_prebind = (
            intent_name_for_slots == "CREATE_APPOINTMENT"
            and missing_required == ["time"]
        )
        if missing_required and not skip_prebind:
            results["stages"]["intent"]["status"] = "needs_clarification"
            results["stages"]["intent"]["missing_slots"] = missing_required
            calendar_result = CalendarBindingResult(
                calendar_booking={},
                needs_clarification=False,
                clarification=None
            )
            results["stages"]["calendar"] = calendar_result.to_dict()
        else:
            # Stage 6: Calendar Binding
            # MANDATORY: Calendar binding only runs when decision_state == RESOLVED
            # EXCEPTION: Also allow binding when date is present but time is missing
            # (to provide bound date in clarification context)
            # The decision layer enforces temporal shape completeness, so RESOLVED
            # guarantees that temporal shape requirements are satisfied
            has_date = (merged_semantic_result and
                        merged_semantic_result.resolved_booking.get("date_refs"))
            # Get missing slots from decision trace if available (added at line 1384)
            decision_missing_slots = execution_trace.get("decision", {}).get(
                "missing_slots", []) if execution_trace else []
            missing_only_time = (decision_result and
                                 decision_result.status == "NEEDS_CLARIFICATION" and
                                 decision_result.reason == "temporal_shape_not_satisfied" and
                                 len(decision_missing_slots) == 1 and
                                 decision_missing_slots == ["time"] and
                                 has_date)

            if decision_result and (decision_result.status == "RESOLVED" or missing_only_time):
                # Proceed with calendar binding
                # Use effective_intent for calendar binding (CONTEXTUAL_UPDATE treated as CREATE_BOOKING)
                # Use merged semantic result if this was a PARTIAL continuation
                binding_intent = effective_intent  # CONTEXTUAL_UPDATE logic removed (dead code)
                # Get external_intent for reservation handling (CREATE_RESERVATION vs CREATE_APPOINTMENT)
                external_intent = results["stages"]["intent"].get(
                    "external_intent")
                try:
                    # BINDER layer: Structured DEBUG log (before binding)
                    # Legacy log - downgraded to DEBUG as part of logging refactor
                    reason_str = 'decision=RESOLVED' if decision_result.status == "RESOLVED" else 'decision=NEEDS_CLARIFICATION (date-only binding)'
                    logger.debug(
                        "BINDER_GATE",
                        extra={
                            'request_id': request_id,
                            'run': True,
                            'reason': reason_str
                        }
                    )
                    # Time calendar binding re-run (with merged semantic result)
                    with StageTimer(execution_trace, "binder", request_id=request_id):
                        calendar_result, binder_trace = bind_calendar(
                            merged_semantic_result,
                            now,
                            timezone,
                            intent=binding_intent,
                            entities=extraction_result,
                            external_intent=external_intent
                        )
                    results["stages"]["calendar"] = calendar_result.to_dict()
                    # Update execution_trace with binder trace (overwrites pipeline's trace with merged semantic result)
                    execution_trace.update(binder_trace)
                except Exception as e:
                    results["stages"]["calendar"] = {"error": str(e)}
                    # Build binder input for error trace
                    semantic_for_binder = merged_semantic_result.resolved_booking if merged_semantic_result else semantic_result.resolved_booking
                    temporal_shape_for_trace = INTENT_TEMPORAL_SHAPE_CONST.get(
                        external_intent) if external_intent else None
                    execution_trace["binder"] = {
                        "called": False,
                        "input": {
                            "intent": binding_intent,
                            "external_intent": external_intent,
                            "temporal_shape": temporal_shape_for_trace,
                            "date_mode": semantic_for_binder.get("date_mode", "none"),
                            "date_refs": semantic_for_binder.get("date_refs", []),
                            "time_mode": semantic_for_binder.get("time_mode", "none"),
                            "time_refs": semantic_for_binder.get("time_refs", []),
                            "time_constraint": semantic_for_binder.get("time_constraint"),
                            "timezone": timezone
                        },
                        "output": {},
                        "decision_reason": f"exception: {str(e)}"
                    }
                    # Create empty calendar_result for consistency (even though we return early)
                    calendar_result = CalendarBindingResult(
                        calendar_booking={},
                        needs_clarification=False,
                        clarification=None
                    )
                    return jsonify({"success": False, "data": results}), 500
            else:
                # decision_state != RESOLVED - skip calendar binding
                # Temporal shape incomplete or other clarification needed
                reason = f"decision={decision_result.status if decision_result else 'NONE'}"
                calendar_result = CalendarBindingResult(
                    calendar_booking={},
                    needs_clarification=False,
                    clarification=None
                )
                results["stages"]["calendar"] = calendar_result.to_dict()
                # Binder was skipped - add trace with input even though not called
                semantic_for_binder = merged_semantic_result.resolved_booking if merged_semantic_result else semantic_result.resolved_booking
                external_intent_for_trace = results["stages"]["intent"].get(
                    "external_intent") or intent
                temporal_shape_for_trace = INTENT_TEMPORAL_SHAPE_CONST.get(
                    external_intent_for_trace) if external_intent_for_trace else None
                execution_trace["binder"] = {
                    "called": False,
                    "input": {
                        "intent": intent,
                        "external_intent": external_intent_for_trace,
                        "temporal_shape": temporal_shape_for_trace,
                        "date_mode": semantic_for_binder.get("date_mode", "none"),
                        "date_refs": semantic_for_binder.get("date_refs", []),
                        "time_mode": semantic_for_binder.get("time_mode", "none"),
                        "time_refs": semantic_for_binder.get("time_refs", []),
                        "time_constraint": semantic_for_binder.get("time_constraint"),
                        "timezone": timezone
                    },
                    "output": {},
                    "decision_reason": reason
                }

        # Determine debug mode (query param debug=1|true|yes)
        debug_flag = str(request.args.get("debug", "0")).lower()
        debug_mode = debug_flag in {"1", "true", "yes"}

        # Extract current booking state from calendar result
        calendar_dict = calendar_result.to_dict()
        calendar_booking = calendar_dict.get(
            "calendar_booking", {}) if calendar_dict else {}
        cal_clar_dict = calendar_dict.get(
            "clarification") if calendar_dict else None
        cal_needs_clarification = bool(calendar_dict.get(
            "needs_clarification")) if calendar_dict else False

        # Clarification planning (YAML-driven + semantic/calendar)
        intent_resp = results["stages"]["intent"]
        intent_name = intent_resp.get("name") if isinstance(
            intent_resp, dict) else intent_resp or intent
        clar = plan_clarification(
            intent_resp, extraction_result, merged_semantic_result, decision_result)

        # If calendar needs clarification and none set yet, use calendar clarification
        if cal_needs_clarification and clar.get("status") != "needs_clarification":
            clar["status"] = "needs_clarification"
            # Extract reason from calendar clarification
            cal_reason = cal_clar_dict.get("reason") if isinstance(
                cal_clar_dict, dict) else None
            if cal_reason:
                if isinstance(cal_reason, str):
                    clar["clarification_reason"] = cal_reason
                elif hasattr(cal_reason, "value"):
                    clar["clarification_reason"] = cal_reason.value

        needs_clarification = clar.get("status") == "needs_clarification"
        missing_slots = clar.get("missing_slots", [])
        clarification_reason = clar.get("clarification_reason")
        
        # If missing_slots not set in clarification, use decision trace as fallback
        if not missing_slots and execution_trace:
            decision_trace = execution_trace.get("decision", {})
            if decision_trace and isinstance(decision_trace, dict):
                decision_missing = decision_trace.get("missing_slots", [])
                if decision_missing:
                    missing_slots = decision_missing

        # Override clarification based on decision_result for time constraints
        # Accept exact/window time constraints for appointments; fuzzy requires clarification
        tc = semantic_for_decision.get(
            "time_constraint") if semantic_for_decision else None
        tc_mode = tc.get("mode") if isinstance(tc, dict) else None

        # Enforce required slots from intent metadata (authoritative)
        resolved_snapshot: Dict[str, Any] = {}
        # Prefer booking_payload for ready/partial responses
        if booking_payload:
            resolved_snapshot.update(booking_payload)
        # Overlay calendar booking fields if present
        if calendar_booking:
            resolved_snapshot.update(calendar_booking)
        # Overlay semantic resolved booking as fallback
        if merged_semantic_result and merged_semantic_result.resolved_booking:
            resolved_snapshot.setdefault(
                "date_refs", merged_semantic_result.resolved_booking.get("date_refs"))
            resolved_snapshot.setdefault(
                "time_refs", merged_semantic_result.resolved_booking.get("time_refs"))
            resolved_snapshot.setdefault(
                "services", merged_semantic_result.resolved_booking.get("services"))

        if intent_name:
            enforced_missing = validate_required_slots(
                intent_name, resolved_snapshot, extraction_result or {})
            
            if enforced_missing:
                needs_clarification = True
                missing_slots = enforced_missing
                # Update clarification_reason based on missing slots
                if not clarification_reason:
                    if "time" in enforced_missing:
                        clarification_reason = "MISSING_TIME"
                    elif "date" in enforced_missing:
                        clarification_reason = "MISSING_DATE"
                    elif "service_id" in enforced_missing or "service" in enforced_missing:
                        clarification_reason = "MISSING_SERVICE"
                booking_payload = None
        # Temporal shape enforcement (authoritative, post-binding)
        if intent_name and intent_name in INTENT_TEMPORAL_SHAPE_CONST:
            shape = INTENT_TEMPORAL_SHAPE_CONST.get(intent_name)
            if shape == APPOINTMENT_TEMPORAL_TYPE_CONST:
                has_dtr = bool((calendar_booking or {}).get("datetime_range"))
                if not has_dtr:
                    temporal_missing: List[str] = []
                    date_refs = merged_semantic_result.resolved_booking.get(
                        "date_refs") if merged_semantic_result else []
                    if date_refs:
                        temporal_missing = ["time"]
                    else:
                        temporal_missing = ["date", "time"]
                    if temporal_missing:
                        needs_clarification = True
                        missing_slots = temporal_missing
                        # Update clarification_reason based on missing slots
                        if not clarification_reason:
                            if "time" in temporal_missing:
                                clarification_reason = "MISSING_TIME"
                            elif "date" in temporal_missing:
                                clarification_reason = "MISSING_DATE"
                            elif len(temporal_missing) >= 2:
                                clarification_reason = "MISSING_TIME"  # Default to time if both missing
                        booking_payload = None
                        response_body_status = "needs_clarification"

        # Extract current clarification
        # Priority: semantic clarification > calendar binding clarification > decision layer
        # CRITICAL: Semantic clarifications (e.g., SERVICE_VARIANT) must be preserved
        # even if decision layer says RESOLVED (due to invariant override)
        current_clarification = None

        # First priority: Check semantic resolution clarification (e.g., SERVICE_VARIANT ambiguity)
        if merged_semantic_result and merged_semantic_result.needs_clarification and merged_semantic_result.clarification:
            # Semantic resolution detected ambiguity (e.g., service variant ambiguity)
            # This must be preserved even if decision layer says RESOLVED
            current_clarification = merged_semantic_result.clarification.to_dict()
            logger.info(
                f"Preserving semantic clarification: {current_clarification.get('reason')}",
                extra={'request_id': request_id,
                       'clarification_reason': current_clarification.get('reason')}
            )
        elif decision_result and decision_result.status == "RESOLVED":
            # Decision is RESOLVED - no clarification needed
            # This clears any existing PARTIAL clarification from memory
            current_clarification = None
        elif calendar_result.needs_clarification and calendar_result.clarification:
            # Only validation errors from calendar binding (range conflicts, etc.)
            current_clarification = calendar_result.clarification.to_dict()

        # Prepare current booking state (only canonical fields)
        # Include date_range and time_range for merge logic to handle time-only updates
        # Format services to preserve resolved_alias if present
        calendar_services = calendar_booking.get("services", [])
        formatted_services = [
            _format_service_for_response(service)
            for service in calendar_services
            if isinstance(service, dict)
        ] if calendar_services else []

        current_booking = {
            "services": formatted_services,
            "datetime_range": calendar_booking.get("datetime_range"),
            "date_range": calendar_booking.get("date_range"),
            "time_range": calendar_booking.get("time_range"),
            "duration": calendar_booking.get("duration")
        }

        # NEW STATE-FIRST MODEL: Merge slots for follow-ups (after calendar binding)
        # For follow-ups, merge current_booking with memory booking state
        # New slot value replaces old, missing slot keeps old
        if not is_new_task_flag and memory_state and memory_state.get("booking_state"):
            memory_booking_state = memory_state.get("booking_state", {})
            if isinstance(memory_booking_state, dict):
                merged_booking = merge_slots_for_followup(
                    memory_booking=memory_booking_state,
                    current_booking=current_booking
                )
                current_booking = merged_booking
                logger.debug(
                    f"Merged slots for follow-up for user {user_id}",
                    extra={'request_id': request_id, 'merged_booking_keys': list(merged_booking.keys())}
                )

        # OLD CONTEXTUAL_UPDATE logic removed - this is handled by merge_slots_for_followup in the new state-first model
        # This entire block has been removed as part of the cleanup of obsolete continuation logic

        # Memory clearing and persistence decisions delegated to memory policy
        should_clear = should_clear_memory(effective_intent)
        if should_clear and memory_store:
            try:
                memory_store.clear(user_id, domain)
                logger.info(f"Cleared memory for {user_id} due to intent: {effective_intent}", extra={
                            'request_id': request_id})
            except Exception as e:  # noqa: BLE001
                logger.warning(f"Failed to clear memory: {e}", extra={
                               'request_id': request_id})

        # Determine if and how memory should be persisted
        should_persist, is_booking_intent, is_modify_with_booking_id, persist_intent = should_persist_memory(
            effective_intent=effective_intent,
            data=data,
            should_clear=should_clear
        )

        merged_memory = None
        if should_persist and is_booking_intent:
            # Prepare memory for persistence (handles RESOLVED vs PARTIAL logic)
            merged_memory = prepare_memory_for_persistence(
                memory_state=memory_state,
                decision_result=decision_result,
                persist_intent=persist_intent,
                current_booking=current_booking,
                current_clarification=current_clarification,
                merged_semantic_result=merged_semantic_result,
                logger=logger,
                user_id=user_id,
                request_id=request_id
            )

            # Persist merged state with CREATE_BOOKING intent
            # Only persist if we have a valid booking state (RESOLVED or PARTIAL)
            if memory_store:
                try:
                    # Time memory write operation
                    with StageTimer(execution_trace, "memory", request_id=request_id):
                        memory_store.set(
                            user_id=user_id,
                            domain=domain,
                            state=merged_memory,
                            ttl=MEMORY_TTL
                        )

                    # Stage 8: STATE PERSIST - Log what was stored
                    storage_backend = "redis" if hasattr(
                        memory_store, 'redis') else "memory"
                    _log_stage(
                        logger, request_id, "state_persist",
                        input_data={"user_id": user_id, "domain": domain},
                        output_data={
                            "stored": {
                                "intent": merged_memory.get("intent"),
                                "booking_state": merged_memory.get("booking_state", {}).get("booking_state") if isinstance(merged_memory.get("booking_state"), dict) else None,
                                "has_services": bool(merged_memory.get("booking_state", {}).get("services") if isinstance(merged_memory.get("booking_state"), dict) else False),
                                "has_datetime_range": bool(merged_memory.get("booking_state", {}).get("datetime_range") if isinstance(merged_memory.get("booking_state"), dict) else False)
                            },
                            "storage_backend": storage_backend
                        }
                    )
                except Exception as e:  # noqa: BLE001
                    logger.warning(f"Failed to persist memory: {e}", extra={
                                   'request_id': request_id})
        elif should_persist and is_modify_with_booking_id:
            # MODIFY_BOOKING with booking_id: persist as MODIFY_BOOKING
            merged_memory = merge_booking_state(
                memory_state=None,  # Don't merge with CREATE_BOOKING draft
                current_intent="MODIFY_BOOKING",
                current_booking=current_booking,
                current_clarification=current_clarification
            )

            # Persist MODIFY_BOOKING state
            if memory_store:
                try:
                    # Time memory write operation
                    with StageTimer(execution_trace, "memory", request_id=request_id):
                        memory_store.set(
                            user_id=user_id,
                            domain=domain,
                            state=merged_memory,
                            ttl=MEMORY_TTL
                        )
                except Exception as e:  # noqa: BLE001
                    logger.warning(f"Failed to persist memory: {e}", extra={
                                   'request_id': request_id})

        # Get final memory state based on all decisions
        merged_memory = get_final_memory_state(
            should_clear=should_clear,
            should_persist=should_persist,
            is_booking_intent=is_booking_intent,
            is_modify_with_booking_id=is_modify_with_booking_id,
            effective_intent=effective_intent,
            memory_state=memory_state,
            current_booking=current_booking,
            current_clarification=current_clarification,
            merged_memory=merged_memory,
            logger=logger,
            request_id=request_id
        )

        # Post-semantic validation guard: Check for orphan slot updates
        # If extracted slots exist but cannot be applied (no booking_id, no draft, no booking),
        # return clarification instead of "successful" empty response
        # Build production response
        # Map CONTEXTUAL_UPDATE to CREATE_BOOKING in API response
        api_intent = effective_intent  # CONTEXTUAL_UPDATE logic removed (dead code)
        # Get external_intent from results (set earlier for decision layer)
        external_intent_for_response = results["stages"]["intent"].get("external_intent")
        intent_payload_name = external_intent_for_response if external_intent_for_response in {
            "CREATE_APPOINTMENT", "CREATE_RESERVATION"} else api_intent
        intent_payload = {"name": intent_payload_name,
                          "confidence": confidence}

        # Clarification fields from plan_clarification / calendar
        # Return booking state for CREATE_BOOKING or MODIFY_BOOKING
        # CRITICAL: For CREATE_BOOKING, booking must NEVER be null, even when clarification is needed
        booking_payload = None
        context_payload = None

        if (is_booking_intent or is_modify_with_booking_id) and not needs_clarification:
            booking_payload = extract_memory_state_for_response(merged_memory)
            # Add booking_state = "RESOLVED" for resolved bookings
            if booking_payload:
                booking_payload["booking_state"] = "RESOLVED"
                # Format services to preserve resolved_alias if present in current semantic result
                if merged_semantic_result:
                    current_services = merged_semantic_result.resolved_booking.get(
                        "services", [])
                    if current_services:
                        # Use services from current semantic result (which may have resolved_alias)
                        booking_payload["services"] = [
                            _format_service_for_response(service)
                            for service in current_services
                            if isinstance(service, dict)
                        ]
                    else:
                        # Format existing services from memory
                        booking_payload["services"] = [
                            _format_service_for_response(service)
                            for service in booking_payload.get("services", [])
                            if isinstance(service, dict)
                        ]
        elif memory_state and memory_state.get("intent") == "CREATE_BOOKING" and not needs_clarification:
            # Return existing booking state from memory for follow-ups
            booking_payload = extract_memory_state_for_response(memory_state)
            if booking_payload:
                booking_payload["booking_state"] = "RESOLVED"
                # Format services to preserve resolved_alias if present in current semantic result
                if merged_semantic_result:
                    current_services = merged_semantic_result.resolved_booking.get(
                        "services", [])
                    if current_services:
                        # Use services from current semantic result (which may have resolved_alias)
                        booking_payload["services"] = [
                            _format_service_for_response(service)
                            for service in current_services
                            if isinstance(service, dict)
                        ]
                    else:
                        # Format existing services from memory
                        booking_payload["services"] = [
                            _format_service_for_response(service)
                            for service in booking_payload.get("services", [])
                            if isinstance(service, dict)
                        ]
        elif is_booking_intent and needs_clarification:
            # For booking intents that need clarification, return lightweight context only
            resolved_booking = merged_semantic_result.resolved_booking
            services = resolved_booking.get("services", [])
            if not services:
                service_families = _get_business_categories(extraction_result)
                services = [
                    _format_service_for_response(service)
                    for service in service_families
                    if isinstance(service, dict) and service.get("text")
                ]
            else:
                services = [
                    _format_service_for_response(service)
                    for service in services
                    if isinstance(service, dict)
                ]
            date_refs = resolved_booking.get("date_refs") or []
            context_payload = {}
            if services:
                context_payload["services"] = services
            if date_refs:
                # Semantic reference (what user said)
                context_payload["start_date_ref"] = date_refs[0]
                if len(date_refs) >= 2:
                    context_payload["end_date_ref"] = date_refs[1]

                # Bound/processed date (ISO format) from calendar binding
                # Extract from calendar_booking if available
                bound_start_date = None
                bound_end_date = None
                if calendar_booking:
                    # Try date_range first (for reservations or date-only)
                    if calendar_booking.get("date_range"):
                        bound_start_date = calendar_booking["date_range"].get(
                            "start_date")
                        bound_end_date = calendar_booking["date_range"].get(
                            "end_date")
                    # Fallback to datetime_range (extract date part)
                    elif calendar_booking.get("datetime_range"):
                        dt_start = calendar_booking["datetime_range"].get(
                            "start", "")
                        dt_end = calendar_booking["datetime_range"].get(
                            "end", "")
                        if dt_start:
                            bound_start_date = dt_start.split("T")[0]
                        if dt_end:
                            bound_end_date = dt_end.split("T")[0]
                    # Also check direct start_date/end_date fields (for reservations)
                    if not bound_start_date and calendar_booking.get("start_date"):
                        bound_start_date = calendar_booking.get("start_date")
                    if not bound_end_date and calendar_booking.get("end_date"):
                        bound_end_date = calendar_booking.get("end_date")

                # Use bound date if available, otherwise fallback to semantic reference
                context_payload["start_date"] = bound_start_date if bound_start_date else date_refs[0]
                if len(date_refs) >= 2:
                    context_payload["end_date"] = bound_end_date if bound_end_date else date_refs[1]

            # Note: time_hint removed - now part of issues structure

        # Extract entities for non-booking intents (DISCOVERY, QUOTE, DETAILS, etc.)
        # CREATE_BOOKING and MODIFY_BOOKING should not include entities field
        entities_payload = None
        is_modify_booking = intent == "MODIFY_BOOKING"
        if not is_booking_intent and not is_modify_booking:
            # Extract services from extraction result
            service_families = _get_business_categories(extraction_result)
            # Always include entities field for non-booking intents
            entities_payload = {}
            if service_families:
                # Format services with text and canonical (same format as booking.services)
                # Preserve resolved_alias if present
                entities_payload["services"] = [
                    _format_service_for_response(service)
                    for service in service_families
                    if isinstance(service, dict) and service.get("text")
                ]

        processing_time = round((time.perf_counter() - start_time) * 1000, 2)

        # Add entity trace
        execution_trace["entity"] = {
            "service_ids": [s.get("text", "") if isinstance(s, dict) else str(s) for s in _get_business_categories(extraction_result)],
            "dates": [d.get("text", "") if isinstance(d, dict) else str(d) for d in (extraction_result.get("dates", []) + extraction_result.get("dates_absolute", []))],
            "times": [t.get("text", "") if isinstance(t, dict) else str(t) for t in extraction_result.get("times", [])]
        }

        # Add response trace (build issues for trace too)
        issues_for_trace: Dict[str, Any] = {}
        if needs_clarification:
            time_issues_for_trace = None
            if merged_semantic_result:
                time_issues_for_trace = merged_semantic_result.resolved_booking.get(
                    "time_issues", [])
            elif semantic_result:
                time_issues_for_trace = semantic_result.resolved_booking.get(
                    "time_issues", [])
            issues_for_trace = _build_issues(
                missing_slots, time_issues_for_trace)

        execution_trace["response"] = {
            "status": "needs_clarification" if needs_clarification else "ready",
            "intent": api_intent,
            "issues": issues_for_trace if issues_for_trace else {},
            "has_booking": booking_payload is not None,
            "has_clarification": needs_clarification
        }

        # Build final response summary (with issues)
        final_response_issues: Dict[str, Any] = {}
        if needs_clarification:
            time_issues_for_final = None
            if merged_semantic_result:
                time_issues_for_final = merged_semantic_result.resolved_booking.get(
                    "time_issues", [])
            elif semantic_result:
                time_issues_for_final = semantic_result.resolved_booking.get(
                    "time_issues", [])
            final_response_issues = _build_issues(
                missing_slots, time_issues_for_final)

        final_response = {
            "status": "needs_clarification" if needs_clarification else "ready",
            "intent": api_intent,
            "issues": final_response_issues if final_response_issues else {}
        }

        # Validate trace completeness (fail fast in debug mode)
        debug_flag = str(request.args.get("debug", "0")).lower()
        debug_mode = debug_flag in {"1", "true", "yes"}
        if debug_mode:
            required_trace_keys = ["entity", "semantic",
                                   "decision", "binder", "response"]
            missing_keys = [
                key for key in required_trace_keys if key not in execution_trace]
            if missing_keys:
                raise ValueError(
                    f"EXECUTION_TRACE incomplete: missing keys {missing_keys}")

        # Ensure trace and final_response are always included (even if empty)
        # This ensures the log structure is consistent
        if not execution_trace:
            execution_trace = {}
        if not final_response:
            final_response = {}

        # Build sentence trace - capture sentence evolution through pipeline
        # Capture the actual values flowing through the pipeline (do not recompute)
        normalized_text = extraction_result.get(
            "osentence", text) if extraction_result else text
        parameterized_text = extraction_result.get(
            "psentence", "") if extraction_result else ""

        # Intent resolver is called with raw text, but should use osentence (normalized)
        # Capture what is actually passed to resolve_intent (currently raw text)
        # Note: The intent resolver normalizes internally, but we capture what was passed
        intent_input_text = text  # Currently passed as raw text to resolve_intent

        sentence_trace = {
            "raw_text": text,
            "normalized_text": normalized_text,
            "parameterized_text": parameterized_text,
            "intent_input_text": intent_input_text
        }

        # Build complete input payload - capture all initial request data
        input_payload = {
            'user_id': user_id,
            'raw_text': text,
            'domain': domain,
            'timezone': timezone
        }

        # Include tenant_context if present (with aliases and booking_mode)
        if tenant_context:
            tenant_context_for_trace = {}
            if isinstance(tenant_context, dict):
                # Include aliases if present
                if "aliases" in tenant_context:
                    tenant_context_for_trace["aliases"] = tenant_context["aliases"]
                # Include booking_mode if present
                if "booking_mode" in tenant_context:
                    tenant_context_for_trace["booking_mode"] = tenant_context["booking_mode"]
            # Only add tenant_context to input if it has content
            if tenant_context_for_trace:
                input_payload['tenant_context'] = tenant_context_for_trace

        # Validate stable fields in debug mode only (non-breaking enforcement)
        # This ensures stable fields are present and have expected types
        # Debug fields are not validated and may change freely
        if debug_mode:
            trace_data = {
                'request_id': request_id,
                'input': input_payload,
                'trace': execution_trace,
                'final_response': final_response
            }
            validate_stable_fields(trace_data, debug_mode=True)

        # Emit single consolidated execution trace log
        # Field classification: See luma/trace_contract.py
        # - STABLE fields (request_id, input, final_response, trace.response.*, trace.semantic.*, trace.decision.state/reason/missing_slots)
        #   require versioning to change and are relied upon by downstream systems.
        # - DEBUG fields (sentence_trace, processing_time_ms, trace.entity.*, trace.binder.*, trace.*.rule_enforced, etc.)
        #   are internal diagnostics and may change without notice.
        # Trace version: v{TRACE_VERSION} (see luma/trace_contract.py)
        logger.info(
            "EXECUTION_TRACE",
            extra={
                'request_id': request_id,
                'input': input_payload,
                'sentence_trace': sentence_trace,
                'trace': execution_trace,
                'final_response': final_response,
                'processing_time_ms': processing_time
            }
        )

        # For CREATE_BOOKING, ensure booking is present only when ready
        if api_intent == "CREATE_BOOKING" and booking_payload is None and not needs_clarification:
            # This should not happen, but ensures contract compliance
            # Build minimal PARTIAL booking from merged semantic result
            resolved_booking = merged_semantic_result.resolved_booking
            services = resolved_booking.get("services", [])
            if not services:
                service_families = _get_business_categories(extraction_result)
                services = [
                    {
                        "text": service.get("text", ""),
                        "canonical": service.get("canonical", "")
                    }
                    for service in service_families
                    if isinstance(service, dict) and service.get("text")
                ]
            booking_payload = {
                "services": services,
                "datetime_range": None,
            }
            logger.warning(
                f"Fallback: Built PARTIAL booking for CREATE_BOOKING when booking_payload was None",
                extra={'request_id': request_id, 'intent': api_intent}
            )

        # booking_payload is already set above for both RESOLVED and PARTIAL cases
        # For non-booking intents, booking_payload may be None (which is fine)

        # Project minimal booking output shape
        if booking_payload is not None:
            # Normalize services to public canonical form
            if booking_payload.get("services"):
                booking_payload["services"] = [
                    _format_service_for_response(s)
                    for s in booking_payload.get("services", [])
                    if isinstance(s, dict)
                ]

            # Appointment responses: only datetime_range
            if intent_payload_name == "CREATE_APPOINTMENT":
                # Always copy datetime_range from calendar_booking if present
                # This comes from calendar binding and should override any memory values
                if "datetime_range" in calendar_booking:
                    booking_payload["datetime_range"] = calendar_booking["datetime_range"]
                booking_payload.pop("date", None)
                booking_payload.pop("time", None)
                booking_payload.pop("date_range", None)
                booking_payload.pop("time_range", None)
                booking_payload.pop("start_date", None)
                booking_payload.pop("end_date", None)

            # Reservation responses: only start_date / end_date
            if intent_payload_name == "CREATE_RESERVATION":
                # Always copy start_date and end_date from calendar_booking if present
                # These come from calendar binding and should override any memory values
                if "start_date" in calendar_booking:
                    booking_payload["start_date"] = calendar_booking["start_date"]
                if "end_date" in calendar_booking:
                    booking_payload["end_date"] = calendar_booking["end_date"]
                booking_payload.pop("datetime_range", None)
                booking_payload.pop("date", None)
                booking_payload.pop("time", None)
                booking_payload.pop("date_range", None)
                booking_payload.pop("time_range", None)

            # Remove legacy booking_state from response payloads
            booking_payload.pop("booking_state", None)

        # Build issues object from missing_slots and time_issues
        issues: Dict[str, Any] = {}
        if needs_clarification:
            # Get time_issues from resolved_booking if available
            time_issues_for_issues = None
            if merged_semantic_result:
                time_issues_for_issues = merged_semantic_result.resolved_booking.get(
                    "time_issues", [])
            elif semantic_result:
                time_issues_for_issues = semantic_result.resolved_booking.get(
                    "time_issues", [])

            # Fix 4: Filter service_id from missing_slots for reservations when services exist
            # For CREATE_RESERVATION, remove service_id from issues if services exist
            filtered_missing_slots = missing_slots
            # Check for services in semantic result (available even when booking_payload is None)
            semantic_services = None
            if merged_semantic_result and merged_semantic_result.resolved_booking:
                semantic_services = merged_semantic_result.resolved_booking.get("services")
            elif semantic_result and semantic_result.resolved_booking:
                semantic_services = semantic_result.resolved_booking.get("services")
            
            if (intent_payload_name == "CREATE_RESERVATION" and 
                "service_id" in missing_slots and
                semantic_services):
                filtered_missing_slots = [s for s in missing_slots if s != "service_id"]
                # Clear MISSING_SERVICE clarification_reason if services exist
                if clarification_reason == "MISSING_SERVICE":
                    clarification_reason = None
                    # If no other missing slots, mark as ready
                    if not filtered_missing_slots:
                        needs_clarification = False
            issues = _build_issues(filtered_missing_slots, time_issues_for_issues)

        response_body = {
            "success": True,
            "intent": intent_payload,
            "status": "needs_clarification" if needs_clarification else "ready",
            "issues": issues if issues else {},
            "clarification_reason": clarification_reason if needs_clarification else None,
            "needs_clarification": needs_clarification,
        }

        if needs_clarification:
            if context_payload:
                response_body["context"] = context_payload
        else:
            if booking_payload is not None:
                # Attach confirmation_state for ready bookings
                booking_payload["confirmation_state"] = "pending"
                # For reservations, provide a datetime_range spanning the stay so date helpers work uniformly
                if intent_payload_name == "CREATE_RESERVATION" and booking_payload.get("start_date") and booking_payload.get("end_date") and not booking_payload.get("datetime_range"):
                    start_iso = f"{booking_payload['start_date']}T00:00:00Z"
                    end_iso = f"{booking_payload['end_date']}T23:59:00Z"
                    booking_payload["datetime_range"] = {
                        "start": start_iso, "end": end_iso}

                response_body["booking"] = booking_payload
                # Expose flat slots for tests/consumers
                slots: Dict[str, Any] = {}
                if booking_payload.get("start_date"):
                    slots["start_date"] = booking_payload.get("start_date")
                if booking_payload.get("end_date"):
                    slots["end_date"] = booking_payload.get("end_date")
                # Check both booking_payload and calendar_booking for datetime_range
                # calendar_booking is the source of truth for calendar binding results
                datetime_range = booking_payload.get("datetime_range") or calendar_booking.get("datetime_range")
                if datetime_range:
                    slots["has_datetime"] = True
                # Bug B: For appointments with RESOLVED status, signal datetime completeness
                # even if datetime_range is null (binder may not have combined it, but semantic state has both)
                elif (intent_payload_name == "CREATE_APPOINTMENT" and 
                      decision_result and decision_result.status == "RESOLVED" and
                      merged_semantic_result):
                    resolved_booking = merged_semantic_result.resolved_booking
                    has_date_refs = bool(resolved_booking.get("date_refs"))
                    has_time_refs = bool(resolved_booking.get("time_refs"))
                    # If both date and time exist in semantic state, signal datetime completeness
                    if has_date_refs and has_time_refs:
                        slots["has_datetime"] = True
                services = booking_payload.get("services") or []
                if services:
                    primary = services[-1] if isinstance(services[-1], dict) else (
                        services[0] if isinstance(services[0], dict) else {})
                    # Fix 3: Normalize canonical service ID to display name for service_id slot
                    # Convert "beauty_and_wellness.beard_grooming" → "beard grooming"
                    canonical = primary.get("canonical") if isinstance(primary, dict) else None
                    if canonical:
                        slots["service_id"] = _normalize_service_canonical_to_display(canonical)
                    else:
                        # Fallback to text field if canonical not available
                        service_text = primary.get("text") if isinstance(primary, dict) else None
                        if service_text:
                            slots["service_id"] = service_text
                response_body["slots"] = slots
        # Omit null datetime_range for cleanliness
        if response_body.get("booking") and response_body["booking"].get("datetime_range") is None:
            response_body["booking"].pop("datetime_range", None)

        # Add entities field for non-booking intents (always include, even if empty)
        if entities_payload is not None:
            response_body["entities"] = entities_payload

        # Attach full internal pipeline data only in debug mode
        if debug_mode:
            response_body["debug"] = results

        # Removed per-stage logging - consolidated trace emitted at end

        return jsonify(response_body)

    except Exception as e:  # noqa: BLE001
        logger.error(
            f"Processing failed: {str(e)}",
            extra={
                'request_id': request_id,
                'error_type': type(e).__name__,
                'text_length': len(text) if 'text' in locals() else 0
            },
            exc_info=True
        )
        return jsonify({
            "success": False,
            "error": f"Processing failed: {str(e)}"
        }), 500

