#!/usr/bin/env python3
"""
Isolated test for fuzzy matching in tenant alias detection.

Tests the _apply_fuzzy_matching_post_process function directly.
"""

from luma.extraction.matcher import _apply_fuzzy_matching_post_process
import sys
from pathlib import Path

# Add src directory to path for imports
script_dir = Path(__file__).parent.resolve()  # extraction/
src_dir = script_dir.parent.parent  # src/
src_path = str(src_dir)
if src_path not in sys.path:
    sys.path.insert(0, src_path)


def test_premium_suite_fuzzy_match():
    """Test that 'premium suite' fuzzy matches to 'premum suite'."""
    print("=" * 60)
    print("Test: 'premium suite' should fuzzy match 'premum suite'")
    print("=" * 60)

    normalized_text = "book me in for premium suite from october 5 th to 9 th"
    tenant_aliases = {
        "premum suite": "room",  # Typo in tenant alias
        "suite": "room",  # Shorter exact match
        "standard": "room",
        "room": "room",
    }

    # Find actual position of "suite" in the text
    import re
    suite_match = re.search(r"\bsuite\b", normalized_text.lower())
    suite_start = suite_match.start() if suite_match else 20
    suite_end = suite_match.end() if suite_match else 25

    # Simulate what compiled version would return (exact match for "suite")
    existing_spans = [
        {
            "start_char": suite_start,
            "end_char": suite_end,
            "text": "suite",
            "canonical": "room",
            "alias_key": "suite",
            "match_type": "exact",
        }
    ]

    print(f"\nInput text: '{normalized_text}'")
    print(f"Tenant aliases: {list(tenant_aliases.keys())}")
    print(f"\nExisting spans (from exact matching):")
    for span in existing_spans:
        print(
            f"  - {span['text']} at [{span['start_char']}:{span['end_char']}] (match_type: {span['match_type']})")

    # Apply fuzzy matching
    result = _apply_fuzzy_matching_post_process(
        normalized_text, tenant_aliases, existing_spans)

    print(f"\nResult spans (after fuzzy matching):")
    for span in result:
        match_type = span.get("match_type", "unknown")
        fuzzy_score = span.get("fuzzy_score", "")
        score_str = f", fuzzy_score: {fuzzy_score}" if fuzzy_score else ""
        print(f"  - '{span['text']}' at [{span['start_char']}:{span['end_char']}] "
              f"(match_type: {match_type}{score_str}, alias_key: {span.get('alias_key', 'N/A')})")

    # Check if "premum suite" was matched
    premum_suite_found = any(
        span.get("alias_key") == "premum suite"
        for span in result
    )

    suite_only_found = any(
        span.get("alias_key") == "suite" and span.get("match_type") == "exact"
        for span in result
    )

    print(f"\n[PASS] 'premum suite' matched: {premum_suite_found}")
    print(f"[FAIL] 'suite' (exact) still present: {suite_only_found}")

    if premum_suite_found and not suite_only_found:
        print(
            "\n[PASS] TEST PASSED: Fuzzy matching correctly preferred 'premum suite' over 'suite'")
        return True
    else:
        print(
            "\n[FAIL] TEST FAILED: Expected 'premum suite' to be matched, but got different result")
        return False


def test_exact_match_still_works():
    """Test that exact matches still work when no fuzzy match is needed."""
    print("\n" + "=" * 60)
    print("Test: Exact match 'premum suite' should still work")
    print("=" * 60)

    normalized_text = "book me in for premum suite from october 5 th to 9 th"
    tenant_aliases = {
        "premum suite": "room",  # Typo in tenant alias
        "suite": "room",
    }

    # Simulate what compiled version would return (exact match for "premum suite")
    existing_spans = [
        {
            "start_char": 20,  # Position of "premum suite" in normalized text
            "end_char": 32,
            "text": "premum suite",
            "canonical": "room",
            "alias_key": "premum suite",
            "match_type": "exact",
        }
    ]

    print(f"\nInput text: '{normalized_text}'")
    print(f"\nExisting spans (from exact matching):")
    for span in existing_spans:
        print(
            f"  - {span['text']} at [{span['start_char']}:{span['end_char']}] (match_type: {span['match_type']})")

    # Apply fuzzy matching
    result = _apply_fuzzy_matching_post_process(
        normalized_text, tenant_aliases, existing_spans)

    print(f"\nResult spans (after fuzzy matching):")
    for span in result:
        match_type = span.get("match_type", "unknown")
        print(f"  - '{span['text']}' at [{span['start_char']}:{span['end_char']}] "
              f"(match_type: {match_type}, alias_key: {span.get('alias_key', 'N/A')})")

    # Check if "premum suite" is still there
    premum_suite_found = any(
        span.get("alias_key") == "premum suite"
        for span in result
    )

    if premum_suite_found:
        print("\n[PASS] TEST PASSED: Exact match 'premum suite' still works")
        return True
    else:
        print(
            "\n[FAIL] TEST FAILED: Expected 'premum suite' to remain, but it was removed")
        return False


def test_character_positions():
    """Test that character positions are calculated correctly."""
    print("\n" + "=" * 60)
    print("Test: Character position calculation")
    print("=" * 60)

    normalized_text = "book me in for premium suite from october 5 th to 9 th"
    print(f"\nText: '{normalized_text}'")
    print(f"Length: {len(normalized_text)}")

    # Find "premium suite" position
    import re
    match = re.search(r"premium suite", normalized_text.lower())
    if match:
        start, end = match.span()
        print(f"\n'premium suite' found at [{start}:{end}]")
        print(f"  Text at that position: '{normalized_text[start:end]}'")

    # Find "suite" position
    match = re.search(r"\bsuite\b", normalized_text.lower())
    if match:
        start, end = match.span()
        print(f"\n'suite' found at [{start}:{end}]")
        print(f"  Text at that position: '{normalized_text[start:end]}'")

    # Check if "suite" is contained within "premium suite"
    premium_start = normalized_text.lower().find("premium suite")
    premium_end = premium_start + len("premium suite")
    suite_start = normalized_text.lower().find(" suite")
    suite_end = suite_start + len(" suite")

    print(f"\nOverlap check:")
    print(f"  'premium suite': [{premium_start}:{premium_end}]")
    print(f"  'suite': [{suite_start}:{suite_end}]")
    print(
        f"  'suite' contained in 'premium suite': {suite_start >= premium_start and suite_end <= premium_end}")


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("Fuzzy Matcher Isolation Tests")
    print("=" * 60)

    # Test character positions first
    test_character_positions()

    # Run tests
    test1_passed = test_premium_suite_fuzzy_match()
    test2_passed = test_exact_match_still_works()

    print("\n" + "=" * 60)
    print("Summary")
    print("=" * 60)
    print(f"Test 1 (fuzzy match): {'PASSED' if test1_passed else 'FAILED'}")
    print(f"Test 2 (exact match): {'PASSED' if test2_passed else 'FAILED'}")

    if test1_passed and test2_passed:
        print("\n[PASS] All tests passed!")
        sys.exit(0)
    else:
        print("\n[FAIL] Some tests failed!")
        sys.exit(1)
