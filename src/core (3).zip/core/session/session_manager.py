"""
Session Manager

Redis-backed session storage for conversational state.

This module provides session management functionality to support follow-ups
without changing existing intent, semantic, or decision logic.

Session schema:
{
    "intent": str,
    "slots": dict,
    "missing_slots": list[str],
    "status": "READY" | "NEEDS_CLARIFICATION"
}

Constraints:
- Uses JSON serialization only (no pickles, no model objects)
- TTL: 20 minutes (reset on save)
- Stateless session logic at API boundary only
"""

import json
import os
from typing import Dict, Any, Optional

SESSION_TTL_SECONDS = 20 * 60  # 20 minutes (middle of 15-30 range)
REDIS_ENV_VAR = "REDIS_URL"
SESSION_KEY_PREFIX = "session:"


def _get_redis_client():
    """
    Get Redis client from environment configuration.
    
    Returns:
        Redis client instance or None if Redis is not available.
    """
    redis_url = os.getenv(REDIS_ENV_VAR)
    if not redis_url:
        return None
    
    try:
        import redis  # type: ignore
        return redis.from_url(redis_url)
    except Exception:
        return None


def _get_session_key(user_id: str) -> str:
    """Generate Redis key for user session."""
    return f"{SESSION_KEY_PREFIX}{user_id}"


def get_session(user_id: str) -> Optional[Dict[str, Any]]:
    """
    Retrieve session state for a user.
    
    Args:
        user_id: Unique identifier for the user
        
    Returns:
        Session state dictionary or None if not found/expired
    """
    redis_client = _get_redis_client()
    if not redis_client:
        return None
    
    try:
        key = _get_session_key(user_id)
        raw = redis_client.get(key)
        if not raw:
            return None
        return json.loads(raw)
    except Exception:
        return None


def save_session(user_id: str, session_state: Dict[str, Any]) -> None:
    """
    Save session state for a user.
    
    Resets TTL on each save (20 minutes).
    
    Args:
        user_id: Unique identifier for the user
        session_state: Session state dictionary with keys:
            - intent: str
            - slots: dict
            - missing_slots: list[str]
            - status: "READY" | "NEEDS_CLARIFICATION"
    """
    redis_client = _get_redis_client()
    if not redis_client:
        return
    
    try:
        key = _get_session_key(user_id)
        serialized = json.dumps(session_state)
        redis_client.setex(key, SESSION_TTL_SECONDS, serialized)
    except Exception:
        # Fail silently - session persistence is optional
        pass


def clear_session(user_id: str) -> None:
    """
    Clear session state for a user.
    
    Args:
        user_id: Unique identifier for the user
    """
    redis_client = _get_redis_client()
    if not redis_client:
        return
    
    try:
        key = _get_session_key(user_id)
        redis_client.delete(key)
    except Exception:
        # Fail silently
        pass

