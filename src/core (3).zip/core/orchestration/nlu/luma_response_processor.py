"""
Luma Response Processor

Interprets Luma API responses and produces decision plans.

This module is pure and side-effect free:
- No external API calls
- No state mutation
- Deterministic interpretation of Luma responses

Responsibilities:
- Clarification interpretation (reason, issues, context)
- CLARIFY outcome construction
- Intent extraction and validation
- Building decision plans with status, allowed_actions, blocked_actions, awaiting
"""

import logging
import threading
from pathlib import Path
from typing import Dict, Any, Optional, List, Set

import yaml

from core.routing import get_template_key, get_action_name
from core.orchestration.errors import UnsupportedIntentError
from luma.clarification.reasons import ClarificationReason

logger = logging.getLogger(__name__)

# Cache for intent execution config (loaded once per process)
_intent_execution_cache: Optional[Dict[str, Any]] = None
_cache_lock = threading.Lock()


def _load_intent_execution_config() -> Dict[str, Any]:
    """
    Load intent execution configuration from YAML file (cached at module level).
    
    Thread-safe lazy loading: loads once on first access, reuses cached data
    for subsequent calls. Zero YAML I/O on request path after initial load.
    
    Returns:
        Dictionary with intent execution config (intents -> commit, fallbacks)
    """
    global _intent_execution_cache
    
    # Fast path: return cached data if already loaded
    if _intent_execution_cache is not None:
        return _intent_execution_cache
    
    # Slow path: load and cache (thread-safe)
    with _cache_lock:
        # Double-check after acquiring lock (another thread may have loaded it)
        if _intent_execution_cache is not None:
            return _intent_execution_cache
        
        # Load YAML file
        config_dir = Path(__file__).resolve().parent.parent / "config"
        config_path = config_dir / "intent_execution.yaml"
        
        if not config_path.exists():
            logger.warning(
                f"intent_execution.yaml not found at {config_path}, "
                "using empty config (no commit actions or fallbacks)"
            )
            _intent_execution_cache = {}
            return _intent_execution_cache
        
        with config_path.open(encoding="utf-8") as f:
            raw = yaml.safe_load(f) or {}
        
        # Extract intents dict from YAML (structure: {intents: {INTENT_NAME: {...}}})
        _intent_execution_cache = raw.get("intents", {}) if isinstance(raw, dict) else {}
        return _intent_execution_cache


def _normalize_modify_booking_missing_slots(
    missing_slots: List[str],
    luma_response: Dict[str, Any]
) -> List[str]:
    """
    Normalize MODIFY_BOOKING missing_slots according to planning contract.
    
    ARCHITECTURAL CHANGE: Planning vs execution slot contracts are now separated.
    - Planning contract: ["booking_id", "date"] (if time provided, date required)
    - Execution contract: ["booking_id"] (checked later, not used for planning)
    
    This function now preserves planning-required slots (date) in missing_slots.
    It only filters out execution-specific slots that shouldn't appear in planning.
    
    Args:
        missing_slots: Raw missing slots list (computed from planning contract)
        luma_response: Luma API response (for context)
        
    Returns:
        Normalized missing slots list (preserves planning requirements)
    """
    # Check if this is MODIFY_BOOKING
    intent = luma_response.get("intent", {})
    intent_name = intent.get("name", "") if isinstance(intent, dict) else ""
    if intent_name != "MODIFY_BOOKING":
        return missing_slots
    
    # Planning contract for MODIFY_BOOKING: ["booking_id", "date"]
    # If time is provided, date becomes required (handled in compute_missing_slots)
    # We preserve all planning-required slots in missing_slots
    # Only filter out execution-specific or invalid slots
    
    # Check slots for context
    slots = luma_response.get("slots", {})
    if not isinstance(slots, dict):
        slots = {}
    
    # Planning-required slots that should be preserved
    planning_slots = {"booking_id", "date"}
    
    # Filter: keep planning-required slots and remove only invalid/execution-specific ones
    normalized = []
    for slot in missing_slots:
        if slot in planning_slots:
            # Preserve planning-required slots
            normalized.append(slot)
        elif slot not in ("change", "time", "start_date", "end_date", "datetime_range", "date_range"):
            # Keep other valid slots (but not execution-specific datetime slots)
            normalized.append(slot)
        # Filter out: "change" (test artifact), execution-specific datetime slots
    
    return normalized if normalized else missing_slots


def _extract_missing_slots(luma_response: Dict[str, Any]) -> Optional[List[str]]:
    """
    Extract missing slots from Luma response.
    
    Priority order:
    1. Direct missing_slots field in response (computed by merge) - even if []
    2. Intent result missing_slots
    3. Issues dict (slots with "missing" value) - only if missing_slots not set
    
    CRITICAL: If missing_slots==[], return [] (not None) - it means "no missing slots"
    Only return None if missing_slots is truly not set.
    
    Args:
        luma_response: Luma API response (may have merged missing_slots)
        
    Returns:
        List of missing slot names (normalized for MODIFY_BOOKING) or None if not set
    """
    # PRIORITY 1: Check direct missing_slots field (computed by merge from intent contract)
    # This is the authoritative source - use it even if []
    if "missing_slots" in luma_response:
        direct_missing = luma_response.get("missing_slots")
        if isinstance(direct_missing, list):
            # missing_slots is set (even if []) - use it directly
            # [] means "no missing slots" (all required slots satisfied)
            missing_slots = direct_missing.copy()
            # Normalize MODIFY_BOOKING missing_slots according to test contract
            missing_slots = _normalize_modify_booking_missing_slots(missing_slots, luma_response)
            return missing_slots
    
    # PRIORITY 2: Check intent result
    intent = luma_response.get("intent", {})
    if isinstance(intent, dict) and "missing_slots" in intent:
        intent_missing = intent.get("missing_slots")
        if isinstance(intent_missing, list):
            missing_slots = intent_missing.copy()
            # Normalize MODIFY_BOOKING missing_slots according to test contract
            missing_slots = _normalize_modify_booking_missing_slots(missing_slots, luma_response)
            return missing_slots
    
    # PRIORITY 3: Check issues dict (slots with "missing" value)
    # Only use issues if missing_slots not explicitly set in response
    # This handles cases where Luma hasn't been through merge yet
    missing_slots: List[str] = []
    issues = luma_response.get("issues", {})
    if isinstance(issues, dict):
        for slot_name, slot_value in issues.items():
            if slot_value == "missing" and slot_name not in missing_slots:
                missing_slots.append(slot_name)
    
    # Deduplicate
    missing_slots = list(set(missing_slots))
    
    # Normalize MODIFY_BOOKING missing_slots according to test contract
    missing_slots = _normalize_modify_booking_missing_slots(missing_slots, luma_response)
    
    # INVARIANT: Always return a list, never None
    # Return [] if no missing slots found (empty list is valid)
    # This ensures missing_slots is always a list throughout the codebase
    return missing_slots if isinstance(missing_slots, list) else []


def _evaluate_fallbacks(
    intent_config: Dict[str, Any],
    missing_slots: List[str]
) -> List[str]:
    """
    Evaluate fallback actions based on missing slots.
    
    Matches fallback.when_missing.any_of against missing_slots.
    Returns list of action names for matching fallbacks.
    
    Args:
        intent_config: Intent config from intent_execution.yaml
        missing_slots: List of missing slot names from Luma
        
    Returns:
        List of allowed fallback action names
    """
    allowed_actions: List[str] = []
    fallbacks = intent_config.get("fallbacks", [])
    
    if not isinstance(fallbacks, list):
        return allowed_actions
    
    missing_slots_set = set(missing_slots)
    
    for fallback in fallbacks:
        if not isinstance(fallback, dict):
            continue
        
        action = fallback.get("action")
        if not action:
            continue
        
        when_missing = fallback.get("when_missing", {})
        if not isinstance(when_missing, dict):
            continue
        
        any_of = when_missing.get("any_of", [])
        if not isinstance(any_of, list):
            continue
        
        # Check if any of the required slots are missing
        if any(slot in missing_slots_set for slot in any_of):
            allowed_actions.append(action)
    
    return allowed_actions


def _build_decision_plan(
    intent_name: str,
    luma_response: Dict[str, Any],
    domain: str
) -> Dict[str, Any]:
    """
    Build a decision plan from Luma response and intent execution config.
    
    Applies rules:
    - commit.action is the irreversible commit step
    - Block commit when needs_clarification == true OR booking.confirmation_state != "confirmed"
    - Evaluate fallbacks by matching when_missing.any_of against missing_slots
    - Allow matching fallback actions (non-destructive)
    
    Args:
        intent_name: Intent name from Luma
        luma_response: Luma API response
        domain: Domain for template key routing
        
    Returns:
        Decision plan dictionary with:
        - status: READY, NEEDS_CLARIFICATION, or AWAITING_CONFIRMATION
        - allowed_actions: List of allowed action names
        - blocked_actions: List of blocked action names
        - awaiting: USER_CONFIRMATION or null
    """
    # Load intent execution config
    intent_configs = _load_intent_execution_config()
    intent_config = intent_configs.get(intent_name, {})
    
    # Get missing_slots from merged response (computed by session merge)
    # ARCHITECTURAL INVARIANT: missing_slots is computed exactly once per turn in session merge
    # missing_slots MUST NOT be recomputed here - it is a pure derived value
    # missing_slots = [] is VALID and means all required slots are satisfied
    missing_slots = luma_response.get("missing_slots")
    
    # INVARIANT CHECK: missing_slots must be a list (never None after merge)
    if missing_slots is None:
        # This should never happen if merge ran correctly
        logger.error(
            f"[MISSING_SLOTS] VIOLATION: missing_slots is None after merge! "
            f"intent={intent_name}, luma_response_keys={list(luma_response.keys())}"
        )
        # Fail-safe: use empty list (but this indicates a bug)
        missing_slots = []
    elif not isinstance(missing_slots, list):
        # This should never happen if merge ran correctly
        logger.error(
            f"[MISSING_SLOTS] VIOLATION: missing_slots is not a list! "
            f"type={type(missing_slots)}, value={missing_slots}, intent={intent_name}"
        )
        # Fail-safe: convert to list (but this indicates a bug)
        missing_slots = list(missing_slots) if missing_slots else []
    
    # CRITICAL: Do NOT recompute missing_slots here - it is already computed in merge
    # missing_slots = [] is valid and must not trigger recomputation
    
    # Determine status
    needs_clarification = luma_response.get("needs_clarification", False)
    booking = luma_response.get("booking", {})
    confirmation_state = booking.get("confirmation_state") if isinstance(booking, dict) else None
    
    # DEBUG: Print decision plan building details
    print(f"[BUILD_PLAN] intent={intent_name} missing_slots={missing_slots} needs_clarification={needs_clarification} confirmation_state={confirmation_state}")
    
    # CRITICAL: If missing_slots is non-empty, status MUST be NEEDS_CLARIFICATION
    # This is the authoritative rule - missing slots drive clarification, not Luma flags
    # NEVER use `if not missing_slots` - only check length (empty list is valid)
    if len(missing_slots) > 0:
        status = "NEEDS_CLARIFICATION"
        print(f"[BUILD_PLAN] Setting status=NEEDS_CLARIFICATION because missing_slots={missing_slots}")
    elif needs_clarification:
        status = "NEEDS_CLARIFICATION"
        print(f"[BUILD_PLAN] Setting status=NEEDS_CLARIFICATION because needs_clarification=True")
    elif confirmation_state == "pending":
        status = "AWAITING_CONFIRMATION"
        print(f"[BUILD_PLAN] Setting status=AWAITING_CONFIRMATION because confirmation_state=pending")
    else:
        status = "READY"
        print(f"[BUILD_PLAN] Setting status=READY (no missing slots, no clarification needed, no pending confirmation)")
    
    # Get commit action
    commit_config = intent_config.get("commit", {})
    commit_action = commit_config.get("action") if isinstance(commit_config, dict) else None
    
    # Determine allowed and blocked actions
    allowed_actions: List[str] = []
    blocked_actions: List[str] = []
    
    # CRITICAL: If missing_slots exist, block ALL actions (including fallbacks)
    # Planner must never see READY if missing_slots exist
    # Executing fallback actions while missing slots is a bug
    # NEVER use `if not missing_slots` - only check length (empty list is valid)
    if len(missing_slots) > 0:
        # Block all actions when missing_slots exist
        if commit_action:
            blocked_actions.append(commit_action)
        # Do NOT evaluate fallbacks - they should not execute while clarifying
    else:
        # Only evaluate fallbacks if no missing slots (missing_slots = [])
        fallback_actions = _evaluate_fallbacks(intent_config, missing_slots)
        allowed_actions.extend(fallback_actions)
        
        # Commit action blocking rules
        if commit_action:
            # CRITICAL: If missing_slots is empty ([]), allow commit immediately
            # Tests expect READY state to execute without confirmation when slots are complete
            # Do NOT require confirmation_state == "confirmed" when all slots are filled
            if len(missing_slots) > 0:
                # Still have missing slots - block commit
                blocked_actions.append(commit_action)
            elif needs_clarification:
                # Luma explicitly says needs clarification - block commit
                blocked_actions.append(commit_action)
            else:
                # All slots filled and no clarification needed - allow commit
                # Do NOT check confirmation_state - tests expect immediate execution
                allowed_actions.append(commit_action)
    
    # Deduplicate
    allowed_actions = list(set(allowed_actions))
    blocked_actions = list(set(blocked_actions))
    
    # Determine awaiting
    awaiting = "USER_CONFIRMATION" if confirmation_state == "pending" else None
    
    # AWAITING_SLOT: Set when status == NEEDS_CLARIFICATION and exactly one slot is missing
    # This allows Core to route user-provided values into the slot it's currently asking for
    awaiting_slot = None
    if status == "NEEDS_CLARIFICATION" and len(missing_slots) == 1:
        awaiting_slot = missing_slots[0]
        logger.debug(f"Set awaiting_slot={awaiting_slot} (exactly one missing slot)")
    
    # CRITICAL INVARIANT: If awaiting_slot is set (from session or newly computed),
    # status MUST remain NEEDS_CLARIFICATION
    # awaiting_slot indicates the session is explicitly awaiting a slot value
    # READY is only allowed when missing_slots is empty AND awaiting_slot is null
    awaiting_slot_from_session = luma_response.get("awaiting_slot")
    
    print(
        f"[AWAITING_SLOT_DEBUG] Before status check: "
        f"awaiting_slot_from_session={awaiting_slot_from_session}, "
        f"awaiting_slot_new={awaiting_slot}, "
        f"missing_slots={missing_slots}, "
        f"status={status}"
    )
    
    effective_awaiting_slot = awaiting_slot_from_session or awaiting_slot
    
    print(
        f"[AWAITING_SLOT_DEBUG] effective_awaiting_slot={effective_awaiting_slot}, "
        f"status={status}, "
        f"will_force_needs_clarification={effective_awaiting_slot and status == 'READY'}"
    )
    
    if effective_awaiting_slot and status == "READY":
        # awaiting_slot is set but status was set to READY - force NEEDS_CLARIFICATION
        status = "NEEDS_CLARIFICATION"
        logger.info(
            f"[AWAITING_SLOT] Forcing status=NEEDS_CLARIFICATION because awaiting_slot={effective_awaiting_slot} is set "
            f"(even though missing_slots is empty)"
        )
        print(
            f"[AWAITING_SLOT] Forcing status=NEEDS_CLARIFICATION because awaiting_slot={effective_awaiting_slot} is set "
            f"(even though missing_slots is empty)"
        )
        # Recompute awaiting_slot since status changed to NEEDS_CLARIFICATION
        if not awaiting_slot and len(missing_slots) == 1:
            awaiting_slot = missing_slots[0]
        elif not awaiting_slot:
            # Use the session awaiting_slot if available
            awaiting_slot = awaiting_slot_from_session
    
    print(
        f"[AWAITING_SLOT_DEBUG] Final plan: "
        f"status={status}, "
        f"awaiting_slot={awaiting_slot or awaiting_slot_from_session}, "
        f"missing_slots={missing_slots}"
    )
    
    return {
        "status": status,
        "allowed_actions": allowed_actions,
        "blocked_actions": blocked_actions,
        "awaiting": awaiting,
        "awaiting_slot": awaiting_slot or awaiting_slot_from_session
    }


def _extract_clarification_data(
    clarification_reason: Optional[str],
    issues: Dict[str, Any],
    clarification_data: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Extract structured clarification data from Luma response.

    Builds a structured data object with:
    - reason: Stable enum-like value (e.g., "MISSING_TIME", "MULTIPLE_MATCHES")
    - missing: Explicit list of required fields that are missing (e.g., ["time"])
    - ambiguous: List of ambiguous fields that need disambiguation (e.g., ["service"]) for MULTIPLE_MATCHES
    - Additional fields from clarification_data (e.g., "options" for MULTIPLE_MATCHES)

    This function extracts semantic cause of clarification and populates
    data.reason, data.missing, and data.ambiguous. This is the single, authoritative source
    for clarification semantics.

    Args:
        clarification_reason: Clarification reason string from Luma
        issues: Issues dict from Luma (contains missing slots, time issues, etc.)
        clarification_data: Optional structured clarification data from Luma (e.g., options for MULTIPLE_MATCHES)

    Returns:
        Dictionary with 'reason', 'missing', and 'ambiguous' fields (all always present), plus any additional fields from clarification_data
    """
    # Extract reason (use clarification_reason if present and non-empty, otherwise infer from issues)
    reason = clarification_reason if clarification_reason and clarification_reason.strip() else None

    # Extract missing and ambiguous fields from issues dict
    # Issues structure: {slot_name: "missing"} or {slot_name: "ambiguous"} or {slot_name: {...}} for rich issues
    missing = []
    ambiguous = []
    if isinstance(issues, dict):
        for slot_name, slot_value in issues.items():
            # If value is "missing", add to missing list
            if slot_value == "missing":
                missing.append(slot_name)
            # If value is "ambiguous", add to ambiguous list (NOT missing)
            elif slot_value == "ambiguous":
                ambiguous.append(slot_name)
            # For rich time issues, still consider "time" as missing if present
            elif slot_name == "time" and isinstance(slot_value, dict):
                # Time has ambiguity but is still missing resolution
                missing.append("time")

    # For UNSUPPORTED_SERVICE, ensure "service" is in missing if not already there
    # Note: MULTIPLE_MATCHES is now handled in Luma (issues.service = "ambiguous"),
    # so it will be extracted from issues above. Only UNSUPPORTED_SERVICE needs fallback handling here.
    if reason == ClarificationReason.UNSUPPORTED_SERVICE.value:
        if "service" not in missing and "service_id" not in missing:
            missing.append("service")

    # If no reason provided but we have missing slots, infer reason
    # Note: Missing slots are already filtered by satisfaction checks in process_luma_response
    # So if "service" is in missing here, it means service_id is truly missing
    if not reason and missing:
        if "time" in missing:
            reason = ClarificationReason.MISSING_TIME.value
        elif "date" in missing:
            reason = ClarificationReason.MISSING_DATE.value
        elif "service" in missing or "service_id" in missing:
            reason = ClarificationReason.MISSING_SERVICE.value
        else:
            reason = ClarificationReason.MISSING_CONTEXT.value  # Generic fallback

    # Build structured data object - always include all fields
    # reason defaults to MISSING_CONTEXT if not provided and cannot be inferred
    if not reason:
        reason = ClarificationReason.MISSING_CONTEXT.value

    # missing and ambiguous default to empty lists if none found
    if not missing:
        missing = []
    if not ambiguous:
        ambiguous = []

    # Start with reason, missing, and ambiguous (always present)
    data = {
        "reason": reason,
        "missing": missing,
        "ambiguous": ambiguous
    }

    # Merge additional fields from clarification_data (e.g., options for MULTIPLE_MATCHES)
    if clarification_data and isinstance(clarification_data, dict):
        # Merge clarification_data into data (e.g., options for MULTIPLE_MATCHES)
        # But preserve reason, missing, and ambiguous as authoritative
        # Note: service_family is not included here - use context.services[0].canonical instead
        for key, value in clarification_data.items():
            if key not in ("reason", "missing", "ambiguous"):  # Don't override reason/missing/ambiguous
                data[key] = value

    return data


def _derive_clarification_reason_from_missing_slots(missing: List[str]) -> str:
    """
    Derive canonical clarification reason from missing slots.
    
    This function provides the single source of truth for mapping missing slots
    to canonical clarification reasons. All clarification outcomes should use
    this function to ensure consistency.
    
    Args:
        missing: List of missing slot names (e.g., ["start_date", "end_date"])
        
    Returns:
        Canonical clarification reason string
    """
    missing_set = set(missing)
    
    if missing_set == {"start_date", "end_date"}:
        return "MISSING_DATE_RANGE"
    elif missing_set == {"start_date"}:
        return "MISSING_START_DATE"
    elif missing_set == {"end_date"}:
        return "MISSING_END_DATE"
    elif missing_set == {"time"}:
        return "MISSING_TIME"
    elif missing_set == {"date"}:
        return "MISSING_DATE"
    elif "time" in missing_set:
        return "MISSING_TIME"
    else:
        return "NEEDS_CLARIFICATION"


def _build_clarify_outcome(
    clarification_reason: str,
    issues: Dict[str, Any],
    context: Dict[str, Any],
    booking: Optional[Dict[str, Any]],
    domain: str,
    clarification_data: Optional[Dict[str, Any]] = None,
    facts: Optional[Dict[str, Any]] = None,
    intent_name: Optional[str] = None
) -> Dict[str, Any]:
    """
    Build a CLARIFY outcome from Luma response data.

    Args:
        clarification_reason: Clarification reason string from Luma
        issues: Issues dict from Luma
        context: Context dict from Luma
        booking: Optional booking payload from Luma
        domain: Domain for template key routing
        clarification_data: Optional structured clarification data from Luma (e.g., options for MULTIPLE_MATCHES)
        facts: Optional facts container with slots, missing_slots, context (for rendering)
        intent_name: Intent name from Luma (ALWAYS set when needs_clarification == true)

    Returns:
        Complete CLARIFY outcome dictionary ready to return
    """
    template_key = get_template_key(clarification_reason, domain)

    logger.info(
        f"Clarification needed: {clarification_reason} -> {template_key}"
    )

    # Extract structured clarification data (reason, missing, and ambiguous fields)
    # This is the single, authoritative source for clarification semantics
    data = _extract_clarification_data(
        clarification_reason, issues, clarification_data)

    # Derive canonical clarification_reason from missing slots
    # This is the top-level field that tests expect
    missing_slots = data.get("missing", [])
    canonical_reason = _derive_clarification_reason_from_missing_slots(missing_slots)

    # Build outcome with facts for rendering
    outcome = {
        "status": "NEEDS_CLARIFICATION",
        "clarification_reason": canonical_reason,  # Top-level canonical reason derived from missing slots
        "template_key": template_key,
        # data contains reason, missing, ambiguous, and any additional fields from clarification_data (e.g., options)
        "data": data,
        "context": context,  # Include context if present
        "booking": booking
    }
    
    # ALWAYS set intent_name when needs_clarification == true (never recompute from facts/slots)
    if intent_name:
        outcome["intent_name"] = intent_name
    
    # Include facts if provided (needed for renderer to access slots)
    if facts:
        outcome["facts"] = facts

    return {
        "success": True,
        "outcome": outcome
    }


def process_luma_response(
    luma_response: Dict[str, Any],
    domain: str,
    user_id: str
) -> Dict[str, Any]:
    """
    Process Luma response and produce a decision plan.

    This function interprets the Luma response and returns a decision plan that includes:
    - status (READY, NEEDS_CLARIFICATION, AWAITING_CONFIRMATION)
    - allowed_actions
    - blocked_actions
    - awaiting (USER_CONFIRMATION or null)

    Args:
        luma_response: Validated Luma API response
        domain: Domain for template key routing
        user_id: User identifier for logging

    Returns:
        Decision dictionary with:
        - plan: Decision plan (status, allowed_actions, blocked_actions, awaiting)
        - outcome: Clarification outcome (if status is NEEDS_CLARIFICATION)
        - intent_name: Intent name (if status is READY or AWAITING_CONFIRMATION)
        - action_name: Action name for handler mapping
        - booking: Booking payload
        - facts: Facts container with slots, missing_slots, context (passthrough from Luma)
        - error: Error code (if error occurred)
        - message: Error message (if error occurred)
    """
    # Extract intent and validate
    intent = luma_response.get("intent", {})
    intent_name = intent.get("name", "").strip() if intent.get("name") else ""
    
    if not intent_name:
        logger.error(f"Missing intent name in Luma response for user {user_id}")
        # Extract facts container even for error cases
        facts = {
            "slots": luma_response.get("slots", {}),
            "missing_slots": luma_response.get("missing_slots", []),
            "context": luma_response.get("context", {})
        }
        return {
            "error": "missing_intent",
            "message": "Intent name is missing from Luma response",
            "plan": {
                "status": "NEEDS_CLARIFICATION",
                "allowed_actions": [],
                "blocked_actions": [],
                "awaiting": None
            },
            "facts": facts
        }
    
    # CRITICAL: Normalize slots BEFORE filtering and plan building
    # SLOT NORMALIZATION: Extract time from all possible sources and write to slots["time"]
    # This ensures resolved time expressions (noon, morning, 3pm, etc.) are written to slots["time"] before filtering
    # Planning must rely only on slots, never context
    slots_for_filtering = luma_response.get("slots", {})
    if not isinstance(slots_for_filtering, dict):
        slots_for_filtering = {}
    
    # Normalize time: extract from multiple sources if not in slots
    # Priority: 1) slots.time (already there), 2) context.time_constraint, 3) trace/semantic data
    # Handle both string time_constraint and dict time_constraint with start/mode fields
    if "time" not in slots_for_filtering or not slots_for_filtering.get("time"):
        time_value = None
        time_mode = None
        
        # Helper to extract time from time_constraint (handles both string and dict)
        def _extract_time_from_constraint(time_constraint_obj, source_name: str):
            """Extract time value from time_constraint (string or dict with start/mode).
            
            Handles multiple formats:
            - String: "12:00" -> "12:00"
            - Dict with start: {"start": "12:00", "mode": "exact"} -> "12:00"
            - Dict with value: {"value": "12:00", "mode": "exact"} -> "12:00"
            - Dict with time: {"time": "12:00", "mode": "exact"} -> "12:00"
            """
            if not time_constraint_obj:
                return None, None
            
            # If time_constraint is a string, use it directly
            if isinstance(time_constraint_obj, str):
                logger.debug(f"Extracting time from {source_name}: string value={time_constraint_obj}")
                return time_constraint_obj, None
            
            # If time_constraint is a dict, extract based on mode
            if isinstance(time_constraint_obj, dict):
                constraint_mode = time_constraint_obj.get("mode", "")
                constraint_start = time_constraint_obj.get("start")
                
                # For exact mode, use start (e.g., "12:00" for "noon")
                if constraint_mode == "exact" and constraint_start:
                    logger.debug(f"Extracting time from {source_name}: mode=exact, start={constraint_start}")
                    return constraint_start, "exact"
                
                # For other modes or if start exists, use start
                if constraint_start:
                    logger.debug(f"Extracting time from {source_name}: start={constraint_start}, mode={constraint_mode}")
                    return constraint_start, constraint_mode
                
                # Fallback: check for "value" field (some formats use "value" instead of "start")
                constraint_value = time_constraint_obj.get("value")
                if constraint_value:
                    logger.debug(f"Extracting time from {source_name}: value={constraint_value}, mode={constraint_mode}")
                    return constraint_value, constraint_mode
                
                # Fallback: check for direct time value
                if "time" in time_constraint_obj:
                    time_val = time_constraint_obj["time"]
                    logger.debug(f"Extracting time from {source_name}: time field={time_val}, mode={constraint_mode}")
                    return time_val, constraint_mode
            
            return None, None
        
        # Check context.time_constraint (most common for resolved expressions like "noon", "morning")
        context = luma_response.get("context", {})
        if isinstance(context, dict):
            time_constraint = context.get("time_constraint")
            if time_constraint:
                extracted_time, extracted_mode = _extract_time_from_constraint(time_constraint, "context.time_constraint")
                if extracted_time:
                    time_value = extracted_time
                    time_mode = extracted_mode or context.get("time_mode")
                    logger.debug(f"Normalized time from context.time_constraint to slots.time: {time_value} (mode={time_mode})")
        
        # Fallback: Check trace.semantic.time_constraint
        if not time_value:
            trace = luma_response.get("trace", {})
            if isinstance(trace, dict):
                semantic = trace.get("semantic", {})
                if isinstance(semantic, dict):
                    time_constraint = semantic.get("time_constraint")
                    if time_constraint:
                        extracted_time, extracted_mode = _extract_time_from_constraint(time_constraint, "trace.semantic.time_constraint")
                        if extracted_time:
                            time_value = extracted_time
                            time_mode = extracted_mode or semantic.get("time_mode")
                            logger.debug(f"Normalized time from trace.semantic.time_constraint to slots.time: {time_value} (mode={time_mode})")
        
        # Fallback: Check stages for semantic data
        if not time_value:
            stages = luma_response.get("stages", [])
            if isinstance(stages, list):
                for stage in stages:
                    if isinstance(stage, dict):
                        semantic = stage.get("semantic", {})
                        if isinstance(semantic, dict):
                            time_constraint = semantic.get("time_constraint")
                            if time_constraint:
                                extracted_time, extracted_mode = _extract_time_from_constraint(time_constraint, "stages[].semantic.time_constraint")
                                if extracted_time:
                                    time_value = extracted_time
                                    time_mode = extracted_mode or semantic.get("time_mode")
                                    logger.debug(f"Normalized time from stages[].semantic.time_constraint to slots.time: {time_value} (mode={time_mode})")
                                    break
        
        # Write normalized time to slots
        if time_value:
            slots_for_filtering["time"] = time_value
            # Update luma_response slots to include normalized time
            luma_response["slots"] = slots_for_filtering
            logger.info(f"Temporal slot normalization: promoted time={time_value} from context to slots before filtering (mode={time_mode})")
    
    # CRITICAL: Get missing_slots from merged response (computed by session merge)
    # ARCHITECTURAL INVARIANT: missing_slots is computed exactly once per turn in session merge
    # missing_slots MUST NOT be recomputed or extracted from Luma issues here
    # missing_slots = [] is VALID and means all required slots are satisfied
    raw_missing_slots = None
    if "missing_slots" in luma_response:
        merged_missing = luma_response.get("missing_slots")
        if isinstance(merged_missing, list):
            # Use merged missing_slots (computed from intent contract) - authoritative
            raw_missing_slots = merged_missing
            logger.debug(f"[PRE_PLAN] Using merged missing_slots from luma_response: {raw_missing_slots}")
    
    # INVARIANT CHECK: missing_slots must be a list (never None after merge)
    if raw_missing_slots is None:
        # This should never happen if merge ran correctly
        logger.error(
            f"[MISSING_SLOTS] VIOLATION: missing_slots is None in process_luma_response! "
            f"user_id={user_id}, luma_response_keys={list(luma_response.keys())}"
        )
        # Fail-safe: use empty list (but this indicates a bug)
        raw_missing_slots = []
    
    # INVARIANT CHECK: missing_slots must be a list
    assert isinstance(raw_missing_slots, list), (
        f"missing_slots must be a list, got {type(raw_missing_slots)}: {raw_missing_slots}"
    )
    
    # CRITICAL: Do NOT filter missing_slots - use the missing_slots computed in merge directly
    # ARCHITECTURAL INVARIANT: missing_slots = REQUIRED_SLOTS(intent) - session.slots.keys()
    # A slot is satisfied ONLY if it exists in session.slots under its exact slot name
    # - time does NOT satisfy date
    # - date does NOT satisfy time
    # - start_date does NOT satisfy end_date
    # - date_range satisfies NOTHING unless explicitly promoted
    # No inference, no type-based satisfaction, no sibling slot satisfaction
    # The missing_slots computed in merge are already correct - use them directly
    
    luma_response_for_plan = luma_response.copy()
    # missing_slots is already computed correctly in merge - use it directly
    # No pre-plan filtering needed - raw_missing_slots is the authoritative value
    filtered_missing_slots_pre_plan = raw_missing_slots
    
    # DEBUG: Log extraction result and merged state RIGHT BEFORE build_plan
    print(f"\n[PRE_PLAN_DEBUG] user_id={user_id} RIGHT BEFORE build_plan:")
    print(f"  extraction_result.slots={luma_response_for_plan.get('slots', {})}")
    print(f"  extraction_result.context={luma_response_for_plan.get('context', {})}")
    context_debug = luma_response_for_plan.get('context', {})
    if isinstance(context_debug, dict):
        print(f"  context.time_constraint={context_debug.get('time_constraint')}")
        print(f"  context.time_ref={context_debug.get('time_ref')}")
        print(f"  context.time_mode={context_debug.get('time_mode')}")
    # Check trace/semantic
    trace_debug = luma_response_for_plan.get('trace', {})
    if isinstance(trace_debug, dict):
        semantic_debug = trace_debug.get('semantic', {})
        if isinstance(semantic_debug, dict):
            print(f"  trace.semantic.time_constraint={semantic_debug.get('time_constraint')}")
            print(f"  trace.semantic.time_mode={semantic_debug.get('time_mode')}")
    print(f"  merged_session_slots (after normalization)={list(slots_for_filtering.keys())}")
    print(f"  slots.time={slots_for_filtering.get('time')}")
    
    logger.info(
        f"[FILTER_DEBUG] Pre-plan filtering: raw={raw_missing_slots}, "
        f"filtered={filtered_missing_slots_pre_plan}, "
        f"slots_keys={list(slots_for_filtering.keys())}"
    )
    print(f"[FILTER_DEBUG] Pre-plan filtering: raw={raw_missing_slots}, filtered={filtered_missing_slots_pre_plan}, slots_keys={list(slots_for_filtering.keys())}")
    
    # DEBUG: Log extraction result RIGHT BEFORE build_plan
    # This helps trace where time expressions like "noon" are parsed
    print(f"[PRE_PLAN_DEBUG] user_id={user_id} RIGHT BEFORE build_plan:")
    print(f"  extraction_result.slots={slots_for_filtering}")
    context_debug = luma_response.get("context", {})
    print(f"  extraction_result.context.time_constraint={context_debug.get('time_constraint')}")
    print(f"  extraction_result.context.time_mode={context_debug.get('time_mode')}")
    print(f"  extraction_result.context.time_ref={context_debug.get('time_ref')}")
    # Check trace.semantic for time info
    trace_debug = luma_response.get("trace", {})
    if isinstance(trace_debug, dict):
        semantic_debug = trace_debug.get("semantic", {})
        if isinstance(semantic_debug, dict):
            print(f"  trace.semantic.time_constraint={semantic_debug.get('time_constraint')}")
            print(f"  trace.semantic.time_mode={semantic_debug.get('time_mode')}")
    # Check stages for semantic data
    stages_debug = luma_response.get("stages", [])
    if isinstance(stages_debug, list):
        for idx, stage in enumerate(stages_debug):
            if isinstance(stage, dict):
                semantic_stage = stage.get("semantic", {})
                if isinstance(semantic_stage, dict):
                    resolved_booking = semantic_stage.get("resolved_booking", {})
                    if isinstance(resolved_booking, dict):
                        print(f"  stages[{idx}].semantic.resolved_booking.time_constraint={resolved_booking.get('time_constraint')}")
                        print(f"  stages[{idx}].semantic.resolved_booking.time_mode={resolved_booking.get('time_mode')}")
    # Show merged slots after normalization
    print(f"  merged_session_slots_after_normalization={list(slots_for_filtering.keys())}")
    print(f"  merged_session_slots.time={slots_for_filtering.get('time')}")
    
    # Build decision plan with FILTERED missing_slots
    plan = _build_decision_plan(intent_name, luma_response_for_plan, domain)
    
    # Check if Luma indicates clarification is needed
    if luma_response.get("needs_clarification", False):
        reason = luma_response.get("clarification_reason", "")
        issues = luma_response.get("issues", {})
        context = luma_response.get("context", {})
        booking = luma_response.get("booking")
        clarification_data = luma_response.get("clarification_data")
        
        # Extract missing_slots from issues keys (keys where value is "missing")
        # BUT only if the slot is not actually satisfied in merged slots or booking
        slots = luma_response.get("slots", {})
        booking = luma_response.get("booking", {})
        missing_slots_from_issues = []
        if isinstance(issues, dict):
            for slot_name, slot_value in issues.items():
                if slot_value == "missing":
                    # Check if slot is actually satisfied in merged slots or booking
                    slot_satisfied = False
                    
                    # Direct slot match
                    if slot_name in slots:
                        slot_satisfied = True
                    # Service/service_id satisfaction mapping
                    elif slot_name == "service" or slot_name == "service_id":
                        # service is satisfied if service_id exists in slots OR services exist in booking
                        # Check both conditions explicitly (not elif) to be more robust
                        has_service_id = "service_id" in slots and slots.get("service_id") is not None
                        has_booking_services = (
                            isinstance(booking, dict) and 
                            isinstance(booking.get("services"), list) and 
                            len(booking.get("services", [])) > 0
                        )
                        if has_service_id or has_booking_services:
                            slot_satisfied = True
                            logger.debug(
                                f"Service slot satisfied (clarification path): service_id_in_slots={has_service_id}, "
                                f"booking_has_services={has_booking_services}, slots_keys={list(slots.keys())}"
                            )
                    # Date slot satisfaction mapping
                    elif slot_name == "date":
                        # date is satisfied if date, start_date, or date_range exists
                        if "date" in slots or "start_date" in slots or "date_range" in slots:
                            slot_satisfied = True
                    elif slot_name == "start_date":
                        # start_date is satisfied if start_date exists, OR if date exists and intent is CREATE_RESERVATION
                        if "start_date" in slots:
                            slot_satisfied = True
                        else:
                            # Check intent to see if this is a reservation
                            intent = luma_response.get("intent", {})
                            intent_name = intent.get("name", "") if isinstance(intent, dict) else ""
                            if intent_name == "CREATE_RESERVATION" and "date" in slots:
                                slot_satisfied = True
                    elif slot_name == "end_date" and "end_date" in slots:
                        slot_satisfied = True
                    elif slot_name == "time" and "time" in slots:
                        slot_satisfied = True
                    
                    # Only add to missing if not satisfied
                    if not slot_satisfied:
                        missing_slots_from_issues.append(slot_name)
                # For rich time issues, still consider "time" as missing if present
                elif slot_name == "time" and isinstance(slot_value, dict):
                    if "time" not in slots:
                        missing_slots_from_issues.append("time")
        
        # Extract facts container (passthrough data from Luma)
        # ARCHITECTURAL INVARIANT: Use merged missing_slots (computed by session merge)
        # Do NOT fallback to missing_slots_from_issues - missing_slots is a pure derived value
        merged_missing_slots = luma_response.get("missing_slots")
        if merged_missing_slots is not None and isinstance(merged_missing_slots, list):
            # Use merged missing_slots (computed by merge from intent contract + promoted slots)
            # This is authoritative - even if [] (means "no missing slots")
            facts_missing_slots = merged_missing_slots
            logger.info(
                f"[CLARIFY] Using merged missing_slots={facts_missing_slots} from luma_response (authoritative)")
        else:
            # This should never happen if merge ran correctly
            logger.error(
                f"[MISSING_SLOTS] VIOLATION: merged missing_slots not set in clarify path! "
                f"user_id={user_id}, merged_missing_slots={merged_missing_slots}"
            )
            # Fail-safe: use empty list (but this indicates a bug)
            facts_missing_slots = []
        
        facts = {
            "slots": slots,
            "missing_slots": facts_missing_slots,
            "context": context  # context is already extracted above
        }

        return {
            "outcome": _build_clarify_outcome(
                clarification_reason=reason,
                issues=issues,
                context=context,
                booking=booking,
                domain=domain,
                clarification_data=clarification_data,
                facts=facts,
                intent_name=intent_name
            ),
            "plan": plan,
            "facts": facts
        }

    # Get action name for handler mapping
    action_name = get_action_name(intent_name)

    if not action_name:
        logger.warning(
            f"Unsupported intent for user {user_id}: {intent_name!r} "
            f"(type: {type(intent_name).__name__})"
        )
        # Debug: log available intents for troubleshooting
        from core.routing.intent_router import INTENT_ACTIONS
        logger.debug(f"Available intents: {list(INTENT_ACTIONS.keys())}")
        # Extract facts container even for unsupported intent
        facts = {
            "slots": luma_response.get("slots", {}),
            "missing_slots": luma_response.get("missing_slots", []),
            "context": luma_response.get("context", {})
        }
        return {
            "error": "unsupported_intent",
            "message": f"Intent {intent_name} is not supported",
            "plan": plan,
            "facts": facts
        }

    # Return execution instruction with decision plan
    booking = luma_response.get("booking", {})
    
    # ARCHITECTURAL INVARIANT: Use merged missing_slots (computed by session merge)
    # Do NOT fallback to pre-filtered missing_slots - missing_slots is a pure derived value
    merged_missing_slots = luma_response.get("missing_slots")
    if merged_missing_slots is not None and isinstance(merged_missing_slots, list):
        # Use merged missing_slots (computed by merge from intent contract + promoted slots)
        # This is authoritative - even if [] (means "no missing slots")
        filtered_missing_slots = merged_missing_slots
        logger.info(
            f"[FILTER_DEBUG] Non-clarification path: using merged missing_slots={filtered_missing_slots} from luma_response")
    else:
        # This should never happen if merge ran correctly
        logger.error(
            f"[MISSING_SLOTS] VIOLATION: merged missing_slots not set in non-clarification path! "
            f"user_id={user_id}, merged_missing_slots={merged_missing_slots}"
        )
        # Fail-safe: use empty list (but this indicates a bug)
        filtered_missing_slots = []
    
    # Get slots (raw slots only - promotion happens in-memory for missing_slots computation)
    # Use raw slots from merged response, not promoted slots
    slots = slots_for_filtering.copy()  # Use the slots we filtered with (raw slots only)
    booking = luma_response.get("booking", {})
    
    logger.info(
        f"[FILTER_DEBUG] Non-clarification path: final missing_slots={filtered_missing_slots}, "
        f"slots_keys={list(slots.keys())}"
    )
    print(f"[FILTER_DEBUG] Non-clarification path: filtered_missing_slots={filtered_missing_slots}, slots_keys={list(slots.keys())}, booking_services={booking.get('services') if isinstance(booking, dict) else None}")
    
    # Update luma_response slots with extracted service_id (if we extracted it from booking)
    # This ensures service_id is available for downstream processing
    if "service_id" in slots and "slots" in luma_response:
        luma_response["slots"] = slots
    
    facts = {
        "slots": slots,
        "missing_slots": filtered_missing_slots,
        "context": luma_response.get("context", {})
    }
    
    # Add debug info to facts for troubleshooting
    facts["_debug"] = {
        "original_missing_slots": raw_missing_slots,
        "filtered_missing_slots": filtered_missing_slots,
        "slots_keys": list(slots.keys()),
        "booking_has_services": (
            isinstance(booking, dict) and 
            isinstance(booking.get("services"), list) and 
            len(booking.get("services", [])) > 0
        ),
        "service_id_in_slots": "service_id" in slots,
        "service_id_value": slots.get("service_id")
    }
    
    return {
        "intent_name": intent_name,
        "action_name": action_name,
        "booking": booking,
        "plan": plan,
        "facts": facts
    }


def build_clarify_outcome_from_reason(
    reason: str,
    issues: Dict[str, Any],
    booking: Optional[Dict[str, Any]],
    domain: str,
    facts: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Build a CLARIFY outcome from a core-initiated clarification reason.

    Used when orchestrator detects clarification needs during service/room/extras resolution.

    Args:
        reason: Clarification reason (e.g., "MISSING_SERVICE")
        issues: Issues dict (e.g., {"service": "missing"})
        booking: Optional booking payload
        domain: Domain for template key routing
        facts: Optional facts container with slots, missing_slots, context (for rendering)

    Returns:
        Complete CLARIFY outcome dictionary ready to return
    """
    template_key = get_template_key(reason, domain)

    # Extract structured clarification data
    clarification_data = _extract_clarification_data(reason, issues)

    # Derive canonical clarification_reason from missing slots
    # This is the top-level field that tests expect
    missing_slots = clarification_data.get("missing", [])
    canonical_reason = _derive_clarification_reason_from_missing_slots(missing_slots)

    outcome = {
        "status": "NEEDS_CLARIFICATION",
        "clarification_reason": canonical_reason,  # Top-level canonical reason derived from missing slots
        "template_key": template_key,
        "data": clarification_data,
        "booking": booking
    }
    
    # Include facts if provided (needed for renderer to access slots)
    if facts:
        outcome["facts"] = facts

    return {
        "success": True,
        "outcome": outcome
    }
