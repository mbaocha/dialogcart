"""
Session Merge Helper

Merges session state with Luma response for follow-up handling.

This module provides pure functions for merging session state without
changing core logic.
"""

from typing import Dict, Any, Optional


def merge_luma_with_session(
    luma_response: Dict[str, Any],
    session_state: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Merge Luma response with session state for follow-up handling.
    
    Merge rules (STRICT):
    1. Override intent FIRST (before any processing)
    2. Extract slots from Luma slots dict AND semantic fields
    3. Start with session slots, merge new entities from Luma (do NOT overwrite existing session values)
    4. Merge missing_slots as: new_missing = old_missing - filled_slots
    
    Args:
        luma_response: Luma API response (may contain newly extracted entities even if intent=UNKNOWN)
        session_state: Session state from previous turn (only passed when status == "NEEDS_CLARIFICATION")
        
    Returns:
        Modified Luma response with merged slots and session intent (ready for process_luma_response)
    """
    # Create a copy to avoid mutating the original
    merged = luma_response.copy()
    
    # STEP 1: Override intent FIRST (before any processing)
    # Session intent takes precedence because Luma is stateless, may return UNKNOWN on follow-ups
    session_intent = session_state.get("intent")
    if session_intent:
        # Always use session intent (convert to dict format if string)
        if isinstance(session_intent, str):
            merged["intent"] = {"name": session_intent}
        elif isinstance(session_intent, dict):
            merged["intent"] = session_intent.copy()
    
    # STEP 2: Extract slots from Luma response
    # First, get slots from luma_response.slots (if present)
    luma_slots = merged.get("slots", {}).copy()
    if not isinstance(luma_slots, dict):
        luma_slots = {}
    
    # Extract semantic fields for slot extraction (when slots is empty/partial)
    # Look for semantic data in stages.semantic.resolved_booking
    stages = merged.get("stages", {})
    semantic_data = None
    if isinstance(stages, dict):
        semantic_stage = stages.get("semantic", {})
        if isinstance(semantic_stage, dict):
            semantic_data = semantic_stage.get("resolved_booking", {})
    
    # Expand slot extraction: derive slots from semantic fields when slots is empty/partial
    if isinstance(semantic_data, dict):
        date_refs = semantic_data.get("date_refs", [])
        date_mode = semantic_data.get("date_mode", "")
        time_constraint = semantic_data.get("time_constraint")
        time_mode = semantic_data.get("time_mode", "")
        
        # If date_refs exists and date_mode == single_day → slots.date
        if date_refs and date_mode == "single_day" and "date" not in luma_slots:
            # Use first date_ref as the date value
            if isinstance(date_refs, list) and len(date_refs) > 0:
                luma_slots["date"] = date_refs[0]
        
        # If date_mode == range → slots.date_range
        if date_mode == "range" and "date_range" not in luma_slots:
            # For range, we might need to construct from date_refs
            # For now, set a placeholder that indicates range mode
            if date_refs and isinstance(date_refs, list):
                luma_slots["date_range"] = date_refs
        
        # If time_constraint exists → slots.time
        if time_constraint and "time" not in luma_slots:
            luma_slots["time"] = time_constraint
    
    # STEP 3: Merge slots: Start with session slots, then merge new entities from Luma
    session_slots = session_state.get("slots", {})
    if not isinstance(session_slots, dict):
        session_slots = {}
    
    # Do NOT overwrite existing session values (Luma entities are delta updates)
    merged_slots = session_slots.copy()
    
    # Merge all slots from Luma into session slots (only if not already set)
    for key, value in luma_slots.items():
        if key not in merged_slots:
            # Only add if not already in session (don't overwrite)
            merged_slots[key] = value
    
    # Update merged response with merged slots
    merged["slots"] = merged_slots
    
    # STEP 4: Handle missing_slots: new_missing = old_missing - filled_slots
    session_missing = session_state.get("missing_slots", [])
    if not isinstance(session_missing, list):
        session_missing = []
    
    # Get slots that were filled in current request (present in merged_slots but not in session_slots)
    filled_slots = set(merged_slots.keys()) - set(session_slots.keys())
    
    # Remove filled slots from session missing_slots
    new_missing = [slot for slot in session_missing if slot not in filled_slots]
    
    # Add any missing slots from current Luma response
    current_missing = merged.get("missing_slots", [])
    if isinstance(current_missing, list):
        for slot in current_missing:
            if slot not in new_missing:
                new_missing.append(slot)
    
    merged["missing_slots"] = new_missing
    
    return merged


# Backward compatibility alias
merge_session_with_luma_response = merge_luma_with_session


def build_session_state_from_outcome(
    outcome: Dict[str, Any],
    outcome_status: str,
    merged_luma_response: Optional[Dict[str, Any]] = None
) -> Optional[Dict[str, Any]]:
    """
    Build session state from outcome and merged Luma response.
    
    Args:
        outcome: Outcome dictionary from handle_message
        outcome_status: Outcome status ("READY" | "NEEDS_CLARIFICATION" | "AWAITING_CONFIRMATION")
        merged_luma_response: Optional merged Luma response (for extracting intent)
        
    Returns:
        Session state dictionary or None if status is READY
    """
    if outcome_status == "READY":
        return None
    
    # Extract facts (contains slots, missing_slots)
    facts = outcome.get("facts", {})
    if not isinstance(facts, dict):
        facts = {}
    
    # Extract slots from facts
    slots = facts.get("slots", {})
    if not isinstance(slots, dict):
        slots = {}
    
    # Extract missing_slots from facts or data.missing
    missing_slots = facts.get("missing_slots", [])
    if not isinstance(missing_slots, list):
        missing_slots = []
    
    # Also check data.missing (clarification outcomes)
    data = outcome.get("data", {})
    if isinstance(data, dict) and "missing" in data:
        data_missing = data.get("missing", [])
        if isinstance(data_missing, list):
            for slot in data_missing:
                if slot not in missing_slots:
                    missing_slots.append(slot)
    
    # Extract intent - prefer from merged Luma response, fallback to outcome
    intent_name = ""
    
    # Try merged Luma response first (most reliable)
    if merged_luma_response:
        intent_obj = merged_luma_response.get("intent", {})
        if isinstance(intent_obj, dict):
            intent_name = intent_obj.get("name", "")
        elif isinstance(intent_obj, str):
            intent_name = intent_obj
    
    # Fallback to outcome intent_name (for non-core intents)
    if not intent_name and "intent_name" in outcome:
        intent_name = outcome.get("intent_name", "")
    
    # Determine status
    status = "NEEDS_CLARIFICATION" if outcome_status in ("NEEDS_CLARIFICATION", "AWAITING_CONFIRMATION") else "READY"
    
    return {
        "intent": intent_name,
        "slots": slots,
        "missing_slots": missing_slots,
        "status": status
    }
