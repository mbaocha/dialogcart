"""
Routing Layer

Maps semantic signals (clarification reasons, intent names) to internal identifiers
(template keys, action names).

This layer contains pure decision tables with no side effects, no execution,
and no rendering logic.
"""

from core.routing.clarification_router import get_template_key
from core.routing.intent_router import get_action_name

__all__ = ["get_template_key", "get_action_name"]

