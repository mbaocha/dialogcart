"""
Core Configuration Package

Contains configuration files and loaders for dialogcart-core.
"""

