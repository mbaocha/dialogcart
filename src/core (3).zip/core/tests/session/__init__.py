"""
Session tests for Core follow-up behavior.
"""
