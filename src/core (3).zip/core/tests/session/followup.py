"""
Core Session Follow-up Scenarios

Multi-turn conversation scenarios to test Redis-backed session behavior.
Each scenario tests session persistence, merge, and cleanup across turns.

50 scenarios covering:
- service → date → time follow-ups
- service → time → date follow-ups
- reservation check-in → check-out completion
- modify booking (time, date, range)
- ambiguous follow-ups ("tomorrow", "evening", "next friday")
- UNKNOWN → becomes booking via follow-up
- follow-up that switches intent (should reset session)
"""

followup_scenarios = [
    # Service appointment scenarios: service → date → time (IDs 1-10)
    {
        "id": 1,
        "name": "service_to_date_to_time",
        "domain": "service",
        "aliases": {"haircut": "haircut"},
        "turns": [
            {"sentence": "book a haircut", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "tomorrow", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["time"]}},
            {"sentence": "11am", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 2,
        "name": "service_to_date_to_time_massage",
        "domain": "service",
        "aliases": {"massage": "massage"},
        "turns": [
            {"sentence": "book massage", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "friday", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["time"]}},
            {"sentence": "3pm", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 3,
        "name": "service_to_date_to_time_facial",
        "domain": "service",
        "aliases": {"facial": "facial"},
        "turns": [
            {"sentence": "schedule facial", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "next monday", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["time"]}},
            {"sentence": "10am", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 4,
        "name": "service_to_date_to_time_waxing",
        "domain": "service",
        "aliases": {"waxing": "waxing"},
        "turns": [
            {"sentence": "book waxing", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "saturday", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["time"]}},
            {"sentence": "2pm", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 5,
        "name": "service_to_date_to_time_manicure",
        "domain": "service",
        "aliases": {"manicure": "manicure"},
        "turns": [
            {"sentence": "i need a manicure", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "next week", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["time"]}},
            {"sentence": "4pm", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 6,
        "name": "service_to_date_to_time_pedicure",
        "domain": "service",
        "aliases": {"pedicure": "pedicure"},
        "turns": [
            {"sentence": "book pedicure", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "this weekend", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["time"]}},
            {"sentence": "11am", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 7,
        "name": "service_to_date_to_time_eyebrow",
        "domain": "service",
        "aliases": {"eyebrow": "eyebrow"},
        "turns": [
            {"sentence": "schedule eyebrow", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "wednesday", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["time"]}},
            {"sentence": "1pm", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 8,
        "name": "service_to_date_to_time_coloring",
        "domain": "service",
        "aliases": {"coloring": "coloring"},
        "turns": [
            {"sentence": "book coloring", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "next thursday", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["time"]}},
            {"sentence": "9am", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 9,
        "name": "service_to_date_to_time_highlight",
        "domain": "service",
        "aliases": {"highlight": "highlight"},
        "turns": [
            {"sentence": "i want highlights", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "next friday", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["time"]}},
            {"sentence": "noon", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 10,
        "name": "service_to_date_to_time_cut",
        "domain": "service",
        "aliases": {"cut": "cut"},
        "turns": [
            {"sentence": "book a cut", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "tuesday", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["time"]}},
            {"sentence": "5pm", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    # Service appointment scenarios: service → time → date (IDs 11-20)
    {
        "id": 11,
        "name": "service_to_time_to_date",
        "domain": "service",
        "aliases": {"massage": "massage"},
        "turns": [
            {"sentence": "book massage at 2pm", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date"]}},
            {"sentence": "tomorrow", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 12,
        "name": "service_to_time_to_date_haircut",
        "domain": "service",
        "aliases": {"haircut": "haircut"},
        "turns": [
            {"sentence": "book haircut at 10am", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date"]}},
            {"sentence": "friday", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 13,
        "name": "service_to_time_to_date_facial",
        "domain": "service",
        "aliases": {"facial": "facial"},
        "turns": [
            {"sentence": "schedule facial for 3pm", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date"]}},
            {"sentence": "next monday", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 14,
        "name": "service_to_time_to_date_morning",
        "domain": "service",
        "aliases": {"massage": "massage"},
        "turns": [
            {"sentence": "book massage at 9am", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date"]}},
            {"sentence": "saturday", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 15,
        "name": "service_to_time_to_date_evening",
        "domain": "service",
        "aliases": {"haircut": "haircut"},
        "turns": [
            {"sentence": "book haircut at 6pm", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date"]}},
            {"sentence": "tuesday", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 16,
        "name": "service_to_time_to_date_noon",
        "domain": "service",
        "aliases": {"manicure": "manicure"},
        "turns": [
            {"sentence": "book manicure at noon", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date"]}},
            {"sentence": "next week", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 17,
        "name": "service_to_time_to_date_afternoon",
        "domain": "service",
        "aliases": {"pedicure": "pedicure"},
        "turns": [
            {"sentence": "book pedicure at 4pm", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date"]}},
            {"sentence": "wednesday", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 18,
        "name": "service_to_time_to_date_midday",
        "domain": "service",
        "aliases": {"waxing": "waxing"},
        "turns": [
            {"sentence": "schedule waxing at 1pm", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date"]}},
            {"sentence": "thursday", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 19,
        "name": "service_to_time_to_date_early",
        "domain": "service",
        "aliases": {"facial": "facial"},
        "turns": [
            {"sentence": "book facial at 8am", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date"]}},
            {"sentence": "next friday", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 20,
        "name": "service_to_time_to_date_late",
        "domain": "service",
        "aliases": {"massage": "massage"},
        "turns": [
            {"sentence": "book massage at 7pm", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date"]}},
            {"sentence": "this weekend", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    # Reservation scenarios: check-in → check-out (IDs 21-30)
    {
        "id": 21,
        "name": "reservation_checkin_to_checkout",
        "domain": "reservation",
        "aliases": {"room": "room"},
        "turns": [
            {"sentence": "reserve a room", "expected": {"intent": "CREATE_RESERVATION", "status": "NEEDS_CLARIFICATION", "missing_slots": ["start_date", "end_date"]}},
            {"sentence": "from october 5th", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["end_date"]}},
            {"sentence": "to october 9th", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 22,
        "name": "reservation_suite_checkin_checkout",
        "domain": "reservation",
        "aliases": {"suite": "room"},
        "turns": [
            {"sentence": "book suite", "expected": {"intent": "CREATE_RESERVATION", "status": "NEEDS_CLARIFICATION", "missing_slots": ["start_date", "end_date"]}},
            {"sentence": "from nov 1st", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["end_date"]}},
            {"sentence": "to nov 5th", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 23,
        "name": "reservation_deluxe_checkin_checkout",
        "domain": "reservation",
        "aliases": {"deluxe": "room"},
        "turns": [
            {"sentence": "reserve deluxe room", "expected": {"intent": "CREATE_RESERVATION", "status": "NEEDS_CLARIFICATION", "missing_slots": ["start_date", "end_date"]}},
            {"sentence": "from dec 10th", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["end_date"]}},
            {"sentence": "through dec 15th", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 24,
        "name": "reservation_standard_checkin_checkout",
        "domain": "reservation",
        "aliases": {"standard": "room"},
        "turns": [
            {"sentence": "book standard room", "expected": {"intent": "CREATE_RESERVATION", "status": "NEEDS_CLARIFICATION", "missing_slots": ["start_date", "end_date"]}},
            {"sentence": "from jan 5th", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["end_date"]}},
            {"sentence": "until jan 8th", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 25,
        "name": "reservation_penthouse_checkin_checkout",
        "domain": "reservation",
        "aliases": {"penthouse": "room"},
        "turns": [
            {"sentence": "reserve penthouse", "expected": {"intent": "CREATE_RESERVATION", "status": "NEEDS_CLARIFICATION", "missing_slots": ["start_date", "end_date"]}},
            {"sentence": "from feb 1st", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["end_date"]}},
            {"sentence": "to feb 5th", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 26,
        "name": "reservation_range_followup",
        "domain": "reservation",
        "aliases": {"room": "room"},
        "turns": [
            {"sentence": "book room", "expected": {"intent": "CREATE_RESERVATION", "status": "NEEDS_CLARIFICATION", "missing_slots": ["start_date", "end_date"]}},
            {"sentence": "march 10 to 15", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 27,
        "name": "reservation_suite_range",
        "domain": "reservation",
        "aliases": {"suite": "room"},
        "turns": [
            {"sentence": "book suite", "expected": {"intent": "CREATE_RESERVATION", "status": "NEEDS_CLARIFICATION", "missing_slots": ["start_date", "end_date"]}},
            {"sentence": "april 1st to 3rd", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 28,
        "name": "reservation_deluxe_range",
        "domain": "reservation",
        "aliases": {"deluxe": "room"},
        "turns": [
            {"sentence": "reserve deluxe", "expected": {"intent": "CREATE_RESERVATION", "status": "NEEDS_CLARIFICATION", "missing_slots": ["start_date", "end_date"]}},
            {"sentence": "may 20 to 25", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 29,
        "name": "reservation_standard_range",
        "domain": "reservation",
        "aliases": {"standard": "room"},
        "turns": [
            {"sentence": "book standard", "expected": {"intent": "CREATE_RESERVATION", "status": "NEEDS_CLARIFICATION", "missing_slots": ["start_date", "end_date"]}},
            {"sentence": "june 1 to 5", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    {
        "id": 30,
        "name": "reservation_multi_turn_range",
        "domain": "reservation",
        "aliases": {"room": "room"},
        "turns": [
            {"sentence": "reserve room", "expected": {"intent": "CREATE_RESERVATION", "status": "NEEDS_CLARIFICATION", "missing_slots": ["start_date", "end_date"]}},
            {"sentence": "from july 1", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["end_date"]}},
            {"sentence": "to july 7", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    },
    # Modify booking scenarios (IDs 31-40)
    {
        "id": 31,
        "name": "modify_booking_time_only",
        "domain": "service",
        "aliases": {"haircut": "haircut"},
        "turns": [
            {"sentence": "change my booking to 3pm", "expected": {"intent": "MODIFY_BOOKING", "status": "NEEDS_CLARIFICATION", "missing_slots": ["booking_id"]}},
            {"sentence": "booking abc123", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 32,
        "name": "modify_booking_date_only",
        "domain": "service",
        "aliases": {"massage": "massage"},
        "turns": [
            {"sentence": "change booking to friday", "expected": {"intent": "MODIFY_BOOKING", "status": "NEEDS_CLARIFICATION", "missing_slots": ["booking_id"]}},
            {"sentence": "booking xyz789", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 33,
        "name": "modify_booking_date_range",
        "domain": "reservation",
        "aliases": {"suite": "room"},
        "turns": [
            {"sentence": "change my reservation", "expected": {"intent": "MODIFY_BOOKING", "status": "NEEDS_CLARIFICATION", "missing_slots": ["booking_id"]}},
            {"sentence": "reservation def456 to nov 1st to 5th", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 34,
        "name": "modify_booking_time_followup",
        "domain": "service",
        "aliases": {"haircut": "haircut"},
        "turns": [
            {"sentence": "change booking", "expected": {"intent": "MODIFY_BOOKING", "status": "NEEDS_CLARIFICATION", "missing_slots": ["booking_id"]}},
            {"sentence": "booking 123 to 4pm", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 35,
        "name": "modify_booking_date_followup",
        "domain": "service",
        "aliases": {"massage": "massage"},
        "turns": [
            {"sentence": "modify booking", "expected": {"intent": "MODIFY_BOOKING", "status": "NEEDS_CLARIFICATION", "missing_slots": ["booking_id"]}},
            {"sentence": "booking 456 to monday", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 36,
        "name": "modify_reservation_range",
        "domain": "reservation",
        "aliases": {"room": "room"},
        "turns": [
            {"sentence": "change reservation", "expected": {"intent": "MODIFY_BOOKING", "status": "NEEDS_CLARIFICATION", "missing_slots": ["booking_id"]}},
            {"sentence": "reservation 789 to dec 1 to 5", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 37,
        "name": "modify_booking_with_id",
        "domain": "service",
        "aliases": {"haircut": "haircut"},
        "turns": [
            {"sentence": "change booking abc123", "expected": {"intent": "MODIFY_BOOKING", "status": "NEEDS_CLARIFICATION", "missing_slots": ["change"]}},
            {"sentence": "to 5pm", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 38,
        "name": "modify_reservation_with_id",
        "domain": "reservation",
        "aliases": {"suite": "room"},
        "turns": [
            {"sentence": "change reservation xyz789", "expected": {"intent": "MODIFY_BOOKING", "status": "NEEDS_CLARIFICATION", "missing_slots": ["change"]}},
            {"sentence": "to jan 10 to 15", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 39,
        "name": "modify_booking_multiple_turns",
        "domain": "service",
        "aliases": {"massage": "massage"},
        "turns": [
            {"sentence": "change booking", "expected": {"intent": "MODIFY_BOOKING", "status": "NEEDS_CLARIFICATION", "missing_slots": ["booking_id"]}},
            {"sentence": "booking 111", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["change"]}},
            {"sentence": "time to 2pm", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 40,
        "name": "modify_reservation_multiple_turns",
        "domain": "reservation",
        "aliases": {"room": "room"},
        "turns": [
            {"sentence": "change reservation", "expected": {"intent": "MODIFY_BOOKING", "status": "NEEDS_CLARIFICATION", "missing_slots": ["booking_id"]}},
            {"sentence": "reservation 222", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["change"]}},
            {"sentence": "dates to feb 1 to 5", "expected": {"status": "READY"}}
        ]
    },
    # Ambiguous follow-ups and edge cases (IDs 41-50)
    {
        "id": 41,
        "name": "ambiguous_tomorrow_followup",
        "domain": "service",
        "aliases": {"haircut": "haircut"},
        "turns": [
            {"sentence": "book haircut", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "tomorrow", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["time"]}},
            {"sentence": "evening", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 42,
        "name": "ambiguous_next_friday",
        "domain": "service",
        "aliases": {"massage": "massage"},
        "turns": [
            {"sentence": "schedule massage", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "next friday", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["time"]}},
            {"sentence": "2pm", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 43,
        "name": "ambiguous_evening_followup",
        "domain": "service",
        "aliases": {"facial": "facial"},
        "turns": [
            {"sentence": "book facial", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "evening", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["date"]}},
            {"sentence": "tomorrow", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 44,
        "name": "ambiguous_morning_followup",
        "domain": "service",
        "aliases": {"haircut": "haircut"},
        "turns": [
            {"sentence": "book haircut", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "morning", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["date"]}},
            {"sentence": "friday", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 45,
        "name": "unknown_to_booking_via_followup",
        "domain": "service",
        "aliases": {"haircut": "haircut"},
        "turns": [
            {"sentence": "hello", "expected": {"status": "NEEDS_CLARIFICATION"}},
            {"sentence": "book a haircut", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "tomorrow at 10am", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 46,
        "name": "intent_switch_resets_session",
        "domain": "service",
        "aliases": {"haircut": "haircut"},
        "turns": [
            {"sentence": "book haircut", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "cancel my booking", "expected": {"intent": "CANCEL_BOOKING", "status": "NEEDS_CLARIFICATION", "missing_slots": ["booking_id"]}},
            {"sentence": "booking abc123", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 47,
        "name": "intent_switch_modify_to_cancel",
        "domain": "service",
        "aliases": {"massage": "massage"},
        "turns": [
            {"sentence": "change booking", "expected": {"intent": "MODIFY_BOOKING", "status": "NEEDS_CLARIFICATION", "missing_slots": ["booking_id"]}},
            {"sentence": "actually cancel it", "expected": {"intent": "CANCEL_BOOKING", "status": "NEEDS_CLARIFICATION", "missing_slots": ["booking_id"]}},
            {"sentence": "booking xyz789", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 48,
        "name": "intent_switch_create_to_cancel",
        "domain": "service",
        "aliases": {"facial": "facial"},
        "turns": [
            {"sentence": "book facial", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "nevermind cancel", "expected": {"intent": "CANCEL_BOOKING", "status": "NEEDS_CLARIFICATION", "missing_slots": ["booking_id"]}},
            {"sentence": "booking 999", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 49,
        "name": "multi_turn_ambiguous_followup",
        "domain": "service",
        "aliases": {"waxing": "waxing"},
        "turns": [
            {"sentence": "book waxing", "expected": {"intent": "CREATE_APPOINTMENT", "status": "NEEDS_CLARIFICATION", "missing_slots": ["date", "time"]}},
            {"sentence": "next week", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["time"]}},
            {"sentence": "morning", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["date"]}},
            {"sentence": "monday", "expected": {"status": "READY"}}
        ]
    },
    {
        "id": 50,
        "name": "reservation_ambiguous_followup",
        "domain": "reservation",
        "aliases": {"room": "room"},
        "turns": [
            {"sentence": "book room", "expected": {"intent": "CREATE_RESERVATION", "status": "NEEDS_CLARIFICATION", "missing_slots": ["start_date", "end_date"]}},
            {"sentence": "next month", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["start_date", "end_date"]}},
            {"sentence": "from the 1st", "expected": {"status": "NEEDS_CLARIFICATION", "missing_slots": ["end_date"]}},
            {"sentence": "to the 5th", "expected": {"status": "READY", "slots": {"has_datetime": True}}}
        ]
    }
]

