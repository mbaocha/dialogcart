"""
Reservation Intent Resolver

Rule-based intent resolution for service/appointment/reservation booking.
Replaces legacy ML-based intent mapping with deterministic, explainable rules.

Determines user intent from:
- Extracted entities (services, dates, times, durations)
- Lexical cues (cancel, reschedule, etc.) loaded from config

NO ML. NO embeddings. NO NER dependency.
"""
import re
from pathlib import Path
from typing import Tuple, Dict, Any, List, Set

import yaml


# Canonical intents (locked - 10 production intents)
DISCOVERY = "DISCOVERY"
DETAILS = "DETAILS"
AVAILABILITY = "AVAILABILITY"
QUOTE = "QUOTE"
RECOMMENDATION = "RECOMMENDATION"
CREATE_BOOKING = "CREATE_BOOKING"
BOOKING_INQUIRY = "BOOKING_INQUIRY"
MODIFY_BOOKING = "MODIFY_BOOKING"
CANCEL_BOOKING = "CANCEL_BOOKING"
PAYMENT = "PAYMENT"
UNKNOWN = "UNKNOWN"

# Confidence scores (heuristic)
HIGH_CONFIDENCE = 0.95
MEDIUM_CONFIDENCE = 0.85
LOW_CONFIDENCE = 0.75


class ReservationIntentResolver:
    """
    Rule-based intent resolver for appointment/reservation booking.

    Uses ordered rules (first match wins) to determine user intent.
    Deterministic, explainable, and fast.
    """

    def __init__(self):
        """Initialize intent resolver with configuration-driven signals."""
        self.intent_signals = self._load_intent_signals()

        # Booking verbs (for CREATE_BOOKING)
        self.booking_verbs = {
            "book", "schedule", "reserve", "appointment", "appoint",
            "set", "arrange", "plan", "make",
            "need", "want", "look", "looking", "get",
            "recommend", "suggest"
        }

    def resolve_intent(
        self,
        osentence: str,
        entities: Dict[str, Any]
    ) -> Tuple[str, float]:
        """
        Resolve intent from original sentence and extracted entities.

        Uses ordered rules (first match wins) to determine intent.
        Rule precedence: destructive/sensitive → booking → informational → unknown

        Args:
            osentence: Original user sentence (lowercased)
            entities: Extraction output with service_families, dates, times, etc.

        Returns:
            Tuple of (intent, confidence_score)
            intent: One of the 10 canonical intents or UNKNOWN
            confidence: Heuristic confidence score (0.75-0.95)

        Intent Decision Rules (ordered, first match wins):

        DESTRUCTIVE/SENSITIVE (check first):
        1. PAYMENT - Payment language
        2. CANCEL_BOOKING - Cancel patterns
        3. MODIFY_BOOKING - Reschedule/modify patterns

        BOOKING-RELATED:
        4. CREATE_BOOKING - Booking verbs + services + time constraints (entity-driven)
        5. AVAILABILITY - Availability language + date/time
        6. BOOKING_INQUIRY - Questions about existing booking

        INFORMATIONAL:
        7. DETAILS - Questions about service attributes (price, duration, inclusions, policies)
        8. QUOTE - Price/cost + service (contextual pricing)
        9. DISCOVERY - What services/rooms exist (services but no time constraints)
        10. RECOMMENDATION - Suggestions, recommendations

        FALLBACK:
        11. UNKNOWN - Nothing matches safely
        """
        if not osentence:
            return UNKNOWN, LOW_CONFIDENCE

        normalized_sentence = self._normalize_sentence(osentence)
        sentence_tokens_list, sentence_tokens_set = self._tokenize(normalized_sentence)

        # Extract entity counts (entity-driven rules first)
        service_families = entities.get("business_categories") or entities.get("service_families", [])
        dates = entities.get("dates", [])
        dates_absolute = entities.get("dates_absolute", [])
        times = entities.get("times", [])
        time_windows = entities.get("time_windows", [])
        durations = entities.get("durations", [])

        has_services = len(service_families) > 0
        has_dates = len(dates) > 0 or len(dates_absolute) > 0
        has_times = len(times) > 0 or len(time_windows) > 0
        has_durations = len(durations) > 0
        has_time_constraints = has_dates or has_times or has_durations

        # ============================================================
        # DESTRUCTIVE/SENSITIVE INTENTS (check first for safety)
        # ============================================================

        # Rule 1: PAYMENT (destructive - check first)
        if self._matches_signals(normalized_sentence, sentence_tokens_list, sentence_tokens_set, PAYMENT):
            return PAYMENT, HIGH_CONFIDENCE

        # Rule 2: CANCEL_BOOKING (destructive - check early)
        if self._matches_signals(normalized_sentence, sentence_tokens_list, sentence_tokens_set, CANCEL_BOOKING):
            return CANCEL_BOOKING, HIGH_CONFIDENCE

        # Rule 3: MODIFY_BOOKING (destructive - check early)
        if self._matches_signals(normalized_sentence, sentence_tokens_list, sentence_tokens_set, MODIFY_BOOKING):
            return MODIFY_BOOKING, HIGH_CONFIDENCE

        # ============================================================
        # BOOKING-RELATED INTENTS
        # ============================================================

        # Rule 4: CREATE_BOOKING (entity-driven: services + time constraints)
        if has_services and has_time_constraints:
            # If services + time constraints exist, it's a booking request
            # Even if it's a question like "Can I get...", it's still CREATE_BOOKING
            # Only exclude if it's clearly an availability question
            is_availability_question = self._matches_signals(
                normalized_sentence, sentence_tokens_list, sentence_tokens_set, AVAILABILITY)
            if not is_availability_question:
                return CREATE_BOOKING, HIGH_CONFIDENCE

        # Fallback rule: booking verbs + at least one of date/time/duration
        # SAFETY: Only permit fallback if at least some booking-relevant info exists (conservative, explainable)
        has_booking_verb = any(
            verb in normalized_sentence for verb in self.booking_verbs)
        if not has_services and has_booking_verb and (has_dates or has_times or has_durations):
            # This fallback enables CREATE_BOOKING intent for utterances like:
            # 'I want to book a full body massage this Friday at 4pm',
            # even if 'full body massage' fails extraction, since booking context is clear.
            return CREATE_BOOKING, MEDIUM_CONFIDENCE

        # Rule 5: BOOKING_INQUIRY (questions about existing booking - check before availability)
        if self._matches_signals(normalized_sentence, sentence_tokens_list, sentence_tokens_set, BOOKING_INQUIRY):
            return BOOKING_INQUIRY, HIGH_CONFIDENCE

        # Rule 6: AVAILABILITY (availability language + date/time OR just availability language)
        if self._matches_signals(normalized_sentence, sentence_tokens_list, sentence_tokens_set, AVAILABILITY):
            if has_time_constraints:
                return AVAILABILITY, HIGH_CONFIDENCE
            elif has_services:
                return AVAILABILITY, MEDIUM_CONFIDENCE
            else:
                # Pure availability check without entities
                return AVAILABILITY, MEDIUM_CONFIDENCE

        # ============================================================
        # INFORMATIONAL INTENTS
        # ============================================================

        # Rule 7: DETAILS (questions about service attributes)
        if self._matches_signals(normalized_sentence, sentence_tokens_list, sentence_tokens_set, DETAILS):
            if has_services:
                return DETAILS, HIGH_CONFIDENCE
            else:
                return DETAILS, MEDIUM_CONFIDENCE

        # Rule 8: QUOTE (price/cost + service)
        if self._matches_signals(normalized_sentence, sentence_tokens_list, sentence_tokens_set, QUOTE):
            if has_services:
                return QUOTE, HIGH_CONFIDENCE
            else:
                return QUOTE, MEDIUM_CONFIDENCE

        # Rule 9: DISCOVERY (what services/rooms exist - no time constraints required)
        discovery_match = self._matches_signals(
            normalized_sentence, sentence_tokens_list, sentence_tokens_set, DISCOVERY
        )
        if not has_time_constraints and (has_services or discovery_match):
            if discovery_match:
                return DISCOVERY, HIGH_CONFIDENCE if has_services else MEDIUM_CONFIDENCE
            has_booking_verb = any(
                verb in normalized_sentence for verb in self.booking_verbs
            )
            if has_services and not has_booking_verb:
                return DISCOVERY, MEDIUM_CONFIDENCE

        # Rule 10: RECOMMENDATION (suggestions, guidance)
        if self._matches_signals(normalized_sentence, sentence_tokens_list, sentence_tokens_set, RECOMMENDATION):
            return RECOMMENDATION, MEDIUM_CONFIDENCE

        # ============================================================
        # FALLBACK
        # ============================================================

        # Rule 11: UNKNOWN
        return UNKNOWN, LOW_CONFIDENCE

    def _load_intent_signals(self) -> Dict[str, Dict[str, List[List[str]]]]:
        """
        Load intent signals from YAML file and normalize them.

        YAML structure per intent:
        - any: list of phrases (substring match on normalized sentence)
        - all: list of token lists (all tokens must be present, order-independent)
        - ordered: list of token lists (tokens must appear in order, not necessarily adjacent)
        """
        path = (
            Path(__file__).resolve().parent.parent
            / "store"
            / "normalization"
            / "intent_signals.yaml"
        )
        with path.open(encoding="utf-8") as f:
            raw = yaml.safe_load(f) or {}

        normalized: Dict[str, Dict[str, List[List[str]]]] = {}
        for intent, cfg in raw.items():
            if not isinstance(cfg, dict):
                continue

            any_phrases = []
            for phrase in cfg.get("any", []) or []:
                if isinstance(phrase, str):
                    norm_phrase = self._normalize_sentence(phrase)
                    if norm_phrase:
                        any_phrases.append(norm_phrase)

            all_token_groups: List[List[str]] = []
            for token_group in cfg.get("all", []) or []:
                tokens = self._normalize_token_group(token_group)
                if tokens:
                    all_token_groups.append(tokens)

            ordered_token_groups: List[List[str]] = []
            for token_group in cfg.get("ordered", []) or []:
                tokens = self._normalize_token_group(token_group)
                if tokens:
                    ordered_token_groups.append(tokens)

            normalized[intent] = {
                "any": any_phrases,
                "all": all_token_groups,
                "ordered": ordered_token_groups,
            }

        return normalized

    def _normalize_sentence(self, sentence: str) -> str:
        """Lowercase and strip punctuation to a whitespace-separated string."""
        if not sentence:
            return ""
        lowered = sentence.lower()
        # Replace punctuation with spaces
        no_punct = re.sub(r"[^\w\s]", " ", lowered)
        collapsed = re.sub(r"\s+", " ", no_punct).strip()
        return collapsed

    def _tokenize(self, normalized_sentence: str) -> Tuple[List[str], Set[str]]:
        """Tokenize normalized sentence into list (ordered) and set (for inclusion)."""
        if not normalized_sentence:
            return [], set()
        tokens_list = normalized_sentence.split()
        return tokens_list, set(tokens_list)

    def _normalize_token_group(self, token_group: Any) -> List[str]:
        """
        Normalize a token group entry (string or list of strings) into a flat token list.
        """
        tokens: List[str] = []
        if isinstance(token_group, str):
            norm_group = self._normalize_sentence(token_group)
            tokens = norm_group.split()
        elif isinstance(token_group, list):
            for t in token_group:
                if isinstance(t, str):
                    norm_token = self._normalize_sentence(t)
                    tokens.extend(norm_token.split())
        # remove empties
        tokens = [t for t in tokens if t]
        return tokens

    def _matches_signals(
        self,
        normalized_sentence: str,
        sentence_tokens_list: List[str],
        sentence_tokens_set: Set[str],
        intent_key: str
    ) -> bool:
        """
        Check if the sentence matches configured signals for a given intent.

        Matching priority: ordered > all > any
        - ordered: tokens must appear in order (not necessarily adjacent)
        - all: all tokens present anywhere (order-independent)
        - any: substring phrase match on normalized sentence
        """
        signals = self.intent_signals.get(intent_key, {})

        # Ordered (strongest)
        for token_group in signals.get("ordered", []):
            if token_group and self._tokens_in_order(sentence_tokens_list, token_group):
                return True

        # Phrase (any) match
        for token_group in signals.get("all", []):
            if token_group and all(token in sentence_tokens_set for token in token_group):
                return True

        # Token-set (all) match
        for phrase in signals.get("any", []):
            if phrase and phrase in normalized_sentence:
                return True

        return False

    def _tokens_in_order(self, sentence_tokens_list: List[str], token_group: List[str]) -> bool:
        """
        Check if all tokens in token_group appear in order within sentence_tokens_list.
        Tokens do not need to be adjacent.
        """
        if not token_group:
            return False

        pos = 0
        for token in token_group:
            try:
                idx = sentence_tokens_list.index(token, pos)
            except ValueError:
                return False
            pos = idx + 1
        return True


def resolve_intent(
    osentence: str,
    entities: Dict[str, Any]
) -> Tuple[str, float]:
    """
    Convenience function for resolving intent.

    Creates a resolver instance and calls resolve_intent().

    Args:
        osentence: Original user sentence (lowercased)
        entities: Extraction output with service_families, dates, times, etc.

    Returns:
        Tuple of (intent, confidence_score)
    """
    resolver = ReservationIntentResolver()
    return resolver.resolve_intent(osentence, entities)
