"""Unit tests for the declarative booking scenario DSL (no HTTP / Luma)."""

from __future__ import annotations

from core.tests.e2e.booking_expectations import Expect
from core.tests.e2e.booking_runner import apply_expect
from core.tests.e2e.booking_scenario import Scenario
from core.tests.e2e.booking_turn import Turn, coerce_turn


class _FakeConv:
    def __init__(self):
        self.calls = []

    def assert_http_ok(self):
        self.calls.append(("http_ok",))

    def assert_turn(self, **kwargs):
        self.calls.append(("assert_turn", kwargs))

    def assert_slot_contains(self, key, fragment, *, in_session=True):
        self.calls.append(("slot_contains", key, fragment, in_session))


def test_expect_maps_aliases_and_explicit_none():
    checks = Expect(
        planner="READY",
        confirmation=None,
        execution="availability",
        time_match="EXACT",
        date_proposal="2026-07-03",
        time_proposal="09",
    ).to_assert_turn_kwargs()
    assert checks["planner_status"] == "READY"
    assert checks["confirmation"] is None
    assert checks["execution_type"] == "availability"
    assert checks["time_match_outcome"] == "TIME_MATCH_EXACT"
    assert checks["date_proposal_start"] == "2026-07-03"
    assert checks["time_proposal_contains"] == "09"


def test_expect_omitted_fields_are_skipped():
    assert Expect(planner="READY").to_assert_turn_kwargs() == {
        "planner_status": "READY"
    }


def test_apply_expect_runs_slot_contains():
    conv = _FakeConv()
    apply_expect(conv, Expect(planner="READY", slot_contains={"time": "10"}))
    assert conv.calls[0][0] == "assert_turn"
    assert conv.calls[1] == ("slot_contains", "time", "10", True)


def test_scenario_coerces_turns():
    scenario = Scenario(
        "Demo",
        Turn("hi", Expect(planner="READY")),
        ("premium", Expect(action="SEARCH_AVAILABILITY")),
    )
    assert len(scenario.turns) == 2
    assert scenario.turns[1].user == "premium"
    assert coerce_turn(("x", {"planner": "READY"})).expect.planner == "READY"
