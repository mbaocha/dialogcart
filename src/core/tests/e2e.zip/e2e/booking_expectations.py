"""Declarative per-turn expectations for booking conversation e2e scenarios."""

from __future__ import annotations

from dataclasses import dataclass, fields
from typing import Any, Dict, List

from core.orchestration.time_resolution import TIME_MATCH_EXACT, TIME_MATCH_MISMATCH

_UNSET = object()

_TIME_MATCH_ALIASES = {
    "EXACT": TIME_MATCH_EXACT,
    "TIME_MATCH_EXACT": TIME_MATCH_EXACT,
    "MISMATCH": TIME_MATCH_MISMATCH,
    "TIME_MATCH_MISMATCH": TIME_MATCH_MISMATCH,
}


@dataclass(frozen=True)
class Expect:
    """Optional assertions applied after a turn. Only set fields are checked.

    Pass ``None`` explicitly (e.g. ``confirmation=None``) to assert absence.
    Omit a field to skip that check.
    """

    planner: Any = _UNSET
    planner_status: Any = _UNSET
    response_status: Any = _UNSET
    status: Any = _UNSET
    stage: Any = _UNSET
    action: Any = _UNSET
    awaiting: Any = _UNSET
    confirmation: Any = _UNSET
    confirmation_state: Any = _UNSET
    intent: Any = _UNSET
    missing_slots: Any = _UNSET
    session_slots: Any = _UNSET
    outcome_slots: Any = _UNSET
    execution: Any = _UNSET
    execution_type: Any = _UNSET
    has_availability_slots: Any = _UNSET
    response_text_present: Any = _UNSET
    time_match: Any = _UNSET
    time_match_outcome: Any = _UNSET
    date_proposal: Any = _UNSET
    date_proposal_start: Any = _UNSET
    time_proposal: Any = _UNSET
    time_proposal_contains: Any = _UNSET
    slot_contains: Any = _UNSET
    slot_absent: Any = _UNSET
    availability_invalidated: Any = _UNSET

    def to_assert_turn_kwargs(self) -> Dict[str, Any]:
        """Map Expect fields onto BookingConversation.assert_turn kwargs."""
        checks: Dict[str, Any] = {}

        planner = self._first_set(self.planner_status, self.planner)
        if planner is not _UNSET:
            checks["planner_status"] = planner

        response_status = self._first_set(self.response_status, self.status)
        if response_status is not _UNSET:
            checks["response_status"] = response_status

        if self.stage is not _UNSET:
            checks["stage"] = self.stage
        if self.action is not _UNSET:
            checks["action"] = self.action
        if self.awaiting is not _UNSET:
            checks["awaiting"] = self.awaiting

        confirmation = self._first_set(self.confirmation, self.confirmation_state)
        if confirmation is not _UNSET:
            checks["confirmation"] = confirmation

        if self.intent is not _UNSET:
            checks["intent"] = self.intent
        if self.missing_slots is not _UNSET:
            checks["missing_slots"] = list(self.missing_slots or [])
        if self.session_slots is not _UNSET:
            checks["session_slots"] = dict(self.session_slots or {})
        if self.outcome_slots is not _UNSET:
            checks["outcome_slots"] = dict(self.outcome_slots or {})

        execution = self._first_set(self.execution_type, self.execution)
        if execution is not _UNSET:
            checks["execution_type"] = execution

        if self.has_availability_slots is not _UNSET:
            checks["has_availability_slots"] = self.has_availability_slots
        if self.response_text_present is not _UNSET:
            checks["response_text_present"] = self.response_text_present

        time_match = self._first_set(self.time_match_outcome, self.time_match)
        if time_match is not _UNSET:
            checks["time_match_outcome"] = _normalize_time_match(str(time_match))

        date_proposal = self._first_set(self.date_proposal_start, self.date_proposal)
        if date_proposal is not _UNSET:
            checks["date_proposal_start"] = date_proposal

        time_proposal = self._first_set(
            self.time_proposal_contains, self.time_proposal
        )
        if time_proposal is not _UNSET:
            checks["time_proposal_contains"] = time_proposal

        if self.slot_absent is not _UNSET:
            checks["slot_absent"] = list(self.slot_absent or [])
        if self.availability_invalidated is not _UNSET:
            checks["availability_invalidated"] = self.availability_invalidated

        return checks

    def apply_extra(self, conv: Any) -> None:
        """Assertions that assert_turn does not cover (slot_contains fragments)."""
        if self.slot_contains is not _UNSET and self.slot_contains:
            for key, fragment in self.slot_contains.items():
                conv.assert_slot_contains(key, fragment, in_session=True)

    @staticmethod
    def _first_set(*values: Any) -> Any:
        for value in values:
            if value is not _UNSET:
                return value
        return _UNSET


def _normalize_time_match(value: str) -> str:
    key = str(value).strip().upper()
    return _TIME_MATCH_ALIASES.get(key, value)


def expect_field_names() -> List[str]:
    return [f.name for f in fields(Expect)]
