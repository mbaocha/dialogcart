"""Shared e2e fixtures for booking conversation scenarios and API tests."""

from __future__ import annotations

import uuid

import pytest

from core.orchestration.api import message as message_api
from core.orchestration.cache.catalog_cache import catalog_cache
from core.orchestration.orchestrator import handle_message as real_handle_message
from core.orchestration.session import clear_session
from core.tests.e2e.test_booking_create_flow import (
    FROZEN_TIME,
    HAIRCUT_CATALOG,
    ORG_ID,
    BookingConversation,
    create_multi_slot_availability_client,
    create_paginated_availability_client,
)
from core.tests.harness.clients import TestCatalogClient, TestLumaClient
from core.tests.harness.mock_clients import (
    create_mock_booking_client,
    create_mock_organization_client,
)
from core.tests.harness.org_setup import setup_test_org_domain
from core.tests.mocks import reset_booking_counter


@pytest.fixture
def booking_conversation(api_client, monkeypatch):
    """API client wired to real orchestration with test doubles for externals only."""
    user_id = f"e2e-create-appt-{uuid.uuid4().hex[:10]}"
    clear_session(user_id)
    reset_booking_counter()

    setup_test_org_domain("service")
    catalog_cache._mem_cache.pop((ORG_ID, "service"), None)

    luma_client = TestLumaClient(test_aliases=HAIRCUT_CATALOG)
    catalog_client = TestCatalogClient(test_aliases=HAIRCUT_CATALOG, domain="service")
    org_client = create_mock_organization_client(business_category_id=1)
    booking_client = create_mock_booking_client()
    availability_client = create_multi_slot_availability_client()

    monkeypatch.setattr(message_api, "_booking_client", booking_client)
    monkeypatch.setattr(message_api, "_availability_client", availability_client)

    def handle_message_with_test_deps(**kwargs):
        kwargs.setdefault("luma_client", luma_client)
        kwargs.setdefault("organization_client", org_client)
        kwargs.setdefault("catalog_client", catalog_client)
        kwargs.setdefault("frozen_time", FROZEN_TIME)
        return real_handle_message(**kwargs)

    monkeypatch.setattr(message_api, "handle_message", handle_message_with_test_deps)

    conv = BookingConversation(api_client, user_id)
    yield conv, booking_client, availability_client

    clear_session(user_id)


@pytest.fixture
def paginated_booking_conversation(api_client, monkeypatch):
    """Like booking_conversation but with 9-slot paginated availability."""
    user_id = f"e2e-paginate-appt-{uuid.uuid4().hex[:10]}"
    clear_session(user_id)
    reset_booking_counter()

    setup_test_org_domain("service")
    catalog_cache._mem_cache.pop((ORG_ID, "service"), None)

    luma_client = TestLumaClient(test_aliases=HAIRCUT_CATALOG)
    catalog_client = TestCatalogClient(test_aliases=HAIRCUT_CATALOG, domain="service")
    org_client = create_mock_organization_client(business_category_id=1)
    booking_client = create_mock_booking_client()
    availability_client = create_paginated_availability_client()

    monkeypatch.setattr(message_api, "_booking_client", booking_client)
    monkeypatch.setattr(message_api, "_availability_client", availability_client)

    def handle_message_with_test_deps(**kwargs):
        kwargs.setdefault("luma_client", luma_client)
        kwargs.setdefault("organization_client", org_client)
        kwargs.setdefault("catalog_client", catalog_client)
        kwargs.setdefault("frozen_time", FROZEN_TIME)
        return real_handle_message(**kwargs)

    monkeypatch.setattr(message_api, "handle_message", handle_message_with_test_deps)

    conv = BookingConversation(api_client, user_id)
    yield conv, booking_client, availability_client

    clear_session(user_id)
