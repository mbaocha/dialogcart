"""A single user turn in a declarative booking conversation scenario."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Optional, Union

from core.tests.e2e.booking_expectations import Expect

# Hooks receive (conv, booking_client, availability_client)
TurnHook = Callable[..., Any]


@dataclass
class Turn:
    """One user message and the expectations / hooks for that turn."""

    user: str
    expect: Optional[Expect] = None
    before: Optional[TurnHook] = None
    after: Optional[TurnHook] = None
    trace: Optional[str] = None

    def __init__(
        self,
        user: str,
        expect: Optional[Expect] = None,
        *,
        before: Optional[TurnHook] = None,
        after: Optional[TurnHook] = None,
        trace: Optional[str] = None,
        **expect_kwargs: Any,
    ) -> None:
        # Allow Turn("hi", Expect(...)) and Turn("hi", planner="READY", ...)
        if expect is None and expect_kwargs:
            expect = Expect(**expect_kwargs)
        elif expect is not None and expect_kwargs:
            raise TypeError(
                "Turn: pass either an Expect instance or keyword expectations, not both"
            )
        self.user = user
        self.expect = expect
        self.before = before
        self.after = after
        self.trace = trace


def coerce_turn(value: Union[Turn, tuple, list, dict]) -> Turn:
    """Normalize shorthand turn values used in Scenario(...)."""
    if isinstance(value, Turn):
        return value
    if isinstance(value, (tuple, list)):
        if len(value) == 1:
            return Turn(str(value[0]))
        if len(value) == 2:
            user, second = value
            if isinstance(second, Expect):
                return Turn(str(user), second)
            if isinstance(second, dict):
                return Turn(str(user), Expect(**second))
            raise TypeError(f"Unsupported turn shorthand: {value!r}")
        raise TypeError(f"Turn tuple must have 1 or 2 items, got {value!r}")
    if isinstance(value, dict):
        return Turn(**value)
    raise TypeError(f"Cannot coerce {type(value)!r} to Turn")
