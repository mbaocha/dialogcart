"""
Full POST /api/message validation for availability browse pagination.

Uses scripted NLU for turns 1–3 (service resolution + July 9 search) so the
browse contract can be validated independently of live Luma alias matching.
Turn 4 uses the same NLU shape real Luma emits for "show me additional times".
"""

from __future__ import annotations

import copy
import logging
import uuid
from typing import Any, Dict

import pytest

from core.orchestration.api import message as message_api
from core.orchestration.availability_browse import resolve_availability_browse
from core.orchestration.availability_fingerprint import compute_availability_fingerprint
from core.orchestration.cache.catalog_cache import catalog_cache
from core.orchestration.orchestrator import handle_message as real_handle_message
from core.orchestration.session import clear_session
from core.tests.e2e.test_booking_create_flow import (
    FROZEN_TIME,
    HAIRCUT_CATALOG,
    ORG_ID,
    PREMIUM_SERVICE,
    BookingConversation,
    _presentation_page_index,
    _response_pagination_page_index,
    create_paginated_availability_client,
    extract_presented_times,
)
from core.tests.harness.clients import ScriptedLumaClient, TestCatalogClient
from core.tests.harness.mock_clients import (
    create_mock_booking_client,
    create_mock_organization_client,
)
from core.tests.harness.org_setup import setup_test_org_domain
from core.tests.mocks import reset_booking_counter

JULY_9 = "2026-07-09"
FULL_SLOT_COUNT = 9
PAGE_SIZE = 6


def _turn1_script() -> Dict[str, Any]:
    return {
        "success": True,
        "intent": {"name": "CREATE_APPOINTMENT"},
        "needs_clarification": True,
        "missing_slots": ["date", "service_id", "time"],
        "service_candidates": [
            {"text": PREMIUM_SERVICE},
            {"text": "flexi haircut + prunning"},
        ],
    }


def _turn2_script() -> Dict[str, Any]:
    return {
        "success": True,
        "intent": {"name": "CREATE_APPOINTMENT"},
        "facts": {
            "service_id": PREMIUM_SERVICE,
            "slots": {"service_id": PREMIUM_SERVICE},
            "missing_slots": ["date", "time"],
        },
        "slots": {"service_id": PREMIUM_SERVICE},
        "missing_slots": ["date", "time"],
    }


def _turn3_script() -> Dict[str, Any]:
    """Date revision via AVAILABILITY intent (matches pagination flow date-change shape)."""
    return {
        "success": True,
        "intent": {"name": "AVAILABILITY"},
        "facts": {
            "dates": [JULY_9],
            "service_id": PREMIUM_SERVICE,
            "slots": {"service_id": PREMIUM_SERVICE},
        },
        "slots": {},
        "date_proposal": {"mode": "single_day", "start": JULY_9},
        "missing_slots": ["time"],
    }


def _turn4_script() -> Dict[str, Any]:
    """Matches live Luma: AVAILABILITY + operation=browse_next."""
    return {
        "success": True,
        "intent": {"name": "AVAILABILITY"},
        "operation": "browse_next",
        "facts": {
            "service_id": PREMIUM_SERVICE,
            "slots": {"service_id": PREMIUM_SERVICE},
            "missing_slots": ["time"],
        },
        "slots": {"service_id": PREMIUM_SERVICE},
        "missing_slots": ["time"],
    }


def _browse_scripts() -> Dict[str, Dict[str, Any]]:
    return {
        "book haircut": _turn1_script(),
        "premium": _turn2_script(),
        "actually july 9": _turn3_script(),
        "show me additional times": _turn4_script(),
    }


@pytest.fixture
def browse_api_conversation(api_client, monkeypatch):
    """POST /api/message with scripted NLU turns 1–4 and paginated availability."""
    user_id = f"e2e-browse-api-{uuid.uuid4().hex[:10]}"
    clear_session(user_id)
    reset_booking_counter()

    setup_test_org_domain("service")
    catalog_cache._mem_cache.pop((ORG_ID, "service"), None)

    luma_client = ScriptedLumaClient(_browse_scripts())
    catalog_client = TestCatalogClient(test_aliases=HAIRCUT_CATALOG, domain="service")
    org_client = create_mock_organization_client(business_category_id=1)
    booking_client = create_mock_booking_client()
    availability_client = create_paginated_availability_client()

    monkeypatch.setattr(message_api, "_booking_client", booking_client)
    monkeypatch.setattr(message_api, "_availability_client", availability_client)

    def handle_message_with_test_deps(**kwargs):
        kwargs.setdefault("luma_client", luma_client)
        kwargs.setdefault("organization_client", org_client)
        kwargs.setdefault("catalog_client", catalog_client)
        kwargs.setdefault("frozen_time", FROZEN_TIME)
        return real_handle_message(**kwargs)

    monkeypatch.setattr(message_api, "handle_message", handle_message_with_test_deps)

    conv = BookingConversation(api_client, user_id)
    yield conv, booking_client, availability_client, luma_client

    clear_session(user_id)


def _cached_slot_count(session: Dict[str, Any]) -> int:
    last = session.get("last_execution_result") or {}
    return len(last.get("slots") or [])


def _presented_slot_count(session: Dict[str, Any]) -> int:
    presented = session.get("presented_availability") or {}
    return len(presented.get("slots") or [])


def test_browse_pagination_full_api_path_validation(browse_api_conversation, caplog):
    """
    Validate browse pagination through POST /api/message (turns 2–4 contract).
    """
    conv, booking_client, availability_client, luma_client = browse_api_conversation

    # Turn 1 — establish CREATE_APPOINTMENT clarification
    conv.send("book haircut")
    conv.assert_http_ok()
    conv.assert_turn(
        response_status="NEEDS_CLARIFICATION",
        intent="CREATE_APPOINTMENT",
    )

    # Turn 2 — service resolution (scripted NLU simulates resolved alias)
    conv.send("premium")
    conv.assert_http_ok()
    sess2 = conv.session() or {}
    assert conv.outcome.get("status") != "NEEDS_CLARIFICATION", (
        f"turn 2: expected service resolved, still NEEDS_CLARIFICATION; "
        f"session={sess2!r} outcome={conv.outcome!r}"
    )
    assert sess2.get("slots", {}).get("service_id") == PREMIUM_SERVICE, (
        f"turn 2: service_id expected {PREMIUM_SERVICE!r}, "
        f"got {sess2.get('slots', {}).get('service_id')!r}"
    )
    searches_after_turn2 = availability_client.get_service_availability.call_count
    assert searches_after_turn2 >= 1, (
        f"turn 2: expected initial SEARCH_AVAILABILITY, call_count={searches_after_turn2}"
    )

    # Turn 3 — date revision + single search for July 9
    conv.send("actually July 9")
    conv.assert_http_ok()
    sess3 = conv.session() or {}
    searches_after_turn3 = availability_client.get_service_availability.call_count
    assert searches_after_turn3 == searches_after_turn2 + 1, (
        f"turn 3: expected exactly one SEARCH_AVAILABILITY on date revision, "
        f"before={searches_after_turn2} after={searches_after_turn3}"
    )
    stored_fp = sess3.get("availability_fingerprint")
    assert stored_fp, "turn 3: availability_fingerprint missing from session"
    full_cached = _cached_slot_count(sess3)
    assert full_cached == FULL_SLOT_COUNT, (
        f"turn 3: last_execution_result should cache all {FULL_SLOT_COUNT} slots, "
        f"got {full_cached}"
    )
    search_fp = compute_availability_fingerprint(
        {
            "organization_id": ORG_ID,
            "service_id": PREMIUM_SERVICE,
            "date": JULY_9,
        }
    )
    assert stored_fp == search_fp, (
        f"turn 3: availability_fingerprint_stored != search fingerprint; "
        f"stored={stored_fp!r} search={search_fp!r}"
    )
    first_page = extract_presented_times(conv.last_body, sess3)
    assert first_page, "turn 3: expected presented availability on page 0"
    page_before = _presentation_page_index(sess3)
    assert page_before == 0, f"turn 3: expected page_index=0 before browse, got {page_before}"

    # Pre-check resolve_availability_browse contract for turn-4 NLU shape
    merged_probe = copy.deepcopy(_turn4_script())
    merged_probe["_source_text"] = "show me additional times"
    merged_probe["_raw_luma_response"] = copy.deepcopy(_turn4_script())
    resolved = resolve_availability_browse(merged_probe, sess3)
    assert resolved == {"direction": "next"}, (
        f"turn 4 pre-check: resolve_availability_browse expected next, got {resolved!r}"
    )

    # Turn 4 — browse pagination (no new search)
    caplog.set_level(logging.INFO, logger="core.orchestration.availability_pagination")
    conv.send("show me additional times")
    conv.assert_http_ok()
    sess4 = conv.session() or {}

    pagination_logs = [
        r.message for r in caplog.records if "[AVAILABILITY_PAGINATION]" in r.message
    ]
    assert pagination_logs, (
        "turn 4: expected [AVAILABILITY_PAGINATION] log from "
        "try_handle_availability_browse_turn"
    )
    assert any("page_index=1" in msg for msg in pagination_logs), (
        f"turn 4: expected page_index=1 in pagination logs; logs={pagination_logs!r}"
    )

    page_after = _presentation_page_index(sess4)
    assert page_after == 1, (
        f"turn 4: session.availability_presentation.page_index expected 1, got {page_after}"
    )
    outcome_pagination = _response_pagination_page_index(conv.last_body)
    assert outcome_pagination == 1, (
        f"turn 4: outcome.availability_pagination.page_index expected 1, "
        f"got {outcome_pagination!r} body={conv.last_body!r}"
    )
    assert conv.plan.get("action") is None, (
        f"turn 4: planned action should be null after browse; plan={conv.plan!r}"
    )
    assert availability_client.get_service_availability.call_count == searches_after_turn3, (
        f"turn 4: SEARCH_AVAILABILITY must not run again; "
        f"call_count={availability_client.get_service_availability.call_count} "
        f"expected {searches_after_turn3}"
    )

    page1_slots = extract_presented_times(conv.last_body, sess4)
    assert page1_slots, "turn 4: presented_availability must contain page 1 slots"
    assert not set(page1_slots) & set(first_page), (
        f"turn 4: page 1 must not repeat page 0 slots; "
        f"page0={first_page!r} page1={page1_slots!r}"
    )
    assert _presented_slot_count(sess4) == FULL_SLOT_COUNT - PAGE_SIZE, (
        f"turn 4: page 1 should have {FULL_SLOT_COUNT - PAGE_SIZE} slots, "
        f"got {_presented_slot_count(sess4)}"
    )
    assert _cached_slot_count(sess4) == FULL_SLOT_COUNT, (
        f"turn 4: last_execution_result must retain full cache ({FULL_SLOT_COUNT}), "
        f"got {_cached_slot_count(sess4)}"
    )
    assert page_before == 0 and page_after == 1

    assert luma_client.last_text == "show me additional times"
