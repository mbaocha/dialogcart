"""Execute declarative time-resolution conversation scenarios (scripted NLU)."""

from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional, Tuple
from unittest.mock import Mock

import pytest

from core.orchestration.api import message as message_api
from core.orchestration.cache.catalog_cache import catalog_cache
from core.orchestration.execution.clients.availability_client import AvailabilityClient
from core.orchestration.orchestrator import handle_message as real_handle_message
from core.orchestration.session import clear_session
from core.orchestration.time_resolution import TIME_MATCH_EXACT
from core.tests.e2e.booking_runner import run_bundle
from core.tests.e2e.test_booking_create_flow import (
    FROZEN_TIME,
    HAIRCUT_CATALOG,
    ORG_ID,
    PREMIUM_SERVICE,
    BookingConversation,
    create_empty_availability_client,
    create_slot_availability_client,
)
from core.tests.e2e.time_resolution_scenarios import (
    TARGET_DATE,
    TIME_RESOLUTION_SCENARIOS,
)
from core.tests.harness.clients import ScriptedLumaClient, TestCatalogClient
from core.tests.harness.mock_clients import (
    create_mock_booking_client,
    create_mock_organization_client,
)
from core.tests.harness.org_setup import setup_test_org_domain
from core.tests.mocks import reset_booking_counter
from core.tracing.availability import AVAILABILITY_REQUEST_ID, AVAILABILITY_RESPONSE_ID
from core.tracing.schema_validation import validate_decision_trace


def _service_disambiguation_script() -> Dict[str, Any]:
    return {
        "success": True,
        "intent": {"name": "CREATE_APPOINTMENT"},
        "needs_clarification": True,
        "missing_slots": ["service_id"],
        "service_candidates": [
            {"text": PREMIUM_SERVICE},
            {"text": "flexi haircut + prunning"},
        ],
    }


def _temporal_turn_script(*, times: List[str]) -> Dict[str, Any]:
    script = _service_disambiguation_script()
    script["facts"] = {"dates": [TARGET_DATE], "times": times}
    script["time_constraint"] = {
        "mode": "exact",
        "start": times[0],
        "end": times[0],
    }
    return script


def _premium_turn_script() -> Dict[str, Any]:
    return {
        "success": True,
        "intent": {"name": "CREATE_APPOINTMENT"},
        "facts": {
            "service_id": PREMIUM_SERVICE,
            "slots": {"service_id": PREMIUM_SERVICE},
        },
        "slots": {"service_id": PREMIUM_SERVICE},
        "missing_slots": ["time"],
    }


def _time_selection_script(time_value: str) -> Dict[str, Any]:
    return {
        "success": True,
        "intent": {"name": "CREATE_APPOINTMENT"},
        "facts": {"times": [time_value]},
        "time_constraint": {
            "mode": "exact",
            "start": time_value,
            "end": time_value,
        },
    }


def _fixed_slots_availability_client(slots: List[Dict[str, Any]]) -> Mock:
    mock_client = Mock(spec=AvailabilityClient)

    def get_service_availability(**kwargs):
        return {"slots": list(slots)}

    mock_client.get_service_availability.side_effect = get_service_availability
    return mock_client


def _instrument_availability_tracing(mock_client: Mock) -> Mock:
    from core.tracing.availability import (
        begin_availability_request,
        finalize_availability_response,
    )

    original = mock_client.get_service_availability.side_effect

    def traced_get_service_availability(**kwargs):
        params = {key: value for key, value in kwargs.items() if value is not None}
        begin_availability_request(
            endpoint="/api/internal/availability/service",
            method="GET",
            organization_id=int(kwargs.get("organization_id") or ORG_ID),
            params=params,
            service_id=kwargs.get("service_id"),
            date=kwargs.get("date"),
        )
        result = original(**kwargs) if callable(original) else {"slots": []}
        finalize_availability_response(
            raw_response=result,
            normalized={
                "type": "availability",
                "status": "success",
                "slots": (result or {}).get("slots") or [],
            },
        )
        return result

    mock_client.get_service_availability.side_effect = traced_get_service_availability
    return mock_client


def _trace_record(trace: Dict[str, Any], record_id: str) -> Dict[str, Any]:
    for record in trace.get("records") or []:
        if record.get("id") == record_id:
            return record
    raise AssertionError(f"trace record {record_id!r} not found")


_MISMATCH_SLOTS = [
    {"start": f"{TARGET_DATE}T09:00:00Z", "end": f"{TARGET_DATE}T09:30:00Z"},
    {"start": f"{TARGET_DATE}T09:30:00Z", "end": f"{TARGET_DATE}T10:00:00Z"},
]

_FIXTURE_PARAMS: Dict[str, Dict[str, Any]] = {
    "scripted": {},
    "scripted_empty": {"empty": True},
    "scripted_mismatch": {"fixed_slots": _MISMATCH_SLOTS},
    "scripted_mismatch_pick": {
        "fixed_slots": _MISMATCH_SLOTS,
        "include_time_pick_script": True,
    },
}


def _build_scripted_bundle(
    monkeypatch,
    api_client,
    *,
    empty: bool = False,
    fixed_slots: Optional[List[Dict[str, Any]]] = None,
    start_hours: tuple[int, ...] = (9, 10),
    include_time_pick_script: bool = False,
    trace_availability: bool = False,
) -> Tuple[BookingConversation, Any, Any, str]:
    user_id = f"e2e-time-res-{uuid.uuid4().hex[:10]}"
    clear_session(user_id)
    reset_booking_counter()
    setup_test_org_domain("service")
    catalog_cache._mem_cache.pop((ORG_ID, "service"), None)

    scripts = {
        "book haircut tomorrow by 9am": _temporal_turn_script(times=["09:00"]),
        "book haircut tomorrow at 10am": _temporal_turn_script(times=["10:00"]),
        "book haircut tomorrow at 9:15am": _temporal_turn_script(times=["09:15"]),
        "premium": _premium_turn_script(),
    }
    if include_time_pick_script:
        scripts["9:30am"] = _time_selection_script("09:30")

    luma_client = ScriptedLumaClient(scripts)
    catalog_client = TestCatalogClient(test_aliases=HAIRCUT_CATALOG, domain="service")
    org_client = create_mock_organization_client(business_category_id=1)
    booking_client = create_mock_booking_client()

    if empty:
        availability_client = create_empty_availability_client()
    elif fixed_slots is not None:
        availability_client = _fixed_slots_availability_client(fixed_slots)
    else:
        availability_client = create_slot_availability_client(start_hours=start_hours)
    if trace_availability:
        availability_client = _instrument_availability_tracing(availability_client)

    monkeypatch.setattr(message_api, "_booking_client", booking_client)
    monkeypatch.setattr(message_api, "_availability_client", availability_client)

    def handle_message_with_test_deps(**kwargs):
        kwargs.setdefault("luma_client", luma_client)
        kwargs.setdefault("organization_client", org_client)
        kwargs.setdefault("catalog_client", catalog_client)
        kwargs.setdefault("frozen_time", FROZEN_TIME)
        return real_handle_message(**kwargs)

    monkeypatch.setattr(message_api, "handle_message", handle_message_with_test_deps)
    conv = BookingConversation(api_client, user_id)
    return conv, booking_client, availability_client, user_id


@pytest.mark.parametrize(
    "scenario",
    TIME_RESOLUTION_SCENARIOS,
    ids=[s.pytest_id() for s in TIME_RESOLUTION_SCENARIOS],
)
def test_time_resolution_conversation_scenario(scenario, api_client, monkeypatch):
    params = dict(_FIXTURE_PARAMS.get(scenario.fixture) or {})
    conv, booking, availability, user_id = _build_scripted_bundle(
        monkeypatch, api_client, **params
    )
    try:
        run_bundle(scenario, (conv, booking, availability))
    finally:
        clear_session(user_id)


@pytest.fixture
def traced_scripted_conversation(api_client, monkeypatch):
    conv, booking_client, availability_client, user_id = _build_scripted_bundle(
        monkeypatch, api_client, trace_availability=True
    )
    yield conv, booking_client, availability_client
    clear_session(user_id)


def test_forensic_trace_records_availability_and_time_resolution(
    traced_scripted_conversation,
    monkeypatch,
):
    """Infrastructure test: forensic nodes, not a declarative conversation scenario."""
    conv, _, _ = traced_scripted_conversation
    monkeypatch.setenv("DIALOGCART_TRACE_DECISIONS", "1")

    conv.send("book haircut tomorrow by 9am")
    conv.send("premium", trace="forensic")

    assert conv.last_http.status_code == 200
    trace = conv.last_body.get("decision_trace")
    assert trace is not None
    validate_decision_trace(trace)

    avail_req = _trace_record(trace, AVAILABILITY_REQUEST_ID)
    assert avail_req["facts"]["time_constraint"] is None
    assert avail_req["facts"].get("service_id") is not None
    assert avail_req["facts"].get("date") == TARGET_DATE

    avail_resp = _trace_record(trace, AVAILABILITY_RESPONSE_ID)
    assert avail_resp["facts"].get("available_slot_count") is not None

    time_res = _trace_record(trace, "evidence.time_resolution")
    assert (time_res.get("facts") or {}).get("time_resolution", {}).get("outcome") == (
        TIME_MATCH_EXACT
    )
