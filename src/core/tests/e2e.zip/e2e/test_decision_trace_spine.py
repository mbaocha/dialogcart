"""E2E tests for Phase 1 decision trace spine emitters."""

from __future__ import annotations

from unittest.mock import Mock

import pytest

from core.orchestration.api import message as message_api
from core.orchestration.clients.catalog_client import CatalogClient
from core.orchestration.clients.organization_client import OrganizationClient
from core.orchestration.execution.clients.availability_client import AvailabilityClient
from core.orchestration.nlu import LumaClient
from core.orchestration.orchestrator import handle_message as real_handle_message
from core.orchestration.session import clear_session
from core.tests.e2e.trace_helpers import maybe_print_decision_trace, stash_decision_trace_from_body
from core.tracing.schema_validation import validate_decision_trace
from core.tracing.spine import (
    SPINE_EXECUTION_ID,
    SPINE_PERSIST_SAVE_ID,
    SPINE_RELOAD_VERIFY_ID,
    SPINE_TURN_OUTCOME_ID,
)


@pytest.fixture
def spine_user_id():
    user_id = "test-decision-trace-spine"
    clear_session(user_id)
    yield user_id
    clear_session(user_id)


@pytest.fixture
def booking_message_mocks(monkeypatch):
    mock_luma = Mock(spec=LumaClient)
    mock_luma.resolve.return_value = {
        "success": True,
        "intent": {"name": "CREATE_APPOINTMENT", "confidence": 0.95},
        "needs_clarification": False,
        "facts": {"service_id": 1, "dates": ["2026-07-10"]},
        "slots": {},
        "missing_slots": ["time"],
        "issues": {"time": "missing"},
        "context": {},
    }

    mock_org = Mock(spec=OrganizationClient)
    mock_org.get_details.return_value = {
        "organization": {
            "id": 1,
            "businessCategoryId": 1,
            "domain": "service",
        }
    }

    mock_catalog = Mock(spec=CatalogClient)
    mock_catalog.get_services.return_value = {
        "catalog_last_updated_at": "2026-01-01T00:00:00Z",
        "business_category_id": 1,
        "services": [
            {
                "id": 1,
                "name": "Haircut",
                "canonical": "haircut",
                "is_active": True,
                "duration": 60,
            }
        ],
    }
    mock_catalog.get_reservation.return_value = {"room_types": [], "extras": []}

    mock_availability = Mock(spec=AvailabilityClient)
    mock_availability.get_service_availability.return_value = {
        "slots": [
            {
                "start": "2026-07-10T10:00:00Z",
                "end": "2026-07-10T10:30:00Z",
                "available": True,
            }
        ]
    }
    monkeypatch.setattr(message_api, "_availability_client", mock_availability)

    return {
        "luma_client": mock_luma,
        "organization_client": mock_org,
        "catalog_client": mock_catalog,
    }


@pytest.fixture
def handle_message_with_booking_mocks(booking_message_mocks, monkeypatch):
    def _handle_message(**kwargs):
        merged = {**booking_message_mocks, **kwargs}
        return real_handle_message(**merged)

    monkeypatch.setattr(message_api, "handle_message", _handle_message)
    return _handle_message


def test_decision_trace_spine_records(
    spine_user_id,
    api_client,
    handle_message_with_booking_mocks,
    monkeypatch,
):
    monkeypatch.setenv("DIALOGCART_TRACE_DECISIONS", "1")

    response = api_client.post(
        "/api/message",
        params={"trace": "forensic"},
        json={
            "user_id": spine_user_id,
            "text": "book haircut",
            "organization_id": 1,
        },
    )

    assert response.status_code == 200
    body = response.json()
    assert body["success"] is True
    stash_decision_trace_from_body(body)
    maybe_print_decision_trace(body)
    assert body.get("decision_trace") is not None

    trace = body["decision_trace"]
    validate_decision_trace(trace)

    record_ids = {record["id"] for record in trace["records"]}
    assert SPINE_EXECUTION_ID in record_ids
    assert SPINE_PERSIST_SAVE_ID in record_ids
    assert SPINE_RELOAD_VERIFY_ID in record_ids
    assert SPINE_TURN_OUTCOME_ID in record_ids
    assert trace["root_id"] == SPINE_TURN_OUTCOME_ID

    execution = next(r for r in trace["records"] if r["id"] == SPINE_EXECUTION_ID)
    assert execution["subsystem"] == "execution"
    assert execution["decision_type"] == "EXECUTE_PLAN_ACTION"

    turn_outcome = next(r for r in trace["records"] if r["id"] == SPINE_TURN_OUTCOME_ID)
    assert turn_outcome["subsystem"] == "api"
    assert turn_outcome["decision_type"] == "TURN_OUTCOME"
    assert turn_outcome["winner"]["intent"] == "CREATE_APPOINTMENT"


def test_decision_trace_absent_when_disabled(
    spine_user_id,
    api_client,
    handle_message_with_booking_mocks,
    monkeypatch,
):
    monkeypatch.delenv("DIALOGCART_TRACE_DECISIONS", raising=False)

    response = api_client.post(
        "/api/message",
        json={
            "user_id": spine_user_id,
            "text": "book haircut",
            "organization_id": 1,
        },
    )

    assert response.status_code == 200
    body = response.json()
    assert body["success"] is True
    assert body.get("decision_trace") is None
    assert body.get("outcome") is not None
