"""Declarative multi-turn conversation scenario for booking e2e tests."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, List, Optional, Sequence, Union

from core.tests.e2e.booking_turn import Turn, coerce_turn

ScenarioHook = Callable[..., Any]


@dataclass
class Scenario:
    """Named conversation made of turns; executed by the scenario runner."""

    name: str
    turns: List[Turn] = field(default_factory=list)
    fixture: str = "booking"
    tags: List[str] = field(default_factory=list)
    before: Optional[ScenarioHook] = None
    after: Optional[ScenarioHook] = None
    id: Optional[str] = None

    def __init__(
        self,
        name: str,
        *turns: Union[Turn, tuple, list, dict],
        fixture: str = "booking",
        tags: Optional[Sequence[str]] = None,
        before: Optional[ScenarioHook] = None,
        after: Optional[ScenarioHook] = None,
        id: Optional[str] = None,
    ) -> None:
        self.name = name
        self.turns = [coerce_turn(t) for t in turns]
        self.fixture = fixture
        self.tags = list(tags or [])
        self.before = before
        self.after = after
        self.id = id or _slugify(name)

    def pytest_id(self) -> str:
        return self.id


def _slugify(name: str) -> str:
    slug = "".join(ch.lower() if ch.isalnum() else "-" for ch in name)
    while "--" in slug:
        slug = slug.replace("--", "-")
    return slug.strip("-") or "scenario"
