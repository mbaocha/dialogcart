"""Declarative booking conversation scenarios (definitions only).

Real-Luma flows use the default \"booking\" fixture. Pagination and tracing
remain in dedicated test modules.
"""

from __future__ import annotations

from typing import Any, Dict, List

from core.tests.e2e.booking_expectations import Expect
from core.tests.e2e.booking_scenario import Scenario
from core.tests.e2e.booking_turn import Turn
from core.tests.e2e.test_booking_create_flow import FLEXI_SERVICE, PREMIUM_SERVICE

BOOKING_SCENARIOS: List[Scenario] = []


def _register(scenario: Scenario) -> Scenario:
    BOOKING_SCENARIOS.append(scenario)
    return scenario


def _assert_booking_created(conv, booking_client, _availability=None) -> None:
    assert booking_client.create_booking.called, (
        f"turn {conv.turn}: expected create_booking after confirmation"
    )
    sess = conv.session() or {}
    slots = sess.get("slots") or {}
    assert slots.get("booking_id") or slots.get("booking_code"), (
        f"turn {conv.turn}: expected booking_id or booking_code in session slots"
    )


def _assert_no_booking(conv, booking_client, _availability=None) -> None:
    assert not booking_client.create_booking.called, (
        f"turn {conv.turn}: booking should not have been created"
    )


def _assert_no_booking_and_date_kept(conv, booking_client, _availability=None) -> None:
    _assert_no_booking(conv, booking_client)
    sess = conv.session() or {}
    assert (sess.get("slots") or {}).get("date"), (
        f"turn {conv.turn}: expected date retained after rejection"
    )


# Per-scenario scratch pads (runner is single-threaded / sequential per test).
_SEARCH_STATE: Dict[str, Any] = {}


def _capture_searches(_conv, _booking, availability) -> None:
    _SEARCH_STATE["count"] = availability.get_service_availability.call_count


def _assert_no_extra_search(conv, booking, availability) -> None:
    _assert_no_booking(conv, booking)
    assert availability.get_service_availability.call_count == _SEARCH_STATE.get("count")
    last = (conv.session() or {}).get("last_execution_result") or {}
    assert last.get("type") == "availability"
    assert len(last.get("slots") or []) >= 1
    missing = (conv.session() or {}).get("missing_slots") or []
    assert "service_id" not in missing


def _assert_service_revision(conv, booking, availability) -> None:
    assert availability.get_service_availability.call_count > _SEARCH_STATE.get("count", 0)
    conv.assert_execution(has_availability_slots=True)
    time_slot = ((conv.session() or {}).get("slots") or {}).get("time")
    assert time_slot in (None, ""), f"expected prior time discarded, got {time_slot!r}"
    _assert_no_booking(conv, booking)


def _assert_date_revision(_conv, booking, availability) -> None:
    assert availability.get_service_availability.call_count > _SEARCH_STATE.get("count", 0)
    _assert_no_booking(_conv, booking)


def _assert_booking_called(conv, booking_client, _availability=None) -> None:
    assert booking_client.create_booking.called, (
        f"turn {conv.turn}: expected booking after yes"
    )


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------

_register(
    Scenario(
        "Happy path create appointment",
        Turn(
            "book me a haircut",
            Expect(
                response_status="NEEDS_CLARIFICATION",
                planner="NEEDS_CLARIFICATION",
                intent="CREATE_APPOINTMENT",
                confirmation=None,
                missing_slots=["date", "service_id", "time"],
            ),
        ),
        Turn(
            "premium",
            Expect(
                response_status="success",
                planner="READY",
                stage="AVAILABILITY",
                action="SEARCH_AVAILABILITY",
                session_slots={"service_id": PREMIUM_SERVICE},
                confirmation=None,
                execution="availability",
                has_availability_slots=True,
                missing_slots=["date", "time"],
            ),
        ),
        Turn(
            "10am",
            Expect(
                response_status="AWAITING_CONFIRMATION",
                planner="AWAITING_CONFIRMATION",
                stage="CONFIRM",
                awaiting="USER_CONFIRMATION",
                action=None,
                session_slots={"service_id": PREMIUM_SERVICE},
                confirmation="pending",
                slot_contains={"time": "10"},
                missing_slots=[],
            ),
            after=_assert_no_booking,
        ),
        Turn(
            "yes",
            Expect(
                planner="READY",
                stage="CONFIRM",
                action="CONFIRM_APPOINTMENT",
                confirmation=None,
                missing_slots=[],
                slot_contains={"time": "10"},
                session_slots={"service_id": PREMIUM_SERVICE},
            ),
            after=_assert_booking_created,
        ),
        tags=["booking", "happy-path"],
    )
)


# ---------------------------------------------------------------------------
# Reject then revise time
# ---------------------------------------------------------------------------

_register(
    Scenario(
        "Reject then revise time",
        Turn(
            "book haircut",
            Expect(
                response_status="NEEDS_CLARIFICATION",
                planner="NEEDS_CLARIFICATION",
                intent="CREATE_APPOINTMENT",
            ),
        ),
        Turn(
            "premium",
            Expect(
                response_status="success",
                planner="READY",
                stage="AVAILABILITY",
                action="SEARCH_AVAILABILITY",
                session_slots={"service_id": PREMIUM_SERVICE},
                execution="availability",
                has_availability_slots=True,
            ),
        ),
        Turn(
            "10am",
            Expect(
                response_status="AWAITING_CONFIRMATION",
                planner="AWAITING_CONFIRMATION",
                stage="CONFIRM",
                awaiting="USER_CONFIRMATION",
                action=None,
                confirmation="pending",
                slot_contains={"time": "10"},
            ),
        ),
        Turn(
            "no",
            Expect(
                intent="CREATE_APPOINTMENT",
                confirmation=None,
                session_slots={"service_id": PREMIUM_SERVICE},
            ),
            after=_assert_no_booking_and_date_kept,
        ),
        Turn(
            "11am",
            Expect(
                response_status="AWAITING_CONFIRMATION",
                planner="AWAITING_CONFIRMATION",
                stage="CONFIRM",
                awaiting="USER_CONFIRMATION",
                action=None,
                confirmation="pending",
                slot_contains={"time": "11"},
            ),
        ),
        Turn(
            "yes",
            Expect(action="CONFIRM_APPOINTMENT", slot_contains={"time": "11"}),
            after=_assert_booking_called,
        ),
        tags=["booking", "revise"],
    )
)


# ---------------------------------------------------------------------------
# Unavailable time → TIME_MATCH_MISMATCH
# ---------------------------------------------------------------------------

_register(
    Scenario(
        "Unavailable time keeps booking flow",
        Turn(
            "book me a haircut",
            Expect(
                response_status="NEEDS_CLARIFICATION",
                intent="CREATE_APPOINTMENT",
            ),
        ),
        Turn(
            "premium",
            Expect(
                response_status="success",
                planner="READY",
                stage="AVAILABILITY",
                action="SEARCH_AVAILABILITY",
                session_slots={"service_id": PREMIUM_SERVICE},
                has_availability_slots=True,
            ),
            after=_capture_searches,
        ),
        Turn(
            "12pm",
            Expect(
                intent="CREATE_APPOINTMENT",
                time_match="TIME_MATCH_MISMATCH",
                planner="NEEDS_CLARIFICATION",
                action=None,
                awaiting="TIME_SELECTION",
                response_text_present=True,
                session_slots={"service_id": PREMIUM_SERVICE},
                time_proposal="12",
            ),
            after=_assert_no_extra_search,
        ),
        tags=["booking", "time-mismatch"],
    )
)


# ---------------------------------------------------------------------------
# Service revision invalidates availability
# ---------------------------------------------------------------------------

_register(
    Scenario(
        "Service revision invalidates availability",
        Turn("book haircut"),
        Turn("premium"),
        Turn(
            "10am",
            Expect(
                response_status="AWAITING_CONFIRMATION",
                confirmation="pending",
                session_slots={"service_id": PREMIUM_SERVICE},
            ),
            after=_capture_searches,
        ),
        Turn(
            "rather book flexi haircut",
            Expect(
                intent="CREATE_APPOINTMENT",
                session_slots={"service_id": FLEXI_SERVICE},
                confirmation=None,
            ),
            after=_assert_service_revision,
        ),
        tags=["booking", "invalidation"],
    )
)


# ---------------------------------------------------------------------------
# Date revision invalidates availability
# ---------------------------------------------------------------------------

_register(
    Scenario(
        "Date revision invalidates availability",
        Turn("book haircut"),
        Turn("premium"),
        Turn(
            "10am",
            Expect(
                response_status="AWAITING_CONFIRMATION",
                planner="AWAITING_CONFIRMATION",
                stage="CONFIRM",
                action=None,
                confirmation="pending",
                session_slots={"service_id": PREMIUM_SERVICE},
            ),
            after=_capture_searches,
        ),
        Turn(
            "actually July 11",
            Expect(
                intent="CREATE_APPOINTMENT",
                response_status="success",
                planner="READY",
                stage="AVAILABILITY",
                action="SEARCH_AVAILABILITY",
                session_slots={"service_id": PREMIUM_SERVICE},
                confirmation=None,
                execution="availability",
                has_availability_slots=True,
                date_proposal="2026-07-11",
                slot_absent=["date", "time"],
                availability_invalidated=True,
            ),
            after=_assert_date_revision,
        ),
        tags=["booking", "invalidation"],
    )
)
