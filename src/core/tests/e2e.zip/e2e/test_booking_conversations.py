"""Execute declarative booking conversation scenarios via BookingConversation."""

from __future__ import annotations

import pytest

from core.tests.e2e import test_booking_create_flow as booking_create_flow
from core.tests.e2e.booking_runner import run_bundle
from core.tests.e2e.booking_scenarios import BOOKING_SCENARIOS

# Same Luma reachability gate as the legacy booking create-flow module.
pytestmark = booking_create_flow.pytestmark


@pytest.mark.parametrize(
    "scenario",
    BOOKING_SCENARIOS,
    ids=[s.pytest_id() for s in BOOKING_SCENARIOS],
)
def test_booking_conversation_scenario(scenario, booking_conversation):
    run_bundle(scenario, booking_conversation)
