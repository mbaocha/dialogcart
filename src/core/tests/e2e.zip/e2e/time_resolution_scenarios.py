"""Scripted time-resolution conversation scenarios (definitions only)."""

from __future__ import annotations

from typing import Any, Dict, List

from core.orchestration.time_resolution import TIME_MATCH_EXACT, TIME_MATCH_MISMATCH
from core.tests.e2e.booking_expectations import Expect
from core.tests.e2e.booking_scenario import Scenario
from core.tests.e2e.booking_turn import Turn
from core.tests.e2e.test_booking_create_flow import PREMIUM_SERVICE, _resolve_search_date

TARGET_DATE = _resolve_search_date(None)

TIME_RESOLUTION_SCENARIOS: List[Scenario] = []


def _register(scenario: Scenario) -> Scenario:
    TIME_RESOLUTION_SCENARIOS.append(scenario)
    return scenario


_STATE: Dict[str, Any] = {}


def _assert_no_search_yet(_conv, _booking, availability) -> None:
    assert availability.get_service_availability.call_count == 0


def _assert_exact_search_side_effects(conv, _booking, availability) -> None:
    assert availability.get_service_availability.call_count == 1
    call = availability.get_service_availability.call_args
    assert call.kwargs.get("date") == TARGET_DATE
    conv.assert_availability_search_without_time_constraint(availability)
    sess = conv.session() or {}
    assert isinstance(sess.get("time_proposal"), dict)
    assert isinstance(sess.get("date_proposal"), dict)
    assert sess.get("resolved_datetime_range")
    last = sess.get("last_execution_result") or {}
    assert last.get("type") == "availability"


def _assert_no_booking_single_search(conv, booking, availability) -> None:
    assert not booking.create_booking.called
    assert availability.get_service_availability.call_count == 1


def _capture_search_count(_c, _b, availability) -> None:
    _STATE["searches"] = availability.get_service_availability.call_count


def _assert_mismatch_side_effects(conv, booking, availability) -> None:
    assert availability.get_service_availability.call_count == _STATE.get("searches", 0) + 1
    assert not booking.create_booking.called
    last = (conv.session() or {}).get("last_execution_result") or {}
    assert last.get("type") == "availability"
    assert conv.plan.get("status") != "READY" or conv.plan.get("action") is not None


def _assert_empty_slots(conv, _booking, availability) -> None:
    assert availability.get_service_availability.call_count == 1
    last = (conv.session() or {}).get("last_execution_result") or {}
    assert last.get("slots") == []


def _assert_proposals_persisted(conv, _booking, availability) -> None:
    sess = conv.session() or {}
    assert isinstance(sess.get("time_proposal"), dict)
    assert isinstance(sess.get("date_proposal"), dict)
    assert isinstance(sess.get("last_execution_result"), dict)
    assert availability.get_service_availability.call_count == 1


_register(
    Scenario(
        "Tomorrow by 9am then premium exact match",
        Turn(
            "book haircut tomorrow by 9am",
            Expect(
                response_status="NEEDS_CLARIFICATION",
                intent="CREATE_APPOINTMENT",
                missing_slots=["service_id"],
                date_proposal=TARGET_DATE,
                time_proposal="09",
            ),
            after=_assert_no_search_yet,
        ),
        Turn(
            "premium",
            Expect(
                response_status="success",
                execution="availability",
                has_availability_slots=True,
                time_match=TIME_MATCH_EXACT,
                planner="AWAITING_CONFIRMATION",
                action=None,
                awaiting="USER_CONFIRMATION",
                session_slots={"service_id": PREMIUM_SERVICE},
                response_text_present=True,
                slot_contains={"time": "09"},
            ),
            after=_assert_exact_search_side_effects,
        ),
        fixture="scripted",
        tags=["time-resolution", "exact"],
        id="tomorrow-by-9am-premium-exact",
    )
)


_register(
    Scenario(
        "Time match exact after service selection",
        Turn(
            "book haircut tomorrow at 10am",
            Expect(
                response_status="NEEDS_CLARIFICATION",
                intent="CREATE_APPOINTMENT",
            ),
        ),
        Turn(
            "premium",
            Expect(
                response_status="success",
                time_match=TIME_MATCH_EXACT,
                planner="AWAITING_CONFIRMATION",
                action=None,
                awaiting="USER_CONFIRMATION",
                response_text_present=True,
                confirmation="pending",
                slot_contains={"time": "10"},
            ),
            after=_assert_no_booking_single_search,
        ),
        fixture="scripted",
        tags=["time-resolution", "exact"],
        id="time-match-exact-same-turn",
    )
)


_register(
    Scenario(
        "Time match mismatch conversational response",
        Turn(
            "book haircut tomorrow at 9:15am",
            Expect(response_status="NEEDS_CLARIFICATION"),
            after=_capture_search_count,
        ),
        Turn(
            "premium",
            Expect(
                response_status="success",
                time_match=TIME_MATCH_MISMATCH,
                planner="NEEDS_CLARIFICATION",
                action=None,
                awaiting="TIME_SELECTION",
                response_text_present=True,
                has_availability_slots=True,
                time_proposal="09:15",
            ),
            after=_assert_mismatch_side_effects,
        ),
        fixture="scripted_mismatch",
        tags=["time-resolution", "mismatch"],
        id="time-match-mismatch-conversational",
    )
)


_register(
    Scenario(
        "Empty availability search records no slots",
        Turn("book haircut tomorrow by 9am"),
        Turn(
            "premium",
            Expect(
                response_status="success",
                execution="availability",
                has_availability_slots=False,
                time_match=TIME_MATCH_MISMATCH,
                planner="NEEDS_CLARIFICATION",
                action=None,
                time_proposal="09",
            ),
            after=_assert_empty_slots,
        ),
        fixture="scripted_empty",
        tags=["time-resolution", "empty"],
        id="empty-availability-no-slots",
    )
)


_register(
    Scenario(
        "Mismatch then user picks alternative",
        Turn("book haircut tomorrow at 9:15am"),
        Turn(
            "premium",
            Expect(time_match=TIME_MATCH_MISMATCH),
        ),
        Turn(
            "9:30am",
            Expect(
                response_status="AWAITING_CONFIRMATION",
                planner="AWAITING_CONFIRMATION",
                awaiting="USER_CONFIRMATION",
                action=None,
                confirmation="pending",
                slot_contains={"time": "09:30"},
            ),
            after=_assert_no_booking_single_search,
        ),
        fixture="scripted_mismatch_pick",
        tags=["time-resolution", "mismatch", "bind"],
        id="mismatch-then-pick-alternative",
    )
)


_register(
    Scenario(
        "Time resolution persists proposals on mismatch",
        Turn("book haircut tomorrow at 9:15am"),
        Turn(
            "premium",
            Expect(time_match=TIME_MATCH_MISMATCH),
            after=_assert_proposals_persisted,
        ),
        fixture="scripted_mismatch",
        tags=["time-resolution", "persistence"],
        id="time-resolution-persists-across-turns",
    )
)
