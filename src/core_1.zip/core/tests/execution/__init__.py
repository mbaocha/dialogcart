"""
Tests for execution system.
"""
