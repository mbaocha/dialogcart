"""Tracing framework tests."""
