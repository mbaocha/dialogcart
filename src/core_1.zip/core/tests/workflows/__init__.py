"""
Tests for workflow system.
"""
