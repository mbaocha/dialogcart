"""
Session Merge Helper

Merges session state with Luma response for follow-up handling.

This module provides pure functions for merging session state without
changing core logic.
"""

import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


def merge_luma_with_session(
    luma_response: Dict[str, Any],
    session_state: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Merge Luma response with session state for follow-up handling.
    
    Merge rules (STRICT):
    1. Session intent is immutable - if Luma intent != session intent, session should be reset (handled in orchestrator)
    2. If luma.intent == UNKNOWN: use session.intent (don't modify session intent)
    3. Extract slots from Luma slots dict AND trace.semantic fields
    4. Start with session slots, merge new entities from Luma (do NOT overwrite existing session values)
    5. Update missing_slots after merge (must shrink on follow-up turns)
    
    IMPORTANT: This function assumes luma.intent == UNKNOWN or luma.intent == session.intent.
    Intent mismatch should be handled by resetting session BEFORE calling this function.
    
    Args:
        luma_response: Luma API response (may contain newly extracted entities even if intent=UNKNOWN)
        session_state: Session state from previous turn (status: "NEEDS_CLARIFICATION" or "READY")
        
    Returns:
        Modified Luma response with merged slots and session intent (ready for process_luma_response)
    """
    # Create a copy to avoid mutating the original
    merged = luma_response.copy()
    
    # STEP 1: Handle intent - Session intent is immutable unless session is reset
    # If luma.intent == UNKNOWN: use session.intent (don't modify session intent)
    session_intent = session_state.get("intent")
    session_status = session_state.get("status", "")
    
    # Extract Luma intent
    luma_intent_obj = merged.get("intent", {})
    luma_intent_name = luma_intent_obj.get("name", "") if isinstance(luma_intent_obj, dict) else ""
    
    logger.debug(
        f"merge_luma_with_session: luma_intent={luma_intent_name} "
        f"session_intent={session_intent} session_status={session_status}"
    )
    
    # If session.intent exists and session is not RESOLVED (status != "READY")
    if session_intent and session_status != "READY":
        # If luma.intent == UNKNOWN, use session.intent (session intent is immutable)
        if luma_intent_name == "UNKNOWN":
            # Always use session intent (convert to dict format if string)
            if isinstance(session_intent, str):
                merged["intent"] = {"name": session_intent}
            elif isinstance(session_intent, dict):
                merged["intent"] = session_intent.copy()
            logger.debug(
                f"merge_luma_with_session: Overrode UNKNOWN with session_intent={session_intent}"
            )
        # If luma.intent == session.intent, use session intent (ensures consistency)
        elif luma_intent_name == session_intent or (isinstance(session_intent, dict) and luma_intent_name == session_intent.get("name", "")):
            # Use session intent (convert to dict format if string)
            if isinstance(session_intent, str):
                merged["intent"] = {"name": session_intent}
            elif isinstance(session_intent, dict):
                merged["intent"] = session_intent.copy()
            logger.debug(
                f"merge_luma_with_session: Using session_intent={session_intent} (matches luma)"
            )
    
    # STEP 2: Extract slots from Luma response
    # First, get slots from luma_response.slots (if present)
    luma_slots = merged.get("slots", {}).copy()
    if not isinstance(luma_slots, dict):
        luma_slots = {}
    
    # Extract semantic fields for slot extraction (when slots is empty/partial)
    # Look for semantic data in trace.semantic (not stages.semantic)
    trace = merged.get("trace", {})
    semantic_data = None
    if isinstance(trace, dict):
        semantic_data = trace.get("semantic", {})
    
    # Also try stages.semantic.resolved_booking as fallback
    if not semantic_data:
        stages = merged.get("stages", {})
        if isinstance(stages, dict):
            semantic_stage = stages.get("semantic", {})
            if isinstance(semantic_stage, dict):
                semantic_data = semantic_stage.get("resolved_booking", {})
    
    # Project semantic fields into slots for follow-ups
    # Extract from trace.semantic or stages.semantic.resolved_booking
    if isinstance(semantic_data, dict):
        date_refs = semantic_data.get("date_refs", [])
        date_mode = semantic_data.get("date_mode", "")
        time_constraint = semantic_data.get("time_constraint")
        time_refs = semantic_data.get("time_refs", [])
        date_roles = semantic_data.get("date_roles", [])
        
        # If date_refs exists:
        if date_refs:
            # Check date_roles to determine which slot to fill
            if date_roles:
                if "START_DATE" in date_roles and "start_date" not in luma_slots:
                    if isinstance(date_refs, list) and len(date_refs) > 0:
                        luma_slots["start_date"] = date_refs[0]
                if "END_DATE" in date_roles and "end_date" not in luma_slots:
                    if isinstance(date_refs, list) and len(date_refs) > 1:
                        luma_slots["end_date"] = date_refs[-1]
                    elif isinstance(date_refs, list) and len(date_refs) == 1 and "start_date" in luma_slots:
                        # Single date for range - use same date for end
                        luma_slots["end_date"] = date_refs[0]
            
            # single_day → slots["date"] (for service appointments)
            if date_mode == "single_day" and "date" not in luma_slots and "start_date" not in luma_slots:
                if isinstance(date_refs, list) and len(date_refs) > 0:
                    luma_slots["date"] = date_refs[0]
            # range → slots["date_range"] or start_date/end_date
            elif date_mode == "range":
                if "date_range" not in luma_slots and "start_date" not in luma_slots:
                    if isinstance(date_refs, list):
                        if len(date_refs) >= 2:
                            luma_slots["start_date"] = date_refs[0]
                            luma_slots["end_date"] = date_refs[-1]
                        elif len(date_refs) == 1:
                            # Single date in range mode - use for start_date
                            luma_slots["start_date"] = date_refs[0]
        
        # If time_refs or time_constraint exists → slots["time"]
        if (time_refs or time_constraint) and "time" not in luma_slots:
            if time_constraint:
                luma_slots["time"] = time_constraint
            elif time_refs and isinstance(time_refs, list) and len(time_refs) > 0:
                luma_slots["time"] = time_refs[0]
    
    # STEP 3: Merge slots: Start with session slots, then merge new entities from Luma
    session_slots = session_state.get("slots", {})
    if not isinstance(session_slots, dict):
        session_slots = {}
    
    # Do NOT overwrite existing session values (Luma entities are delta updates)
    merged_slots = session_slots.copy()
    
    # Merge all slots from Luma into session slots (only if not already set)
    for key, value in luma_slots.items():
        if key not in merged_slots:
            # Only add if not already in session (don't overwrite)
            merged_slots[key] = value
    
    # Update merged response with merged slots
    merged["slots"] = merged_slots
    
    # STEP 4: Update missing_slots after merge (must shrink on follow-up turns)
    session_missing = session_state.get("missing_slots", [])
    if not isinstance(session_missing, list):
        session_missing = []
    
    # Get slots that were filled in current request (present in merged_slots but not in session_slots)
    filled_slots = set(merged_slots.keys()) - set(session_slots.keys())
    
    # Map filled slots to missing slot names (e.g., start_date/end_date satisfy date)
    slot_satisfaction_map = {
        "date": ["date"],
        "start_date": ["date", "start_date"],
        "end_date": ["end_date"],
        "time": ["time"],
        "date_range": ["date", "date_range", "start_date", "end_date"]
    }
    
    # Determine which missing slots are satisfied
    satisfied_missing = set()
    for filled_slot in filled_slots:
        if filled_slot in slot_satisfaction_map:
            satisfied_missing.update(slot_satisfaction_map[filled_slot])
        else:
            satisfied_missing.add(filled_slot)
    
    # Remove satisfied slots from session missing_slots (must shrink on follow-up turns)
    new_missing = [slot for slot in session_missing if slot not in satisfied_missing]
    
    # Add any missing slots from current Luma response (if any)
    current_missing = merged.get("missing_slots", [])
    if isinstance(current_missing, list):
        for slot in current_missing:
            if slot not in new_missing:
                new_missing.append(slot)
    
    merged["missing_slots"] = new_missing
    
    # Assertion: session.intent determines planner path exclusively
    # Verify that merged intent matches session intent (when session exists and not reset)
    merged_intent = merged.get("intent", {})
    merged_intent_name = merged_intent.get("name", "") if isinstance(merged_intent, dict) else ""
    if session_intent and session_status != "READY":
        session_intent_str = session_intent if isinstance(session_intent, str) else session_intent.get("name", "")
        assert merged_intent_name == session_intent_str, (
            f"Session intent mismatch: session.intent={session_intent_str}, "
            f"merged.intent={merged_intent_name}. Session intent must determine planner path exclusively."
        )
    
    return merged


# Backward compatibility alias
merge_session_with_luma_response = merge_luma_with_session


def build_session_state_from_outcome(
    outcome: Dict[str, Any],
    outcome_status: str,
    merged_luma_response: Optional[Dict[str, Any]] = None
) -> Optional[Dict[str, Any]]:
    """
    Build session state from outcome and merged Luma response.
    
    Args:
        outcome: Outcome dictionary from handle_message
        outcome_status: Outcome status ("READY" | "NEEDS_CLARIFICATION" | "AWAITING_CONFIRMATION")
        merged_luma_response: Optional merged Luma response (for extracting intent)
        
    Returns:
        Session state dictionary or None if status is READY
    """
    if outcome_status == "READY":
        return None
    
    # Extract facts (contains slots, missing_slots)
    facts = outcome.get("facts", {})
    if not isinstance(facts, dict):
        facts = {}
    
    # Extract slots from facts
    slots = facts.get("slots", {})
    if not isinstance(slots, dict):
        slots = {}
    
    # Extract missing_slots from facts or data.missing
    missing_slots = facts.get("missing_slots", [])
    if not isinstance(missing_slots, list):
        missing_slots = []
    
    # Also check data.missing (clarification outcomes)
    data = outcome.get("data", {})
    if isinstance(data, dict) and "missing" in data:
        data_missing = data.get("missing", [])
        if isinstance(data_missing, list):
            for slot in data_missing:
                if slot not in missing_slots:
                    missing_slots.append(slot)
    
    # Extract intent - prefer from merged Luma response, fallback to outcome
    intent_name = ""
    
    # Try merged Luma response first (most reliable)
    if merged_luma_response:
        intent_obj = merged_luma_response.get("intent", {})
        if isinstance(intent_obj, dict):
            intent_name = intent_obj.get("name", "")
        elif isinstance(intent_obj, str):
            intent_name = intent_obj
    
    # Fallback to outcome intent_name (for non-core intents)
    if not intent_name and "intent_name" in outcome:
        intent_name = outcome.get("intent_name", "")
    
    # Determine status
    status = "NEEDS_CLARIFICATION" if outcome_status in ("NEEDS_CLARIFICATION", "AWAITING_CONFIRMATION") else "READY"
    
    return {
        "intent": intent_name,
        "slots": slots,
        "missing_slots": missing_slots,
        "status": status
    }
