"""
Slot Contract - Required Slots Definition

Defines required slots per intent and computes missing slots.

This is the single source of truth for what slots are required for each intent.
missing_slots are computed fresh from intent + collected slots.
"""

from typing import Dict, List, Set, Any


# Execution-required slots per intent (for execution readiness checks)
# These are checked later, not used for planning missing_slots computation
EXECUTION_REQUIRED_SLOTS_BY_INTENT: Dict[str, List[str]] = {
    "CREATE_APPOINTMENT": ["service_id", "date", "time"],
    "CREATE_RESERVATION": ["service_id", "start_date", "end_date"],
    "MODIFY_BOOKING": ["booking_id"],  # Domain-specific slots added by normalizer
    "CANCEL_BOOKING": ["booking_id"],
}

# Planning-required slots per intent (for missing_slots computation)
# Tests validate PLANNING behavior, not execution readiness
# Planning requires more information than execution for some intents
PLANNING_REQUIRED_SLOTS_BY_INTENT: Dict[str, List[str]] = {
    "CREATE_APPOINTMENT": ["service_id", "date", "time"],
    "CREATE_RESERVATION": ["service_id", "start_date", "end_date"],
    "MODIFY_BOOKING": ["booking_id", "date"],  # Planning requires date for service domain
    "CANCEL_BOOKING": ["booking_id"],
}

# Backward compatibility: REQUIRED_SLOTS_BY_INTENT now refers to planning slots
# (since compute_missing_slots uses planning slots for tests)
REQUIRED_SLOTS_BY_INTENT = PLANNING_REQUIRED_SLOTS_BY_INTENT


def get_required_slots_for_intent(intent_name: str) -> List[str]:
    """
    Get required slots for an intent from the intent contract.
    
    This is the authoritative source for what slots are required.
    
    Args:
        intent_name: Intent name (e.g., "CREATE_APPOINTMENT", "CREATE_RESERVATION")
        
    Returns:
        List of required slot names for the intent
    """
    return REQUIRED_SLOTS_BY_INTENT.get(intent_name, [])


def get_planning_required_slots_for_intent(intent_name: str, collected_slots: Dict[str, Any] = None) -> List[str]:
    """
    Get planning-required slots for an intent.
    
    For MODIFY_BOOKING (service domain):
    - Base planning slots: ["booking_id", "date"]
    - If time is provided, date becomes required (must be in planning slots)
    
    Args:
        intent_name: Intent name (e.g., "CREATE_APPOINTMENT", "MODIFY_BOOKING")
        collected_slots: Optional collected slots to check for conditional requirements
        
    Returns:
        List of planning-required slot names for the intent
    """
    base_planning_slots = PLANNING_REQUIRED_SLOTS_BY_INTENT.get(intent_name, [])
    
    # MODIFY_BOOKING special rule: if time is provided, date becomes required
    if intent_name == "MODIFY_BOOKING" and collected_slots:
        # Check if time is provided
        has_time = "time" in collected_slots and collected_slots.get("time") is not None
        if has_time and "date" not in base_planning_slots:
            # Add date to planning requirements if time is provided
            base_planning_slots = base_planning_slots + ["date"]
    
    return base_planning_slots


def compute_missing_slots(intent_name: str, collected_slots: Dict[str, Any]) -> List[str]:
    """
    Compute missing slots fresh from planning contract and collected slots.
    
    ARCHITECTURAL INVARIANT: missing_slots = PLANNING_REQUIRED_SLOTS(intent) - collected_slots
    This is a pure function with no side effects.
    
    Formula: missing_slots = planning_required_slots - collected_slots
    
    Rules:
    - Uses PLANNING slot contract, not execution contract
    - Tests validate PLANNING behavior, not execution readiness
    - No inference
    - No context-based satisfaction
    - Slot is satisfied ONLY if explicitly present in collected_slots
    
    Special rules:
    - MODIFY_BOOKING: If time is provided, date becomes required
    
    Args:
        intent_name: Intent name (e.g., "CREATE_APPOINTMENT", "MODIFY_BOOKING")
        collected_slots: Dictionary of collected slots (persisted in session)
        
    Returns:
        Sorted list of missing slot names (empty list if all slots satisfied)
    """
    import logging
    logger = logging.getLogger(__name__)
    
    if not intent_name:
        return []
    
    # Use planning-required slots (not execution slots)
    # This ensures tests validate planning behavior, not execution readiness
    required_slots = set(get_planning_required_slots_for_intent(intent_name, collected_slots))
    collected_slot_keys = set(collected_slots.keys()) if collected_slots else set()
    
    # LOG: intent, collected_slots, and computed missing_slots
    logger.info(
        f"[MISSING_SLOTS] compute_missing_slots: "
        f"intent={intent_name}, "
        f"collected_slots={list(collected_slot_keys)}, "
        f"planning_required_slots={list(required_slots)}"
    )
    print(f"[MISSING_SLOTS] compute_missing_slots: intent={intent_name}, collected_slots={list(collected_slot_keys)}, planning_required_slots={list(required_slots)}")
    
    # missing_slots = planning_required_slots - collected_slots
    missing = required_slots - collected_slot_keys
    
    # Sort for consistency
    missing_slots = sorted(missing)
    
    # LOG: computed missing_slots
    logger.info(
        f"[MISSING_SLOTS] compute_missing_slots result: {missing_slots}"
    )
    print(f"[MISSING_SLOTS] compute_missing_slots result: {missing_slots}")
    
    # INVARIANT CHECK: missing_slots must be a list
    assert isinstance(missing_slots, list), (
        f"missing_slots must be a list, got {type(missing_slots)}: {missing_slots}"
    )
    
    return missing_slots


def filter_collected_slots_for_intent(
    collected_slots: Dict[str, Any],
    old_intent: str,
    new_intent: str
) -> Dict[str, Any]:
    """
    Filter collected slots when intent changes.
    
    ARCHITECTURAL INVARIANT: Intent change is a hard boundary
    - On intent change, drop slots that are not valid for the new intent
    - Preserve slots that overlap semantically (e.g., service_id if applicable)
    - Do NOT reuse old slot names (e.g. date/time must NOT leak into reservation)
    - start_date/end_date must NOT satisfy service date implicitly
    - Only keep slots that are in the new intent's slot universe
    
    This function must be STRICT to prevent cross-domain slot leakage.
    
    Args:
        collected_slots: Previously collected slots (effective_slots from session)
        old_intent: Previous intent name
        new_intent: New intent name
        
    Returns:
        Filtered collected slots (only slots valid for new intent)
    """
    import logging
    logger = logging.getLogger(__name__)
    
    if old_intent == new_intent:
        # Same intent - keep all slots
        return collected_slots.copy() if collected_slots else {}
    
    # Intent changed - only keep slots that are valid for new intent
    # CRITICAL: This must be strict to prevent slot leakage
    
    # Define valid slot universe for each intent (STRICT)
    # CREATE_APPOINTMENT: date, time, service_id (and derived has_datetime, date_range)
    # CREATE_RESERVATION: start_date, end_date, service_id, date_range (NOT date, time)
    # MODIFY_BOOKING: booking_id (and domain-specific slots)
    # CANCEL_BOOKING: booking_id
    
    valid_slots_by_intent = {
        "CREATE_APPOINTMENT": {"date", "time", "service_id", "has_datetime", "date_range"},
        "CREATE_RESERVATION": {"start_date", "end_date", "service_id", "date_range"},
        "MODIFY_BOOKING": {"booking_id"},
        "CANCEL_BOOKING": {"booking_id"},
    }
    
    valid_slots_new = valid_slots_by_intent.get(new_intent, set())
    
    # CRITICAL: Strict filtering - only keep slots in valid universe
    # service_id is preserved if it's in the valid slots (it's in both CREATE_APPOINTMENT and CREATE_RESERVATION)
    # date/time from service intent must NOT leak into reservation intent
    # start_date/end_date must NOT satisfy service date implicitly
    
    filtered = {}
    dropped = []
    
    for slot_name, slot_value in (collected_slots or {}).items():
        if slot_name in valid_slots_new:
            # Slot is valid for new intent - preserve it
            filtered[slot_name] = slot_value
        else:
            # Slot is NOT valid for new intent - drop it
            dropped.append(slot_name)
            logger.debug(
                f"[INTENT_CHANGE] Dropping slot '{slot_name}' (not valid for {new_intent}, "
                f"valid_slots={valid_slots_new})"
            )
    
    # Log filtering results
    if dropped:
        logger.info(
            f"[INTENT_CHANGE] filter_collected_slots_for_intent: "
            f"old_intent={old_intent}, new_intent={new_intent}, "
            f"dropped_slots={dropped}, preserved_slots={list(filtered.keys())}"
        )
    
    return filtered


def promote_slots_for_intent(
    raw_slots: Dict[str, Any],
    intent_name: str,
    context: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Promote raw slots to intent-specific slots (in-memory, non-persistent).
    
    ARCHITECTURAL INVARIANT: Promotion must be IDEMPOTENT and ADDITIVE.
    - Promotion starts with ALL existing merged slots (session.slots + luma slots)
    - Promotion may ADD derived slots (e.g., date → start_date)
    - Promotion must NEVER remove or overwrite existing slots
    - Promotion must NOT depend on current-turn presence alone
    - If start_date exists in merged slots, it must remain even if no date_roles appear this turn
    - date_roles may ADD meaning but must not be required to PRESERVE slots
    - Promotion logic must be safe to run repeatedly with no side effects
    
    This runs BEFORE computing missing_slots but is NEVER persisted.
    Promotion rules are intent-scoped and role-aware.
    
    Args:
        raw_slots: Merged slots (session slots + luma slots) - durable facts that must be preserved
        intent_name: Intent name for promotion rules
        context: Context from Luma response (for date_roles, etc.)
        
    Returns:
        Promoted slots dict (raw_slots + promoted slots, non-persistent)
        All input slots are preserved - promotion is additive only
    """
    import logging
    logger = logging.getLogger(__name__)
    
    # CRITICAL: Start with copy of ALL existing merged slots - promotion is additive, never destructive
    # This ensures all session slots are preserved, regardless of current-turn conditions
    promoted = raw_slots.copy() if raw_slots else {}
    
    # LOG: promoted_slots BEFORE promotion
    logger.info(
        f"[PROMOTION] BEFORE promotion: intent={intent_name}, "
        f"input_slots={list(raw_slots.keys()) if raw_slots else []}, "
        f"promoted_slots={list(promoted.keys())}"
    )
    print(
        f"[PROMOTION] BEFORE promotion: intent={intent_name}, "
        f"input_slots={list(raw_slots.keys()) if raw_slots else []}, "
        f"promoted_slots={list(promoted.keys())}"
    )
    
    if intent_name == "CREATE_RESERVATION":
        # Promotion rules for reservations
        date_roles = context.get("date_roles", []) if context else []
        
        # date_range → start_date + end_date (ADD only if both present AND slots don't already exist)
        # CRITICAL: Do NOT overwrite existing start_date/end_date
        date_range = raw_slots.get("date_range")
        if isinstance(date_range, dict):
            range_start = date_range.get("start")
            range_end = date_range.get("end")
            if range_start and range_end:
                # Only ADD if slots don't already exist
                if "start_date" not in promoted:
                    promoted["start_date"] = range_start
                    logger.info(f"[PROMOTION] ADDED start_date from date_range: {range_start}")
                    print(f"[PROMOTION] ADDED start_date from date_range: {range_start}")
                else:
                    logger.debug(
                        f"[PROMOTION] SKIPPED start_date promotion (already exists: {promoted.get('start_date')})"
                    )
                
                if "end_date" not in promoted:
                    promoted["end_date"] = range_end
                    logger.info(f"[PROMOTION] ADDED end_date from date_range: {range_end}")
                    print(f"[PROMOTION] ADDED end_date from date_range: {range_end}")
                else:
                    logger.debug(
                        f"[PROMOTION] SKIPPED end_date promotion (already exists: {promoted.get('end_date')})"
                    )
        
        # date → start_date (ADD only if date_roles explicitly indicates START_DATE AND start_date doesn't exist)
        # CRITICAL: date_roles may ADD meaning but must not be required to PRESERVE slots
        # If start_date already exists, preserve it regardless of date_roles
        if "date" in raw_slots and "START_DATE" in date_roles:
            if "start_date" not in promoted:
                promoted["start_date"] = raw_slots["date"]
                logger.info(
                    f"[PROMOTION] ADDED start_date from date with START_DATE role: {raw_slots['date']}"
                )
                print(
                    f"[PROMOTION] ADDED start_date from date with START_DATE role: {raw_slots['date']}"
                )
            else:
                logger.debug(
                    f"[PROMOTION] SKIPPED start_date promotion (already exists: {promoted.get('start_date')}, "
                    f"date_roles={date_roles})"
                )
        elif "start_date" in promoted:
            # start_date exists but no date_roles this turn - PRESERVE it
            logger.debug(
                f"[PROMOTION] PRESERVED existing start_date: {promoted.get('start_date')} "
                f"(no date_roles this turn, but slot persists)"
            )
        
        # date → end_date (ADD only if date_roles explicitly indicates END_DATE AND end_date doesn't exist)
        if "date" in raw_slots and "END_DATE" in date_roles:
            if "end_date" not in promoted:
                promoted["end_date"] = raw_slots["date"]
                logger.info(
                    f"[PROMOTION] ADDED end_date from date with END_DATE role: {raw_slots['date']}"
                )
                print(
                    f"[PROMOTION] ADDED end_date from date with END_DATE role: {raw_slots['date']}"
                )
            else:
                logger.debug(
                    f"[PROMOTION] SKIPPED end_date promotion (already exists: {promoted.get('end_date')}, "
                    f"date_roles={date_roles})"
                )
        elif "end_date" in promoted:
            # end_date exists but no date_roles this turn - PRESERVE it
            logger.debug(
                f"[PROMOTION] PRESERVED existing end_date: {promoted.get('end_date')} "
                f"(no date_roles this turn, but slot persists)"
            )
    
    elif intent_name == "CREATE_APPOINTMENT":
        # Promotion rules for service appointments
        # date_range → date (ADD only if date not already present)
        # CRITICAL: Do NOT overwrite existing date slot
        if "date_range" in raw_slots and "date" not in promoted:
            # Promote date_range to date (non-persistent view)
            date_range = raw_slots.get("date_range")
            if isinstance(date_range, dict):
                # If date_range is a dict, extract start date
                promoted["date"] = date_range.get("start") or date_range.get("value") or date_range
            else:
                # If date_range is a string or other type, use directly
                promoted["date"] = date_range
            logger.info(f"[PROMOTION] ADDED date from date_range: {promoted['date']}")
            print(f"[PROMOTION] ADDED date from date_range: {promoted['date']}")
        elif "date" in promoted:
            logger.debug(
                f"[PROMOTION] SKIPPED date promotion (already exists: {promoted.get('date')})"
            )
        
        # date + time → has_datetime (for execution readiness)
        # CRITICAL: Only ADD has_datetime if both date and time exist
        # Do NOT overwrite if already exists
        if "has_datetime" not in promoted:
            if ("date" in promoted and "time" in raw_slots) or ("date" in raw_slots and "time" in raw_slots):
                promoted["has_datetime"] = True
                logger.info("[PROMOTION] ADDED has_datetime (date + time present)")
                print("[PROMOTION] ADDED has_datetime (date + time present)")
    
    # LOG: promoted_slots AFTER promotion
    logger.info(
        f"[PROMOTION] AFTER promotion: intent={intent_name}, "
        f"promoted_slots={list(promoted.keys())}"
    )
    print(
        f"[PROMOTION] AFTER promotion: intent={intent_name}, "
        f"promoted_slots={list(promoted.keys())}"
    )
    
    # CRITICAL: Verify all input slots are preserved
    input_slot_keys = set(raw_slots.keys()) if raw_slots else set()
    promoted_slot_keys = set(promoted.keys())
    if input_slot_keys:
        lost_slots = input_slot_keys - promoted_slot_keys
        if lost_slots:
            logger.error(
                f"[PROMOTION] VIOLATION: Slots lost during promotion! "
                f"Lost slots: {list(lost_slots)}, "
                f"input_slots={list(input_slot_keys)}, "
                f"promoted_slots={list(promoted_slot_keys)}"
            )
            # Restore lost slots (fail-safe)
            for key in lost_slots:
                promoted[key] = raw_slots[key]
                logger.warning(f"[PROMOTION] Restored lost slot: {key} = {raw_slots[key]}")
    
    return promoted

