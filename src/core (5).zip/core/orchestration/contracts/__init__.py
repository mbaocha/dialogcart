"""
Contracts Package

Contains contract validation for external service responses.
"""

