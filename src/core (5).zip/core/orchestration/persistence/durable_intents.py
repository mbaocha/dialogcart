"""
Durable Intent Configuration

Defines which intents may be persisted in session state and accumulate slots across turns.
All intents NOT in this list are ephemeral by default.

Design Rules:
- Only intents in DURABLE_INTENTS may:
  - Be persisted in session
  - Accumulate slots across turns
  - Be resumed when Luma returns UNKNOWN
- Any intent not in DURABLE_INTENTS is ephemeral and must NOT be persisted
"""

# Single source of truth for durable intents
DURABLE_INTENTS = {
    "CREATE_APPOINTMENT",
    "CREATE_RESERVATION",
    "SEARCH_AVAILABILITY",
    "CONFIRM_APPOINTMENT",
}

# Slot allow-list per durable intent (conservative first pass)
# Only these slots may be persisted for each intent
DURABLE_SLOTS = {
    "CREATE_APPOINTMENT": {"service_id", "date", "time", "staff_id", "duration"},
    "CREATE_RESERVATION": {"room_id", "check_in", "check_out", "guests"},
    "SEARCH_AVAILABILITY": {"service_id", "date", "time"},
    "CONFIRM_APPOINTMENT": {"service_id", "date", "time", "booking_id"},
}


def is_durable_intent(intent_name: str) -> bool:
    """
    Check if an intent is durable (may be persisted in session).

    Args:
        intent_name: Intent name to check

    Returns:
        True if intent is in DURABLE_INTENTS, False otherwise
    """
    if not intent_name:
        return False
    return intent_name in DURABLE_INTENTS


def filter_slots_for_intent(intent_name: str, slots: dict) -> dict:
    """
    Filter slots to only include those allowed for the given intent.

    Args:
        intent_name: Intent name (must be durable)
        slots: Raw slots dictionary

    Returns:
        Filtered slots dictionary containing only allowed slots
    """
    if not is_durable_intent(intent_name):
        return {}

    allowed_slots = DURABLE_SLOTS.get(intent_name, set())
    if not allowed_slots:
        return {}

    return {k: v for k, v in slots.items() if k in allowed_slots}

