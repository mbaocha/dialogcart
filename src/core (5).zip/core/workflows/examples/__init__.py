"""
Example workflows demonstrating workflow registration and usage.

These are minimal examples to prove the workflow system works.
"""

