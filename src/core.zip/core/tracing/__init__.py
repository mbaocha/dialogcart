"""DialogCart tracing frameworks (invariants and decision trace).

Decision Trace is the completed platform capability for orchestration debugging.
See ``DECISION_TRACE.md`` for architecture, enablement, and engineering standards.
"""

from core.tracing.decision_trace import (
    TRACE_ENV_VAR as DECISION_TRACE_ENV_VAR,
    TRACE_HEADER as DECISION_TRACE_HEADER,
    TRACE_QUERY_PARAM as DECISION_TRACE_QUERY_PARAM,
    Candidate,
    DecisionTraceError,
    FailedPredicate,
    IgnoredInput,
    InvariantAttachment,
    TurnTrace,
    attach_decision_trace_to_result,
    build_decision_trace_for_request,
    clear_request_decision_trace_enabled,
    reset_decision_trace_state,
    decide,
    emit_evidence,
    emit_mutation,
    empty_decision_trace,
    finalize_turn_trace,
    get_last_decision_trace,
    is_decision_trace_enabled,
    set_request_decision_trace_enabled,
    trace_to_dict,
)
from core.tracing.invariant_trace import (
    STAGE_ORDER,
    STAGE_OWNERS,
    TRACE_ENV_VAR,
    InvariantResult,
    StageRecord,
    TurnInvariantTrace,
    TurnTraceSummary,
    attach_trace_to_result,
    finalize_turn_trace as finalize_invariant_turn_trace,
    format_invariant_summary,
    get_last_trace_summary,
    invariant_failure_context,
    is_trace_enabled,
    trace_stage,
)
from core.tracing.formatters import (
    decision_trace_to_mermaid,
    format_decision_failure_context,
    format_decision_summary,
)
from core.tracing.schema_validation import (
    DecisionTraceSchemaError,
    load_decision_trace_schema,
    validate_decision_trace,
)

__all__ = [
    # Invariant trace
    "TRACE_ENV_VAR",
    "STAGE_ORDER",
    "STAGE_OWNERS",
    "InvariantResult",
    "StageRecord",
    "TurnInvariantTrace",
    "TurnTraceSummary",
    "attach_trace_to_result",
    "finalize_invariant_turn_trace",
    "format_invariant_summary",
    "get_last_trace_summary",
    "invariant_failure_context",
    "is_trace_enabled",
    "trace_stage",
    # Decision trace
    "DECISION_TRACE_ENV_VAR",
    "DECISION_TRACE_HEADER",
    "DECISION_TRACE_QUERY_PARAM",
    "Candidate",
    "DecisionTraceError",
    "FailedPredicate",
    "IgnoredInput",
    "InvariantAttachment",
    "TurnTrace",
    "attach_decision_trace_to_result",
    "build_decision_trace_for_request",
    "clear_request_decision_trace_enabled",
    "reset_decision_trace_state",
    "decide",
    "emit_evidence",
    "emit_mutation",
    "empty_decision_trace",
    "finalize_turn_trace",
    "get_last_decision_trace",
    "is_decision_trace_enabled",
    "set_request_decision_trace_enabled",
    "trace_to_dict",
    # Formatters
    "decision_trace_to_mermaid",
    "format_decision_failure_context",
    "format_decision_summary",
    # Schema validation
    "DecisionTraceSchemaError",
    "load_decision_trace_schema",
    "validate_decision_trace",
]
