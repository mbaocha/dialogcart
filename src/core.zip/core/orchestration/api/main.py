"""
FastAPI Main Application

Entry point for running the dialogcart-core API server.
"""

import logging
import sys

from fastapi import FastAPI

from core.orchestration.api import message

# Wire up application logging before uvicorn.run() is called.
# Uvicorn's dictConfig only configures uvicorn.* loggers, so handlers added
# here survive startup.
#
# Two loggers need explicit wiring:
#   core.turn_log  — one structured JSON line per stage (INPUT/LUMA/SESSION_READ/…)
#                    already set to INFO in orchestrator.py; just needs a handler.
#   core.orchestration.api.message — session load/save events; blocked by the
#                    core.orchestration=ERROR override in orchestrator.py so must be
#                    re-enabled and given its own handler here.
_log_handler = logging.StreamHandler(sys.stdout)
_log_handler.setFormatter(
    logging.Formatter("%(asctime)s  %(name)-45s  %(levelname)s  %(message)s")
)

_turn_logger = logging.getLogger("core.turn_log")
_turn_logger.addHandler(_log_handler)
_turn_logger.propagate = False

_api_msg_logger = logging.getLogger("core.orchestration.api.message")
_api_msg_logger.setLevel(logging.INFO)
_api_msg_logger.addHandler(_log_handler)
_api_msg_logger.propagate = False

# Create FastAPI app
app = FastAPI(
    title="Dialogcart Core API",
    description="Stateless orchestration service for dialogcart",
    version="1.0.0",
)

# Include routers
app.include_router(message.router, prefix="/api", tags=["messages"])


@app.get("/health")
async def health():
    """Health check endpoint."""
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
