"""
CREATE_APPOINTMENT conversation journeys through POST /api/message.

Exercises real orchestration (planner, merge, invalidation, execution dispatch).
Only external dependencies are substituted: NLU (Luma), booking backend, availability API.

Requires a running Luma instance (LUMA_BASE_URL, default http://localhost:9001).
"""

from __future__ import annotations

import os
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional
from unittest.mock import Mock

import httpx
import pytest

from core.orchestration.api import message as message_api
from core.orchestration.cache.catalog_cache import catalog_cache
from core.orchestration.execution.clients.availability_client import AvailabilityClient
from core.orchestration.orchestrator import handle_message as real_handle_message
from core.orchestration.session import clear_session, get_session
from core.tests.harness.clients import TestCatalogClient, TestLumaClient
from core.tests.harness.mock_clients import (
    create_mock_booking_client,
    create_mock_organization_client,
)
from core.tests.harness.org_setup import setup_test_org_domain
from core.tests.mocks import reset_booking_counter
from core.tests.e2e.trace_helpers import augment_assertion_message, maybe_print_decision_trace, stash_decision_trace_from_body

os.environ.setdefault("CORE_EXECUTION_MODE", "test")

HAIRCUT_CATALOG = {
    "premium haircut": "haircut",
    "flexi haircut + prunning": "haircut",
}

FROZEN_TIME = datetime(2026, 7, 1, 10, 0, 0, tzinfo=timezone.utc)
ORG_ID = int(os.getenv("ORG_ID", "1"))
PREMIUM_SERVICE = "premium haircut"
FLEXI_SERVICE = "flexi haircut + prunning"


def _luma_reachable() -> bool:
    base = os.getenv("LUMA_BASE_URL", "http://localhost:9001").rstrip("/")
    try:
        with httpx.Client(timeout=3.0) as client:
            for path in ("/health", "/resolve"):
                try:
                    if path == "/health":
                        resp = client.get(f"{base}{path}")
                    else:
                        resp = client.post(
                            f"{base}{path}",
                            json={
                                "user_id": "e2e-probe",
                                "text": "hello",
                                "domain": "service",
                                "timezone": "UTC",
                            },
                        )
                    if resp.status_code < 500:
                        return True
                except httpx.HTTPError:
                    continue
    except Exception:
        pass
    return False


pytestmark = pytest.mark.skipif(
    not _luma_reachable(),
    reason="Luma NLU service is not reachable (set LUMA_BASE_URL or start Luma)",
)


def _resolve_search_date(raw: Optional[str]) -> str:
    if raw and isinstance(raw, str):
        cleaned = raw.split("T")[0].strip()
        if len(cleaned) == 10 and cleaned[4] == "-" and cleaned[7] == "-":
            return cleaned
    return (FROZEN_TIME + timedelta(days=2)).strftime("%Y-%m-%d")


def create_multi_slot_availability_client(
    frozen_time: datetime = FROZEN_TIME,
) -> Mock:
    """Availability with 10:00 and 11:00 slots only (12:00 unavailable)."""
    mock_client = Mock(spec=AvailabilityClient)

    def get_service_availability(**kwargs):
        date = _resolve_search_date(kwargs.get("date"))
        return {
            "slots": [
                {
                    "start": f"{date}T10:00:00Z",
                    "end": f"{date}T10:30:00Z",
                    "available": True,
                },
                {
                    "start": f"{date}T11:00:00Z",
                    "end": f"{date}T11:30:00Z",
                    "available": True,
                },
            ]
        }

    mock_client.get_service_availability.side_effect = get_service_availability
    return mock_client


def create_paginated_availability_client(
    frozen_time: datetime = FROZEN_TIME,
    *,
    slot_hours: tuple[int, ...] = tuple(range(9, 18)),
) -> Mock:
    """Availability with more slots than the default presentation cap (6)."""
    mock_client = Mock(spec=AvailabilityClient)

    def get_service_availability(**kwargs):
        date = _resolve_search_date(kwargs.get("date"))
        return {
            "slots": [
                {
                    "start": f"{date}T{hour:02d}:00:00Z",
                    "end": f"{date}T{hour:02d}:30:00Z",
                    "available": True,
                }
                for hour in slot_hours
            ]
        }

    mock_client.get_service_availability.side_effect = get_service_availability
    return mock_client


def _normalize_slot_start(slot: Dict[str, Any]) -> Optional[str]:
    if not isinstance(slot, dict):
        return None
    start = slot.get("starts_at") or slot.get("start") or slot.get("start_time")
    return str(start) if start else None


def extract_presented_times(
    body: Dict[str, Any],
    session: Optional[Dict[str, Any]],
) -> List[str]:
    """Return normalized start-time keys for the availability page shown to the user."""
    sess = session or {}
    presented = sess.get("presented_availability")
    if isinstance(presented, dict):
        slots = presented.get("slots") or []
        starts = [_normalize_slot_start(s) for s in slots]
        starts = [s for s in starts if s]
        if starts:
            return starts
        times = presented.get("times")
        if isinstance(times, list) and times:
            return [str(t) for t in times]

    execution = _execution_view(body, sess)
    slots = execution.get("slots") or []
    starts = [_normalize_slot_start(s) for s in slots]
    return [s for s in starts if s]


_NO_MORE_TIMES_PHRASES = (
    "no more",
    "no additional",
    "no other",
    "no further",
    "that's all",
    "thats all",
    "all available",
)


def _response_text(body: Dict[str, Any]) -> str:
    outcome = body.get("outcome") or {}
    return str(outcome.get("text") or body.get("text") or "")


def _response_indicates_no_more_times(text: str) -> bool:
    lowered = text.lower()
    return any(phrase in lowered for phrase in _NO_MORE_TIMES_PHRASES)


def assert_different_availability_page(
    first_page: List[str],
    second_page: List[str],
    *,
    response_text: str = "",
    turn: int = 0,
) -> None:
    """
    Pagination contract: never repeat the same page; never repeat prior slots.

    When no further slots exist, the response must say so explicitly.
    """
    if first_page == second_page:
        pytest.fail(
            f"turn {turn}: 'show more' repeated the same availability page "
            f"({first_page!r}); expected a different page or an explicit "
            f"'no more times' indication"
        )

    overlap = set(first_page) & set(second_page)
    if overlap:
        pytest.fail(
            f"turn {turn}: 'show more' repeated previously shown slots: "
            f"{sorted(overlap)!r}"
        )

    if not second_page:
        assert _response_indicates_no_more_times(response_text), (
            f"turn {turn}: no additional slots returned but response did not "
            f"explicitly indicate there are no more available times: "
            f"{response_text!r}"
        )


def assert_no_booking_execution(
    conv: "BookingConversation",
    booking_client: Mock,
) -> None:
    assert not booking_client.create_booking.called, (
        f"turn {conv.turn}: booking should not have been created"
    )
    conv.assert_confirmation(None)
    execution = _execution_view(conv.last_body, conv.session())
    assert execution.get("type") != "booking", (
        f"turn {conv.turn}: unexpected booking execution"
    )


def _plan_view(outcome: Dict[str, Any]) -> Dict[str, Any]:
    nested = outcome.get("plan") if isinstance(outcome.get("plan"), dict) else {}
    return {
        "status": nested.get("status") or outcome.get("status"),
        "stage": nested.get("stage") or outcome.get("stage"),
        "action": nested.get("action") if "action" in nested else outcome.get("action"),
        "awaiting": outcome.get("awaiting") or nested.get("awaiting"),
    }


def _confirmation_state(session: Optional[Dict[str, Any]]) -> Optional[str]:
    if not session:
        return None
    if session.get("confirmation_state"):
        return session.get("confirmation_state")
    booking = session.get("booking")
    if isinstance(booking, dict):
        return booking.get("confirmation_state")
    return None


def _execution_view(body: Dict[str, Any], session: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    outcome = body.get("outcome") or {}
    if outcome.get("type"):
        return outcome
    last = (session or {}).get("last_execution_result")
    return last if isinstance(last, dict) else {}


class BookingConversation:
    """Thin wrapper around POST /api/message for readable multi-turn tests."""

    def __init__(self, api_client, user_id: str, organization_id: int = ORG_ID):
        self.api_client = api_client
        self.user_id = user_id
        self.organization_id = organization_id
        self.last_http = None
        self.last_body: Dict[str, Any] = {}
        self.turn = 0

    def send(self, text: str) -> Dict[str, Any]:
        self.turn += 1
        self.last_http = self.api_client.post(
            "/api/message",
            json={
                "user_id": self.user_id,
                "text": text,
                "organization_id": self.organization_id,
                "domain": "service",
                "timezone": "UTC",
            },
        )
        self.last_body = self.last_http.json()
        stash_decision_trace_from_body(self.last_body)
        maybe_print_decision_trace(self.last_body)
        return self.last_body

    @property
    def outcome(self) -> Dict[str, Any]:
        return self.last_body.get("outcome") or {}

    @property
    def plan(self) -> Dict[str, Any]:
        return _plan_view(self.outcome)

    def session(self) -> Optional[Dict[str, Any]]:
        return get_session(self.user_id)

    def _assert(self, condition: bool, message: str) -> None:
        if not condition:
            raise AssertionError(
                augment_assertion_message(message, body=self.last_body)
            )

    def assert_http_ok(self) -> None:
        self._assert(self.last_http is not None, "no request sent yet")
        self._assert(
            self.last_http is not None and self.last_http.status_code == 200,
            (
                f"turn {self.turn}: expected HTTP 200, got {self.last_http.status_code}: "
                f"{self.last_body}"
            ),
        )
        self._assert(
            self.last_body.get("success") is True,
            f"turn {self.turn}: expected success=True, got {self.last_body}",
        )

    def assert_status(self, response_status: str) -> None:
        actual = self.outcome.get("status")
        self._assert(
            actual == response_status,
            f"turn {self.turn}: response status expected {response_status!r}, got {actual!r}",
        )

    def assert_planner_status(self, planner_status: str) -> None:
        actual = self.plan.get("status")
        self._assert(
            actual == planner_status,
            f"turn {self.turn}: planner status expected {planner_status!r}, got {actual!r}",
        )

    def assert_stage(self, stage: str) -> None:
        actual = self.plan.get("stage")
        self._assert(
            actual == stage,
            f"turn {self.turn}: stage expected {stage!r}, got {actual!r}",
        )

    def assert_awaiting(self, awaiting: str) -> None:
        actual = self.plan.get("awaiting")
        self._assert(
            actual == awaiting,
            f"turn {self.turn}: awaiting expected {awaiting!r}, got {actual!r}",
        )

    def assert_action(self, action: Optional[str]) -> None:
        actual = self.plan.get("action")
        self._assert(
            actual == action,
            f"turn {self.turn}: action expected {action!r}, got {actual!r}",
        )

    def assert_slots(
        self,
        *,
        outcome: Optional[Dict[str, Any]] = None,
        session: Optional[Dict[str, Any]] = None,
    ) -> None:
        if outcome:
            actual = self.outcome.get("slots") or {}
            for key, value in outcome.items():
                self._assert(
                    actual.get(key) == value,
                    (
                        f"turn {self.turn}: outcome slot {key!r} expected {value!r}, "
                        f"got {actual.get(key)!r}"
                    ),
                )
        if session:
            sess = self.session() or {}
            actual = sess.get("slots") or {}
            for key, value in session.items():
                self._assert(
                    actual.get(key) == value,
                    (
                        f"turn {self.turn}: session slot {key!r} expected {value!r}, "
                        f"got {actual.get(key)!r}"
                    ),
                )

    def assert_slot_contains(self, key: str, fragment: str, *, in_session: bool = True) -> None:
        source = (self.session() or {}).get("slots", {}) if in_session else self.outcome.get("slots", {})
        value = str(source.get(key, ""))
        self._assert(
            fragment in value,
            f"turn {self.turn}: expected {key!r} to contain {fragment!r}, got {value!r}",
        )

    def assert_slot_absent(self, key: str) -> None:
        slots = (self.session() or {}).get("slots") or {}
        value = slots.get(key)
        self._assert(
            value in (None, ""),
            f"turn {self.turn}: expected session slot {key!r} to be absent, got {value!r}",
        )

    def assert_date_proposal(self, start: str) -> None:
        sess = self.session() or {}
        proposal = sess.get("date_proposal")
        if not isinstance(proposal, dict):
            facts = sess.get("facts")
            if isinstance(facts, dict):
                proposal = facts.get("date_proposal")
        if not isinstance(proposal, dict):
            proposal = {}
        actual = str(proposal.get("start", "")).split("T")[0].split(" ")[0]
        self._assert(
            actual == start,
            f"turn {self.turn}: date_proposal.start expected {start!r}, got {actual!r}",
        )

    def assert_availability_invalidated(self) -> None:
        """Bound datetime and prior search artifacts should be cleared after revision."""
        sess = self.session() or {}
        self._assert(
            not sess.get("resolved_datetime_range"),
            (
                f"turn {self.turn}: expected resolved_datetime_range cleared, "
                f"got {sess.get('resolved_datetime_range')!r}"
            ),
        )
        self._assert(
            _confirmation_state(sess) is None,
            f"turn {self.turn}: expected confirmation cleared after revision",
        )

    def assert_missing_slots(self, expected: list) -> None:
        sess = self.session() or {}
        actual = sess.get("missing_slots") or self.outcome.get("missing_slots") or []
        self._assert(
            sorted(actual) == sorted(expected),
            f"turn {self.turn}: missing_slots expected {expected}, got {actual}",
        )

    def assert_confirmation(self, state: Optional[str]) -> None:
        actual = _confirmation_state(self.session())
        self._assert(
            actual == state,
            f"turn {self.turn}: confirmation_state expected {state!r}, got {actual!r}",
        )

    def assert_execution(
        self,
        *,
        result_type: Optional[str] = None,
        has_availability_slots: Optional[bool] = None,
    ) -> None:
        execution = _execution_view(self.last_body, self.session())
        if result_type is not None:
            self._assert(
                execution.get("type") == result_type,
                (
                    f"turn {self.turn}: execution type expected {result_type!r}, "
                    f"got {execution.get('type')!r}"
                ),
            )
        if has_availability_slots is True:
            slots = execution.get("slots") or []
            self._assert(
                len(slots) >= 1,
                f"turn {self.turn}: expected availability slots in execution result",
            )
        if has_availability_slots is False:
            slots = execution.get("slots") or []
            self._assert(
                len(slots) == 0,
                f"turn {self.turn}: expected no availability slots, got {len(slots)}",
            )

    def assert_intent(self, intent_name: str) -> None:
        sess = self.session() or {}
        actual = sess.get("intent_name") or self.outcome.get("intent_name")
        self._assert(
            actual == intent_name,
            f"turn {self.turn}: intent expected {intent_name!r}, got {actual!r}",
        )

    def assert_turn(self, **checks: Any) -> None:
        """Run standard per-turn assertions from keyword expectations."""
        self.assert_http_ok()
        if "response_status" in checks:
            self.assert_status(checks["response_status"])
        if "planner_status" in checks:
            self.assert_planner_status(checks["planner_status"])
        if "stage" in checks:
            self.assert_stage(checks["stage"])
        if "awaiting" in checks:
            self.assert_awaiting(checks["awaiting"])
        if "action" in checks:
            self.assert_action(checks["action"])
        if "outcome_slots" in checks:
            self.assert_slots(outcome=checks["outcome_slots"])
        if "session_slots" in checks:
            self.assert_slots(session=checks["session_slots"])
        if "confirmation" in checks:
            self.assert_confirmation(checks["confirmation"])
        if "missing_slots" in checks:
            self.assert_missing_slots(checks["missing_slots"])
        if "intent" in checks:
            self.assert_intent(checks["intent"])
        if checks.get("execution_type"):
            self.assert_execution(result_type=checks["execution_type"])
        if checks.get("has_availability_slots") is not None:
            self.assert_execution(has_availability_slots=checks["has_availability_slots"])
        if checks.get("date_proposal_start"):
            self.assert_date_proposal(checks["date_proposal_start"])
        if checks.get("slot_absent"):
            for key in checks["slot_absent"]:
                self.assert_slot_absent(key)
        if checks.get("availability_invalidated"):
            self.assert_availability_invalidated()


@pytest.fixture
def paginated_booking_conversation(api_client, monkeypatch):
    """Like booking_conversation but with 9-slot paginated availability."""
    user_id = f"e2e-paginate-appt-{uuid.uuid4().hex[:10]}"
    clear_session(user_id)
    reset_booking_counter()

    setup_test_org_domain("service")
    catalog_cache._mem_cache.pop((ORG_ID, "service"), None)

    luma_client = TestLumaClient(test_aliases=HAIRCUT_CATALOG)
    catalog_client = TestCatalogClient(test_aliases=HAIRCUT_CATALOG, domain="service")
    org_client = create_mock_organization_client(business_category_id=1)
    booking_client = create_mock_booking_client()
    availability_client = create_paginated_availability_client()

    monkeypatch.setattr(message_api, "_booking_client", booking_client)
    monkeypatch.setattr(message_api, "_availability_client", availability_client)

    def handle_message_with_test_deps(**kwargs):
        kwargs.setdefault("luma_client", luma_client)
        kwargs.setdefault("organization_client", org_client)
        kwargs.setdefault("catalog_client", catalog_client)
        kwargs.setdefault("frozen_time", FROZEN_TIME)
        return real_handle_message(**kwargs)

    monkeypatch.setattr(message_api, "handle_message", handle_message_with_test_deps)

    conv = BookingConversation(api_client, user_id)
    yield conv, booking_client, availability_client

    clear_session(user_id)


def _presentation_page_index(session: Optional[Dict[str, Any]]) -> int:
    presentation = (session or {}).get("availability_presentation") or {}
    return int(presentation.get("page_index") or 0)


def _response_pagination_page_index(body: Dict[str, Any]) -> Optional[int]:
    outcome = body.get("outcome") or {}
    pagination = (
        body.get("availability_pagination")
        or outcome.get("availability_pagination")
        or {}
    )
    if not isinstance(pagination, dict):
        return None
    page_index = pagination.get("page_index")
    return int(page_index) if page_index is not None else None


def _reach_july_9_availability(conv: BookingConversation) -> List[str]:
    """Book haircut, select premium, revise to July 9; return first page times."""
    conv.send("book haircut")
    conv.assert_turn(
        response_status="NEEDS_CLARIFICATION",
        intent="CREATE_APPOINTMENT",
    )
    conv.send("premium")
    conv.assert_turn(
        response_status="success",
        planner_status="READY",
        stage="AVAILABILITY",
        action="SEARCH_AVAILABILITY",
        session_slots={"service_id": PREMIUM_SERVICE},
        execution_type="availability",
        has_availability_slots=True,
    )
    conv.send("actually July 9")
    conv.assert_turn(
        intent="CREATE_APPOINTMENT",
        response_status="success",
        action="SEARCH_AVAILABILITY",
        execution_type="availability",
        has_availability_slots=True,
        date_proposal_start="2026-07-09",
    )
    first_page = extract_presented_times(conv.last_body, conv.session())
    assert first_page, f"turn {conv.turn}: expected first availability page"
    assert _presentation_page_index(conv.session()) == 0
    return first_page


@pytest.fixture
def booking_conversation(api_client, monkeypatch):
    """API client wired to real orchestration with test doubles for externals only."""
    user_id = f"e2e-create-appt-{uuid.uuid4().hex[:10]}"
    clear_session(user_id)
    reset_booking_counter()

    setup_test_org_domain("service")
    catalog_cache._mem_cache.pop((ORG_ID, "service"), None)

    luma_client = TestLumaClient(test_aliases=HAIRCUT_CATALOG)
    catalog_client = TestCatalogClient(test_aliases=HAIRCUT_CATALOG, domain="service")
    org_client = create_mock_organization_client(business_category_id=1)
    booking_client = create_mock_booking_client()
    availability_client = create_multi_slot_availability_client()

    monkeypatch.setattr(message_api, "_booking_client", booking_client)
    monkeypatch.setattr(message_api, "_availability_client", availability_client)

    def handle_message_with_test_deps(**kwargs):
        kwargs.setdefault("luma_client", luma_client)
        kwargs.setdefault("organization_client", org_client)
        kwargs.setdefault("catalog_client", catalog_client)
        kwargs.setdefault("frozen_time", FROZEN_TIME)
        return real_handle_message(**kwargs)

    monkeypatch.setattr(message_api, "handle_message", handle_message_with_test_deps)

    conv = BookingConversation(api_client, user_id)
    yield conv, booking_client, availability_client

    clear_session(user_id)


def test_happy_path_create_appointment(booking_conversation):
    conv, booking_client, _ = booking_conversation

    # User: book me a haircut
    conv.send("book me a haircut")
    conv.assert_turn(
        response_status="NEEDS_CLARIFICATION",
        planner_status="NEEDS_CLARIFICATION",
        intent="CREATE_APPOINTMENT",
        confirmation=None,
        missing_slots=["date", "service_id", "time"],
    )

    # User: premium
    conv.send("premium")
    conv.assert_turn(
        response_status="success",
        planner_status="READY",
        stage="AVAILABILITY",
        action="SEARCH_AVAILABILITY",
        session_slots={"service_id": PREMIUM_SERVICE},
        confirmation=None,
        execution_type="availability",
        has_availability_slots=True,
    )
    conv.assert_missing_slots(["date", "time"])

    # User: 10am — confirmation requested; no booking execution yet
    conv.send("10am")
    conv.assert_turn(
        response_status="AWAITING_CONFIRMATION",
        planner_status="AWAITING_CONFIRMATION",
        stage="CONFIRM",
        awaiting="USER_CONFIRMATION",
        action=None,
        session_slots={"service_id": PREMIUM_SERVICE},
        confirmation="pending",
    )
    conv.assert_slot_contains("time", "10", in_session=True)
    conv.assert_missing_slots([])
    assert not booking_client.create_booking.called

    # User: yes — booking executes; confirmation cleared
    conv.send("yes")
    conv.assert_turn(
        planner_status="READY",
        stage="CONFIRM",
        action="CONFIRM_APPOINTMENT",
        confirmation=None,
    )
    assert booking_client.create_booking.called
    conv.assert_missing_slots([])
    sess = conv.session() or {}
    assert sess.get("slots", {}).get("service_id") == PREMIUM_SERVICE
    conv.assert_slot_contains("time", "10", in_session=True)
    assert sess.get("slots", {}).get("booking_id") or sess.get("slots", {}).get("booking_code")


def test_reject_then_revise_time(booking_conversation):
    conv, booking_client, _ = booking_conversation

    conv.send("book haircut")
    conv.assert_turn(
        response_status="NEEDS_CLARIFICATION",
        planner_status="NEEDS_CLARIFICATION",
        intent="CREATE_APPOINTMENT",
    )

    conv.send("premium")
    conv.assert_turn(
        response_status="success",
        planner_status="READY",
        stage="AVAILABILITY",
        action="SEARCH_AVAILABILITY",
        session_slots={"service_id": PREMIUM_SERVICE},
        execution_type="availability",
        has_availability_slots=True,
    )

    conv.send("10am")
    conv.assert_turn(
        response_status="AWAITING_CONFIRMATION",
        planner_status="AWAITING_CONFIRMATION",
        stage="CONFIRM",
        awaiting="USER_CONFIRMATION",
        action=None,
        confirmation="pending",
    )
    conv.assert_slot_contains("time", "10", in_session=True)

    # User: no
    conv.send("no")
    conv.assert_turn(
        intent="CREATE_APPOINTMENT",
        confirmation=None,
    )
    assert not booking_client.create_booking.called
    conv.assert_slots(session={"service_id": PREMIUM_SERVICE})
    sess = conv.session() or {}
    assert sess.get("slots", {}).get("date")

    # User: 11am
    conv.send("11am")
    conv.assert_turn(
        response_status="AWAITING_CONFIRMATION",
        planner_status="AWAITING_CONFIRMATION",
        stage="CONFIRM",
        awaiting="USER_CONFIRMATION",
        action=None,
        confirmation="pending",
    )
    conv.assert_slot_contains("time", "11", in_session=True)

    # User: yes
    conv.send("yes")
    conv.assert_turn(action="CONFIRM_APPOINTMENT")
    assert booking_client.create_booking.called
    conv.assert_slot_contains("time", "11", in_session=True)


def test_unavailable_time_keeps_booking_flow(booking_conversation):
    conv, booking_client, availability_client = booking_conversation

    conv.send("book haircut")
    conv.assert_turn(
        response_status="NEEDS_CLARIFICATION",
        intent="CREATE_APPOINTMENT",
    )

    conv.send("premium")
    conv.assert_turn(
        response_status="success",
        planner_status="READY",
        stage="AVAILABILITY",
        action="SEARCH_AVAILABILITY",
        session_slots={"service_id": PREMIUM_SERVICE},
        has_availability_slots=True,
    )
    searches_after_premium = availability_client.get_service_availability.call_count

    # User: 12pm (not in presented 10:00 / 11:00 offers)
    conv.send("12pm")
    conv.assert_turn(intent="CREATE_APPOINTMENT")
    conv.assert_slots(session={"service_id": PREMIUM_SERVICE})
    assert "service_id" not in (conv.session() or {}).get("missing_slots", [])
    assert not booking_client.create_booking.called
    assert availability_client.get_service_availability.call_count >= searches_after_premium
    conv.assert_execution(has_availability_slots=True)


def test_service_revision_invalidates_availability(booking_conversation):
    conv, booking_client, availability_client = booking_conversation

    conv.send("book haircut")
    conv.send("premium")
    conv.send("10am")
    conv.assert_turn(
        response_status="AWAITING_CONFIRMATION",
        confirmation="pending",
        session_slots={"service_id": PREMIUM_SERVICE},
    )

    searches_before = availability_client.get_service_availability.call_count

    # User: rather book flexi haircut
    conv.send("rather book flexi haircut")
    conv.assert_turn(intent="CREATE_APPOINTMENT")
    conv.assert_slots(session={"service_id": FLEXI_SERVICE})
    conv.assert_confirmation(None)
    assert availability_client.get_service_availability.call_count > searches_before
    conv.assert_execution(has_availability_slots=True)
    sess = conv.session() or {}
    time_slot = (sess.get("slots") or {}).get("time")
    assert time_slot in (None, ""), f"expected prior time discarded, got {time_slot!r}"
    assert not booking_client.create_booking.called


def test_date_revision_invalidates_availability(booking_conversation):
    conv, booking_client, availability_client = booking_conversation

    conv.send("book haircut")
    conv.send("premium")
    conv.send("10am")
    conv.assert_turn(
        response_status="AWAITING_CONFIRMATION",
        planner_status="AWAITING_CONFIRMATION",
        stage="CONFIRM",
        action=None,
        confirmation="pending",
        session_slots={"service_id": PREMIUM_SERVICE},
    )

    searches_before = availability_client.get_service_availability.call_count

    # User: actually July 11 — proposal updated; durable date/time cleared; re-search
    conv.send("actually July 11")
    conv.assert_turn(
        intent="CREATE_APPOINTMENT",
        response_status="success",
        planner_status="READY",
        stage="AVAILABILITY",
        action="SEARCH_AVAILABILITY",
        session_slots={"service_id": PREMIUM_SERVICE},
        confirmation=None,
        execution_type="availability",
        has_availability_slots=True,
        date_proposal_start="2026-07-11",
        slot_absent=["date", "time"],
        availability_invalidated=True,
    )
    assert availability_client.get_service_availability.call_count > searches_before
    assert not booking_client.create_booking.called


def test_show_more_times_paginates_existing_availability(paginated_booking_conversation):
    """
    Behavioural contract for availability pagination ("show more times").
    """
    conv, booking_client, availability_client = paginated_booking_conversation
    july_9_first_page = _reach_july_9_availability(conv)
    searches_before_show_more = availability_client.get_service_availability.call_count

    # User: show me additional times — paginate without advancing the booking
    conv.send("show me additional times")
    conv.assert_turn(
        intent="CREATE_APPOINTMENT",
        confirmation=None,
        action=None,
    )
    conv.assert_slots(session={"service_id": PREMIUM_SERVICE})
    conv.assert_date_proposal("2026-07-09")
    assert_no_booking_execution(conv, booking_client)
    assert availability_client.get_service_availability.call_count == searches_before_show_more

    pagination_page = _response_pagination_page_index(conv.last_body)
    assert pagination_page == 1, (
        f"turn {conv.turn}: expected response availability_pagination.page_index=1, "
        f"got {pagination_page!r} body={conv.last_body!r}"
    )

    show_more_page = extract_presented_times(conv.last_body, conv.session())
    assert_different_availability_page(
        july_9_first_page,
        show_more_page,
        response_text=_response_text(conv.last_body),
        turn=conv.turn,
    )
    assert _presentation_page_index(conv.session()) == 1


def test_show_more_at_last_page_says_no_more(paginated_booking_conversation):
    conv, booking_client, availability_client = paginated_booking_conversation
    july_9_first_page = _reach_july_9_availability(conv)

    conv.send("show me additional times")
    second_page = extract_presented_times(conv.last_body, conv.session())
    assert_different_availability_page(
        july_9_first_page,
        second_page,
        turn=conv.turn,
    )
    searches_before = availability_client.get_service_availability.call_count

    conv.send("show more times")
    conv.assert_turn(intent="CREATE_APPOINTMENT", action=None)
    assert_no_booking_execution(conv, booking_client)
    assert availability_client.get_service_availability.call_count == searches_before
    third_page = extract_presented_times(conv.last_body, conv.session())
    assert third_page == second_page, (
        f"turn {conv.turn}: exhausted browse must not repeat the current page"
    )
    pagination = (conv.outcome or {}).get("availability_pagination") or conv.last_body.get(
        "availability_pagination"
    ) or {}
    assert pagination.get("exhausted") is True, (
        f"turn {conv.turn}: expected availability_pagination.exhausted=true, got {pagination!r}"
    )
    assert pagination.get("direction") == "next"
    assert pagination.get("page_index") == 1
    assert _presentation_page_index(conv.session()) == 1
    assert len((conv.session() or {}).get("last_execution_result", {}).get("slots") or []) >= 9
    assert _response_indicates_no_more_times(_response_text(conv.last_body)), (
        f"turn {conv.turn}: expected explicit no-more-times message, got {_response_text(conv.last_body)!r}"
    )


def test_previous_page_returns_earlier_availability(paginated_booking_conversation):
    conv, booking_client, availability_client = paginated_booking_conversation
    first_page = _reach_july_9_availability(conv)

    conv.send("show more times")
    second_page = extract_presented_times(conv.last_body, conv.session())
    assert_different_availability_page(first_page, second_page, turn=conv.turn)
    searches_before = availability_client.get_service_availability.call_count

    conv.send("earlier times")
    conv.assert_turn(intent="CREATE_APPOINTMENT", action=None)
    assert_no_booking_execution(conv, booking_client)
    assert availability_client.get_service_availability.call_count == searches_before
    assert extract_presented_times(conv.last_body, conv.session()) == first_page
    assert _presentation_page_index(conv.session()) == 0


def test_pagination_resets_on_service_change(paginated_booking_conversation):
    conv, booking_client, availability_client = paginated_booking_conversation
    _reach_july_9_availability(conv)
    conv.send("show more times")
    assert _presentation_page_index(conv.session()) == 1

    conv.send("rather book flexi haircut")
    conv.assert_turn(intent="CREATE_APPOINTMENT", action="SEARCH_AVAILABILITY")
    assert _presentation_page_index(conv.session()) == 0
    assert not booking_client.create_booking.called


def test_pagination_resets_on_date_change(paginated_booking_conversation):
    conv, booking_client, availability_client = paginated_booking_conversation
    _reach_july_9_availability(conv)
    conv.send("show more times")
    assert _presentation_page_index(conv.session()) == 1

    conv.send("actually July 11")
    conv.assert_turn(
        intent="CREATE_APPOINTMENT",
        action="SEARCH_AVAILABILITY",
        date_proposal_start="2026-07-11",
    )
    assert _presentation_page_index(conv.session()) == 0
    assert not booking_client.create_booking.called


def test_time_on_page_two_binds_not_page_one_slot(paginated_booking_conversation):
    conv, booking_client, availability_client = paginated_booking_conversation
    first_page = _reach_july_9_availability(conv)
    conv.send("show more times")
    second_page = extract_presented_times(conv.last_body, conv.session())
    assert_different_availability_page(first_page, second_page, turn=conv.turn)

    # 9am is on page 0 only — must not bind while page 1 is presented
    conv.send("9am")
    conv.assert_turn(intent="CREATE_APPOINTMENT")
    assert conv.outcome.get("status") != "AWAITING_CONFIRMATION"
    assert not booking_client.create_booking.called

    # 5pm (17:00) is on page 1 — should bind
    searches_before_5pm = availability_client.get_service_availability.call_count
    full_cache = len((conv.session() or {}).get("last_execution_result", {}).get("slots") or [])
    conv.send("5pm")
    conv.assert_turn(
        response_status="AWAITING_CONFIRMATION",
        stage="CONFIRM",
        awaiting="USER_CONFIRMATION",
        action=None,
        confirmation="pending",
    )
    assert availability_client.get_service_availability.call_count == searches_before_5pm, (
        f"turn {conv.turn}: selecting page-2 time must not call SEARCH_AVAILABILITY"
    )
    sess = conv.session() or {}
    bound = sess.get("resolved_datetime_range") or {}
    assert bound.get("start") == "2026-07-09T17:00:00Z", (
        f"turn {conv.turn}: expected bound start 2026-07-09T17:00:00Z, got {bound!r}"
    )
    assert len(sess.get("last_execution_result", {}).get("slots") or []) == full_cache, (
        f"turn {conv.turn}: last_execution_result must retain full cached availability list"
    )
    conv.assert_slot_contains("time", "17", in_session=True)

