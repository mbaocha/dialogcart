"""
Tests package for dialogcart-core

Tests are organized by layer:
- orchestration/ - Orchestration layer tests
- routing/ - Routing layer tests  
- rendering/ - Rendering layer tests
- integration/ - Integration tests
"""
