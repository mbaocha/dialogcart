"""
Dialogcart Core Application

Legacy wrapper - use orchestrator.handle_message() directly.
This file is kept for backward compatibility.
"""

from core.orchestrator import handle_message

# Re-export for backward compatibility
process_message = handle_message

