"""
Luma HTTP Client

Thin HTTP client for calling Luma /resolve endpoint.
Uses httpx with timeouts; raises UpstreamError on failures.
"""

import os
from typing import Dict, Any, Optional
import httpx

from core.errors import UpstreamError


class LumaClient:
    """HTTP client for Luma service."""
    
    def __init__(self, base_url: Optional[str] = None):
        """
        Initialize Luma client.
        
        Args:
            base_url: Luma service base URL. Defaults to LUMA_BASE_URL env var.
        """
        self.base_url = base_url or os.getenv(
            "LUMA_BASE_URL", 
            "http://localhost:9001"
        )
        # Remove trailing slash if present
        self.base_url = self.base_url.rstrip("/")
    
    def resolve(
        self, 
        user_id: str, 
        text: str, 
        domain: str = "service",
        timezone: str = "UTC"
    ) -> Dict[str, Any]:
        """
        Call Luma /resolve endpoint.
        
        Args:
            user_id: User identifier
            text: User message text
            domain: Domain (default: "service")
            timezone: Timezone (default: "UTC")
            
        Returns:
            Luma response dictionary
            
        Raises:
            UpstreamError: On network failures or HTTP errors
        """
        url = f"{self.base_url}/resolve"
        
        payload = {
            "user_id": user_id,
            "text": text,
            "domain": domain,
            "timezone": timezone
        }
        
        try:
            with httpx.Client(timeout=30.0) as client:
                response = client.post(url, json=payload)
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            raise UpstreamError(
                f"Luma API returned error {e.response.status_code}: {e.response.text}"
            ) from e
        except httpx.RequestError as e:
            raise UpstreamError(
                f"Luma API request failed: {str(e)}"
            ) from e
        except Exception as e:
            raise UpstreamError(
                f"Unexpected error calling Luma API: {str(e)}"
            ) from e

