"""
Cancellation API Client

Outbound client for calling existing cancellation business API.
"""

import os
from typing import Dict, Any, Optional
import httpx

from core.errors import UpstreamError


class CancellationClient:
    """HTTP client for cancellation business API."""
    
    def __init__(self, base_url: Optional[str] = None):
        """
        Initialize cancellation client.
        
        Args:
            base_url: Cancellation API base URL. Defaults to CANCELLATION_API_BASE_URL env var.
        """
        self.base_url = base_url or os.getenv(
            "CANCELLATION_API_BASE_URL",
            "http://localhost:8000"
        )
        self.base_url = self.base_url.rstrip("/")
    
    def cancel(self, user_id: str, booking: Dict[str, Any]) -> Dict[str, Any]:
        """
        Cancel a booking.
        
        Args:
            user_id: User identifier
            booking: Booking payload from Luma
            
        Returns:
            API response JSON
            
        Raises:
            UpstreamError: On network failures or HTTP errors
        """
        url = f"{self.base_url}/booking/cancel"
        
        payload = {
            "user_id": user_id,
            "booking": booking
        }
        
        try:
            with httpx.Client(timeout=30.0) as client:
                response = client.post(url, json=payload)
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            raise UpstreamError(
                f"Cancellation API returned error {e.response.status_code}: {e.response.text}"
            ) from e
        except httpx.RequestError as e:
            raise UpstreamError(
                f"Cancellation API request failed: {str(e)}"
            ) from e
        except Exception as e:
            raise UpstreamError(
                f"Unexpected error calling Cancellation API: {str(e)}"
            ) from e

