"""
Modification API Client

Outbound client for calling existing modification business API.
"""

import os
from typing import Dict, Any, Optional
import httpx

from core.errors import UpstreamError


class ModificationClient:
    """HTTP client for modification business API."""
    
    def __init__(self, base_url: Optional[str] = None):
        """
        Initialize modification client.
        
        Args:
            base_url: Modification API base URL. Defaults to MODIFICATION_API_BASE_URL env var.
        """
        self.base_url = base_url or os.getenv(
            "MODIFICATION_API_BASE_URL",
            "http://localhost:8000"
        )
        self.base_url = self.base_url.rstrip("/")
    
    def modify(self, user_id: str, booking: Dict[str, Any]) -> Dict[str, Any]:
        """
        Modify a booking.
        
        Args:
            user_id: User identifier
            booking: Booking payload from Luma
            
        Returns:
            API response JSON
            
        Raises:
            UpstreamError: On network failures or HTTP errors
        """
        url = f"{self.base_url}/booking/modify"
        
        payload = {
            "user_id": user_id,
            "booking": booking
        }
        
        try:
            with httpx.Client(timeout=30.0) as client:
                response = client.post(url, json=payload)
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            raise UpstreamError(
                f"Modification API returned error {e.response.status_code}: {e.response.text}"
            ) from e
        except httpx.RequestError as e:
            raise UpstreamError(
                f"Modification API request failed: {str(e)}"
            ) from e
        except Exception as e:
            raise UpstreamError(
                f"Unexpected error calling Modification API: {str(e)}"
            ) from e

