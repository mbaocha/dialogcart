"""
Stateless Conversation Orchestrator

Pure stateless function that orchestrates conversation flow.
No persistence, no memory, no NLP logic.
"""

import logging
from typing import Dict, Any, Optional

from core.luma_client import LumaClient
from core.contracts import assert_luma_contract
from core.errors import ContractViolation, UpstreamError, UnsupportedIntentError
from core.router import get_template_key, get_action_name
from core.clients.booking_client import BookingClient
from core.clients.modification_client import ModificationClient
from core.clients.cancellation_client import CancellationClient

logger = logging.getLogger(__name__)


def handle_message(
    user_id: str,
    text: str,
    domain: str = "service",
    timezone: str = "UTC",
    luma_client: Optional[LumaClient] = None,
    booking_client: Optional[BookingClient] = None,
    modification_client: Optional[ModificationClient] = None,
    cancellation_client: Optional[CancellationClient] = None
) -> Dict[str, Any]:
    """
    Handle a user message - stateless orchestration.
    
    Flow:
    1. Call Luma (LumaClient.resolve)
    2. Assert response contract (assert_luma_contract)
    3. If success=false return {success:false, error:...}
    4. If needs_clarification=true return clarification payload with template_key + data
    5. Else (resolved) call outbound business API via BookingClient/ModificationClient/CancellationClient
    6. Return {success:true, outcome:{type:"EXECUTED"|"CLARIFY", ...}}
    
    Args:
        user_id: User identifier
        text: User message text
        domain: Domain (default: "service")
        timezone: Timezone (default: "UTC")
        luma_client: Luma client instance (creates default if None)
        booking_client: Booking client instance (creates default if None)
        modification_client: Modification client instance (creates default if None)
        cancellation_client: Cancellation client instance (creates default if None)
        
    Returns:
        Response dictionary with success and outcome
    """
    # Initialize default clients if not provided
    if luma_client is None:
        luma_client = LumaClient()
    if booking_client is None:
        booking_client = BookingClient()
    if modification_client is None:
        modification_client = ModificationClient()
    if cancellation_client is None:
        cancellation_client = CancellationClient()
    
    # Step 1: Call Luma
    try:
        luma_response = luma_client.resolve(
            user_id=user_id,
            text=text,
            domain=domain,
            timezone=timezone
        )
    except UpstreamError as e:
        logger.error(f"Luma API error for user {user_id}: {str(e)}")
        return {
            "success": False,
            "error": "upstream_error",
            "message": str(e)
        }
    
    # Step 2: Assert contract
    try:
        assert_luma_contract(luma_response)
    except ContractViolation as e:
        logger.error(f"Contract violation for user {user_id}: {str(e)}")
        return {
            "success": False,
            "error": "contract_violation",
            "message": str(e)
        }
    
    # Step 3: If success=false return error
    if not luma_response.get("success", False):
        error_msg = luma_response.get("error", "Unknown error from Luma")
        logger.warning(f"Luma returned success=false for user {user_id}: {error_msg}")
        return {
            "success": False,
            "error": "luma_error",
            "message": error_msg
        }
    
    # Step 4: If needs_clarification=true return clarification payload
    if luma_response.get("needs_clarification", False):
        clarification = luma_response.get("clarification", {})
        reason = clarification.get("reason", "")
        template_key = get_template_key(reason, domain)
        
        logger.info(
            f"Clarification needed for user {user_id}: {reason} -> {template_key}"
        )
        
        return {
            "success": True,
            "outcome": {
                "type": "CLARIFY",
                "template_key": template_key,
                "data": clarification.get("data", {}),
                "booking": luma_response.get("booking")
            }
        }
    
    # Step 5: Else (resolved) call outbound business API
    intent = luma_response.get("intent", {})
    intent_name = intent.get("name", "")
    action_name = get_action_name(intent_name)
    
    if not action_name:
        logger.warning(f"Unsupported intent for user {user_id}: {intent_name}")
        return {
            "success": False,
            "error": "unsupported_intent",
            "message": f"Intent {intent_name} is not supported"
        }
    
    booking = luma_response.get("booking", {})
    
    try:
        if action_name == "booking.create":
            api_response = booking_client.create(user_id, booking)
        elif action_name == "booking.modify":
            api_response = modification_client.modify(user_id, booking)
        elif action_name == "booking.cancel":
            api_response = cancellation_client.cancel(user_id, booking)
        else:
            raise UnsupportedIntentError(f"Action {action_name} not implemented")
        
        logger.info(
            f"Successfully executed {action_name} for user {user_id}"
        )
        
        # Step 6: Return success with EXECUTED outcome
        return {
            "success": True,
            "outcome": {
                "type": "EXECUTED",
                "action": action_name,
                "intent": intent_name,
                "result": api_response
            }
        }
        
    except UpstreamError as e:
        logger.error(f"Business API error for user {user_id} action {action_name}: {str(e)}")
        return {
            "success": False,
            "error": "upstream_error",
            "message": str(e),
            "action": action_name
        }
    except UnsupportedIntentError as e:
        logger.error(f"Unsupported action for user {user_id}: {str(e)}")
        return {
            "success": False,
            "error": "unsupported_action",
            "message": str(e)
        }

