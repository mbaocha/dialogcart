"""
Execution Dispatcher

Minimal execution dispatcher that routes planning results to appropriate execution handlers.
Supports SEARCH_AVAILABILITY, CONFIRM_APPOINTMENT, CONFIRM_RESERVATION, and CONFIRM_CANCELLATION actions.
"""

import logging
import re
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Tuple

logger = logging.getLogger(__name__)

# Default service duration in minutes (used when duration is not available)
DEFAULT_SERVICE_DURATION_MINUTES = 60


def execute(
    plan: Dict[str, Any],
    availability_client: Optional[Any] = None,
    booking_client: Optional[Any] = None
) -> Dict[str, Any]:
    """
    Execute a planning result using injected clients.

    Routes SEARCH_AVAILABILITY, CONFIRM_APPOINTMENT, CONFIRM_RESERVATION, and CONFIRM_CANCELLATION actions.

    Args:
        plan: Planning result from plan_message() containing:
            - action: Action to execute ("SEARCH_AVAILABILITY", "CONFIRM_APPOINTMENT", "CONFIRM_RESERVATION", or "CONFIRM_CANCELLATION")
            - slots: Collected slots dictionary
            - intent_name: Intent name (e.g., "CREATE_APPOINTMENT", "CREATE_RESERVATION", "CANCEL_BOOKING")
            - time_constraint: Optional time constraint (if present)
        availability_client: Injected availability client instance (required for SEARCH_AVAILABILITY)
        booking_client: Injected booking client instance (required for CONFIRM_APPOINTMENT, CONFIRM_RESERVATION, and CONFIRM_CANCELLATION)

    Returns:
        Execution result dictionary with normalized structure:
        - For SEARCH_AVAILABILITY:
          {
              "type": "availability",
              "status": "success",
              "slots": [...]
          }
        - For CONFIRM_APPOINTMENT:
          {
            "status": "EXECUTED",
            "booking": <booking object>,
            "facts": <original facts>
          }
        - For CONFIRM_RESERVATION:
          {
            "status": "EXECUTED",
            "booking": <booking object>,
            "facts": <original facts>
          }
        - For CONFIRM_CANCELLATION:
          {
            "status": "EXECUTED",
            "booking_id": <booking_id>,
            "status": "cancelled",
            "facts": <original facts>
          }

    Raises:
        ValueError: If action is not supported or required slots/clients are missing
        AttributeError: If client doesn't have required methods
    """
    action = plan.get("action")

    # Route based on action
    if action == "SEARCH_AVAILABILITY":
        if not availability_client:
            raise ValueError(
                "availability_client is required for SEARCH_AVAILABILITY action")
        return _execute_search_availability(plan, availability_client)
    elif action == "CONFIRM_APPOINTMENT":
        if not booking_client:
            raise ValueError(
                "booking_client is required for CONFIRM_APPOINTMENT action")
        return _execute_confirm_appointment(plan, booking_client)
    elif action == "CONFIRM_RESERVATION":
        if not booking_client:
            raise ValueError(
                "booking_client is required for CONFIRM_RESERVATION action")
        return _execute_confirm_reservation(plan, booking_client)
    elif action == "CONFIRM_CANCELLATION":
        if not booking_client:
            raise ValueError(
                "booking_client is required for CONFIRM_CANCELLATION action")
        return _execute_confirm_cancellation(plan, booking_client)
    else:
        raise ValueError(
            f"Unsupported action: {action}. Supported actions: SEARCH_AVAILABILITY, CONFIRM_APPOINTMENT, CONFIRM_RESERVATION, CONFIRM_CANCELLATION"
        )


def _execute_search_availability(
    plan: Dict[str, Any],
    availability_client: Any
) -> Dict[str, Any]:
    """
    Execute SEARCH_AVAILABILITY action.

    Args:
        plan: Planning result containing slots, intent_name, time_constraint
        availability_client: Availability client instance

    Returns:
        Normalized availability execution result
    """

    slots = plan.get("slots", {})
    intent_name = plan.get("intent_name", "")
    time_constraint = plan.get("time_constraint")

    # Extract organization_id (required for all availability calls)
    organization_id = slots.get("organization_id")
    if not organization_id:
        raise ValueError(
            "organization_id is required in slots for availability search")

    # Route based on intent to determine service vs reservation
    if intent_name == "CREATE_APPOINTMENT":
        # Service availability search
        return _execute_service_availability(
            organization_id=organization_id,
            slots=slots,
            time_constraint=time_constraint,
            availability_client=availability_client
        )
    elif intent_name == "CREATE_RESERVATION":
        # Reservation availability search
        return _execute_reservation_availability(
            organization_id=organization_id,
            slots=slots,
            time_constraint=time_constraint,
            availability_client=availability_client
        )
    else:
        # Default to service availability for unknown intents
        logger.warning(
            f"Unknown intent '{intent_name}', defaulting to service availability search"
        )
        return _execute_service_availability(
            organization_id=organization_id,
            slots=slots,
            time_constraint=time_constraint,
            availability_client=availability_client
        )


def _execute_confirm_appointment(
    plan: Dict[str, Any],
    booking_client: Any
) -> Dict[str, Any]:
    """
    Execute CONFIRM_APPOINTMENT action.

    Args:
        plan: Planning result containing slots, intent_name, time_constraint
        booking_client: Booking client instance

    Returns:
        Execution result with booking data:
        {
            "status": "EXECUTED",
            "booking": <booking object>,
            "facts": <original facts>
        }
    """
    slots = plan.get("slots", {})
    intent_name = plan.get("intent_name", "")
    time_constraint = plan.get("time_constraint")

    # Extract required fields
    organization_id = slots.get("organization_id")
    if not organization_id:
        raise ValueError(
            "organization_id is required in slots for appointment confirmation")

    service_id = slots.get("service_id")
    if not service_id:
        raise ValueError(
            "service_id is required in slots for appointment confirmation")

    # Extract customer_id (default to 1 if not provided)
    customer_id = slots.get("customer_id", 1)
    if not isinstance(customer_id, int):
        try:
            customer_id = int(customer_id)
        except (ValueError, TypeError):
            customer_id = 1

    # Resolve datetime from date + time strings if needed
    # This handles cases where slots contain raw date/time strings but no datetime_range
    _resolve_datetime_from_slots(slots)

    # Extract start_time and end_time from slots or time_constraint
    start_time, end_time = _extract_datetime_from_slots(slots, time_constraint)
    if not start_time or not end_time:
        raise ValueError(
            "start_time and end_time are required for appointment confirmation. "
            "Provide datetime_range in slots or time_constraint with start/end, "
            "or provide date and time strings for automatic resolution."
        )

    # Extract optional fields
    staff_id = slots.get("staff_id")
    addons = slots.get("addons")

    # Call booking client
    try:
        booking_response = booking_client.create_booking(
            organization_id=organization_id,
            customer_id=customer_id,
            booking_type="service",
            item_id=service_id if isinstance(service_id, int) else int(
                service_id) if str(service_id).isdigit() else 1,
            start_time=start_time,
            end_time=end_time,
            staff_id=staff_id,
            addons=addons
        )
    except AttributeError as e:
        raise AttributeError(
            f"booking_client must have create_booking method: {e}"
        ) from e
    except Exception as e:
        # Surface booking errors as execution failures
        logger.error(f"Booking creation failed: {e}")
        raise ValueError(f"Booking creation failed: {str(e)}") from e

    # Extract booking object from response
    booking = booking_response.get("booking") if isinstance(
        booking_response, dict) else booking_response

    # Build execution result
    # Include original facts (slots) in the result
    facts = {
        "slots": slots,
        "intent_name": intent_name
    }
    if time_constraint:
        facts["time_constraint"] = time_constraint

    return {
        "status": "EXECUTED",
        "booking": booking,
        "facts": facts
    }


def _execute_confirm_reservation(
    plan: Dict[str, Any],
    booking_client: Any
) -> Dict[str, Any]:
    """
    Execute CONFIRM_RESERVATION action.

    Args:
        plan: Planning result containing slots, intent_name, time_constraint
        booking_client: Booking client instance

    Returns:
        Execution result with booking data:
        {
            "status": "EXECUTED",
            "booking": <booking object>,
            "facts": <original facts>
        }
    """
    slots = plan.get("slots", {})
    intent_name = plan.get("intent_name", "")
    time_constraint = plan.get("time_constraint")

    # Extract required fields
    organization_id = slots.get("organization_id")
    if not organization_id:
        raise ValueError(
            "organization_id is required in slots for reservation confirmation")

    service_id = slots.get("service_id")
    if not service_id:
        raise ValueError(
            "service_id is required in slots for reservation confirmation")

    # Extract customer_id (default to 1 if not provided)
    customer_id = slots.get("customer_id", 1)
    if not isinstance(customer_id, int):
        try:
            customer_id = int(customer_id)
        except (ValueError, TypeError):
            customer_id = 1

    # Extract date range (start_date and end_date)
    start_date, end_date = _extract_date_range_from_slots(slots)
    if not start_date or not end_date:
        raise ValueError(
            "start_date and end_date (or date_range) are required in slots "
            "for reservation confirmation. Provide date_range in slots with start/end dates."
        )

    # Convert dates to check_in/check_out datetime strings
    # Use default check-in time (15:00:00) and check-out time (11:00:00)
    # If dates are already datetime strings, preserve the time component
    check_in = _convert_date_to_check_in_datetime(start_date)
    check_out = _convert_date_to_check_out_datetime(end_date)

    # Extract optional fields
    guests = slots.get("guests", 1)
    if not isinstance(guests, int):
        try:
            guests = int(guests)
        except (ValueError, TypeError):
            guests = 1
    extras = slots.get("extras")

    # Call booking client
    try:
        booking_response = booking_client.create_booking(
            organization_id=organization_id,
            customer_id=customer_id,
            booking_type="reservation",
            item_id=service_id if isinstance(service_id, int) else int(
                service_id) if str(service_id).isdigit() else 1,
            check_in=check_in,
            check_out=check_out,
            guests=guests,
            extras=extras
        )
    except AttributeError as e:
        raise AttributeError(
            f"booking_client must have create_booking method: {e}"
        ) from e
    except Exception as e:
        # Surface booking errors as execution failures
        logger.error(f"Reservation booking creation failed: {e}")
        raise ValueError(
            f"Reservation booking creation failed: {str(e)}") from e

    # Extract booking object from response
    booking = booking_response.get("booking") if isinstance(
        booking_response, dict) else booking_response

    # Build execution result
    # Include original facts (slots) in the result
    facts = {
        "slots": slots,
        "intent_name": intent_name
    }
    if time_constraint:
        facts["time_constraint"] = time_constraint

    return {
        "status": "EXECUTED",
        "booking": booking,
        "facts": facts
    }


def _execute_confirm_cancellation(
    plan: Dict[str, Any],
    booking_client: Any
) -> Dict[str, Any]:
    """
    Execute CONFIRM_CANCELLATION action.

    Args:
        plan: Planning result containing slots, intent_name
        booking_client: Booking client instance

    Returns:
        Execution result with cancellation data:
        {
            "status": "EXECUTED",
            "booking_id": <booking_id>,
            "status": "cancelled",
            "facts": <original facts>
        }
    """
    slots = plan.get("slots", {})
    intent_name = plan.get("intent_name", "")

    # Extract required fields
    organization_id = slots.get("organization_id")
    if not organization_id:
        raise ValueError(
            "organization_id is required in slots for cancellation")

    booking_id = slots.get("booking_id")
    if not booking_id:
        raise ValueError(
            "booking_id is required in slots for cancellation")

    # Call booking client
    try:
        cancellation_response = booking_client.cancel_booking(
            organization_id=organization_id,
            booking_id=booking_id
        )
    except AttributeError as e:
        raise AttributeError(
            f"booking_client must have cancel_booking method: {e}"
        ) from e
    except Exception as e:
        # Surface cancellation errors as execution failures
        logger.error(f"Booking cancellation failed: {e}")
        raise ValueError(f"Booking cancellation failed: {str(e)}") from e

    # Extract cancellation data from response
    # Handle both dict response and direct booking_id
    if isinstance(cancellation_response, dict):
        cancelled_booking_id = cancellation_response.get(
            "booking_id") or booking_id
        cancellation_status = cancellation_response.get("status", "cancelled")
    else:
        cancelled_booking_id = booking_id
        cancellation_status = "cancelled"

    # Build execution result
    # Include original facts (slots) in the result
    facts = {
        "slots": slots,
        "intent_name": intent_name
    }

    return {
        "status": "EXECUTED",
        "booking_id": cancelled_booking_id,
        "cancellation": {
            "status": cancellation_status,
            "booking_id": cancelled_booking_id
        },
        "facts": facts
    }


def _convert_date_to_check_in_datetime(date_str: str) -> str:
    """
    Convert a date string to check-in datetime (ISO-8601 with timezone).

    Args:
        date_str: Date string in YYYY-MM-DD format or ISO datetime string

    Returns:
        ISO-8601 datetime string with default check-in time (15:00:00) and UTC timezone
    """
    # Extract date part (handle both date-only and datetime strings)
    date_part = date_str.split("T")[0].split(" ")[0]

    # If already a datetime string with timezone, preserve it
    if "T" in date_str or " " in date_str:
        # Already has time component
        if "+" in date_str or date_str.endswith("Z"):
            # Already has timezone, return as-is
            return date_str
        # Has time but no timezone - add UTC timezone
        if "T" in date_str:
            return f"{date_str}Z" if not date_str.endswith("Z") else date_str
        # Space-separated format - convert to ISO and add timezone
        return f"{date_str}Z" if not date_str.endswith("Z") else date_str

    # Date-only string - add default check-in time: 15:00:00 (3 PM) UTC
    return f"{date_part}T15:00:00Z"


def _convert_date_to_check_out_datetime(date_str: str) -> str:
    """
    Convert a date string to check-out datetime (ISO-8601 with timezone).

    Args:
        date_str: Date string in YYYY-MM-DD format or ISO datetime string

    Returns:
        ISO-8601 datetime string with default check-out time (11:00:00) and UTC timezone
    """
    # Extract date part (handle both date-only and datetime strings)
    date_part = date_str.split("T")[0].split(" ")[0]

    # If already a datetime string with timezone, preserve it
    if "T" in date_str or " " in date_str:
        # Already has time component
        if "+" in date_str or date_str.endswith("Z"):
            # Already has timezone, return as-is
            return date_str
        # Has time but no timezone - add UTC timezone
        if "T" in date_str:
            return f"{date_str}Z" if not date_str.endswith("Z") else date_str
        # Space-separated format - convert to ISO and add timezone
        return f"{date_str}Z" if not date_str.endswith("Z") else date_str

    # Date-only string - add default check-out time: 11:00:00 (11 AM) UTC
    return f"{date_part}T11:00:00Z"


def _resolve_datetime_from_slots(slots: Dict[str, Any]) -> None:
    """
    Resolve date + time strings into datetime_range if needed.

    This function checks if slots contain date and time strings but no datetime_range.
    If so, it resolves them into ISO-8601 datetime strings and populates slots.datetime_range.

    Args:
        slots: Slots dictionary (modified in-place if resolution is needed)
    """
    # Check if datetime_range or start_time/end_time already exist
    if slots.get("datetime_range") or slots.get("start_time") or slots.get("end_time"):
        return  # Already resolved, no need to process

    # Check if we have date and time strings to resolve
    date_str = slots.get("date")
    time_str = slots.get("time")

    if not date_str or not time_str:
        return  # Missing date or time, cannot resolve

    try:
        # Resolve date string to a datetime object
        date_dt = _parse_date_string(str(date_str))
        if not date_dt:
            logger.warning(f"Could not parse date string: {date_str}")
            return

        # Resolve time string to hour and minute
        hour, minute = _parse_time_string(str(time_str))
        if hour is None:
            logger.warning(f"Could not parse time string: {time_str}")
            return

        # Combine date and time
        start_datetime = date_dt.replace(
            hour=hour, minute=minute, second=0, microsecond=0)

        # Get service duration (default to 60 minutes)
        duration_minutes = slots.get(
            "duration_minutes") or slots.get("duration")
        if duration_minutes:
            try:
                duration_minutes = int(duration_minutes)
            except (ValueError, TypeError):
                duration_minutes = DEFAULT_SERVICE_DURATION_MINUTES
        else:
            duration_minutes = DEFAULT_SERVICE_DURATION_MINUTES

        # Calculate end time
        end_datetime = start_datetime + timedelta(minutes=duration_minutes)

        # Format as ISO-8601 strings
        start_time_iso = start_datetime.strftime("%Y-%m-%dT%H:%M:%S")
        end_time_iso = end_datetime.strftime("%Y-%m-%dT%H:%M:%S")

        # Populate datetime_range in slots
        slots["datetime_range"] = {
            "start": start_time_iso,
            "end": end_time_iso
        }

        logger.info(
            f"Resolved datetime from date='{date_str}' time='{time_str}' "
            f"to start={start_time_iso} end={end_time_iso}"
        )
    except Exception as e:
        logger.error(
            f"Failed to resolve datetime from date='{date_str}' time='{time_str}': {e}")
        # Don't raise - let _extract_datetime_from_slots handle the error


def _parse_date_string(date_str: str) -> Optional[datetime]:
    """
    Parse a date string into a datetime object.

    Handles:
    - Relative dates: "tomorrow", "next monday", "next week"
    - Absolute dates: "2026-01-16", "15/12/2025"

    Args:
        date_str: Date string to parse

    Returns:
        Datetime object or None if parsing fails
    """
    date_str_lower = date_str.lower().strip()

    # Handle ISO date format (YYYY-MM-DD)
    iso_date_pattern = r"^\d{4}-\d{2}-\d{2}$"
    if re.match(iso_date_pattern, date_str_lower):
        try:
            return datetime.strptime(date_str_lower, "%Y-%m-%d")
        except ValueError:
            pass

    # Handle relative dates
    now = datetime.now()
    relative_dates = {
        "today": 0,
        "tomorrow": 1,
        "day after tomorrow": 2,
    }

    if date_str_lower in relative_dates:
        offset_days = relative_dates[date_str_lower]
        target_date = now + timedelta(days=offset_days)
        return target_date.replace(hour=0, minute=0, second=0, microsecond=0)

    # Handle "next <weekday>"
    weekday_map = {
        "monday": 0,
        "tuesday": 1,
        "wednesday": 2,
        "thursday": 3,
        "friday": 4,
        "saturday": 5,
        "sunday": 6,
    }

    next_weekday_match = re.search(
        r"next\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)", date_str_lower)
    if next_weekday_match:
        weekday_name = next_weekday_match.group(1)
        target_weekday = weekday_map.get(weekday_name)
        if target_weekday is not None:
            today_weekday = now.weekday()
            days_ahead = (target_weekday - today_weekday) % 7
            if days_ahead == 0:
                days_ahead = 7  # If today is the target weekday, use next week
            target_date = now + timedelta(days=days_ahead)
            return target_date.replace(hour=0, minute=0, second=0, microsecond=0)

    # Handle "next week" (7 days from now)
    if "next week" in date_str_lower:
        target_date = now + timedelta(days=7)
        return target_date.replace(hour=0, minute=0, second=0, microsecond=0)

    # Try parsing as absolute date (DD/MM/YYYY or DD-MM-YYYY)
    date_patterns = [
        (r"^(\d{1,2})/(\d{1,2})/(\d{4})$", "%d/%m/%Y"),
        (r"^(\d{1,2})-(\d{1,2})-(\d{4})$", "%d-%m-%Y"),
        (r"^(\d{4})-(\d{1,2})-(\d{1,2})$", "%Y-%m-%d"),
    ]

    for pattern, fmt in date_patterns:
        match = re.match(pattern, date_str_lower)
        if match:
            try:
                return datetime.strptime(date_str_lower, fmt)
            except ValueError:
                continue

    return None


def _parse_time_string(time_str: str) -> Tuple[Optional[int], int]:
    """
    Parse a time string into hour and minute.

    Handles:
    - 12-hour format: "2pm", "3pm", "10am", "2:30pm"
    - 24-hour format: "14:00", "14:30"

    Args:
        time_str: Time string to parse

    Returns:
        Tuple of (hour, minute) where hour is 0-23, minute is 0-59
        Returns (None, 0) if parsing fails
    """
    time_str_lower = time_str.lower().strip()

    # Remove "at" prefix if present
    time_str_lower = re.sub(r"^at\s+", "", time_str_lower)

    # Handle 12-hour format with am/pm
    am_pm_pattern = r"^(\d{1,2})(?::(\d{2}))?\s*(am|pm)$"
    match = re.match(am_pm_pattern, time_str_lower)
    if match:
        hour = int(match.group(1))
        minute = int(match.group(2)) if match.group(2) else 0
        period = match.group(3)

        # Convert to 24-hour format
        if period == "pm" and hour != 12:
            hour += 12
        elif period == "am" and hour == 12:
            hour = 0

        if 0 <= hour <= 23 and 0 <= minute <= 59:
            return (hour, minute)

    # Handle 24-hour format (HH:MM or HHMM)
    hour_minute_pattern = r"^(\d{1,2})(?::(\d{2}))?$"
    match = re.match(hour_minute_pattern, time_str_lower)
    if match:
        hour = int(match.group(1))
        minute = int(match.group(2)) if match.group(2) else 0

        if 0 <= hour <= 23 and 0 <= minute <= 59:
            return (hour, minute)

    return (None, 0)


def _extract_datetime_from_slots(
    slots: Dict[str, Any],
    time_constraint: Optional[Dict[str, Any]] = None
) -> Tuple[Optional[str], Optional[str]]:
    """
    Extract start_time and end_time from slots or time_constraint.

    Checks multiple possible locations:
    1. slots.datetime_range.start and slots.datetime_range.end
    2. time_constraint.start and time_constraint.end
    3. slots.start_time and slots.end_time

    Returns:
        Tuple of (start_time, end_time) as ISO-8601 datetime strings, or (None, None) if not found
    """
    start_time = None
    end_time = None

    # Check datetime_range in slots
    datetime_range = slots.get("datetime_range")
    if isinstance(datetime_range, dict):
        start_time = datetime_range.get("start")
        end_time = datetime_range.get("end")

    # Fallback to time_constraint if datetime_range not found
    if not start_time or not end_time:
        if isinstance(time_constraint, dict):
            start_time = start_time or time_constraint.get("start")
            end_time = end_time or time_constraint.get("end")

    # Fallback to direct start_time/end_time in slots
    if not start_time:
        start_time = slots.get("start_time")
    if not end_time:
        end_time = slots.get("end_time")

    # Convert to strings if needed
    if start_time:
        start_time = str(start_time)
    if end_time:
        end_time = str(end_time)

    return (start_time, end_time)


def _execute_service_availability(
    organization_id: int,
    slots: Dict[str, Any],
    time_constraint: Optional[Dict[str, Any]],
    availability_client: Any
) -> Dict[str, Any]:
    """
    Execute service availability search.

    Args:
        organization_id: Organization ID
        slots: Slots dictionary (must include service_id and date)
        time_constraint: Optional time constraint
        availability_client: Availability client instance

    Returns:
        Normalized execution result
    """
    # Extract required fields
    service_id = slots.get("service_id")
    if not service_id:
        raise ValueError(
            "service_id is required in slots for service availability search")

    # Extract date (can be date, start_date, or from date_range/datetime_range)
    date = _extract_date_from_slots(slots)
    if not date:
        raise ValueError(
            "date is required in slots for service availability search")

    # Build extra_params from time_constraint if present
    extra_params: Optional[Dict[str, Any]] = None
    if time_constraint:
        extra_params = {"time_constraint": time_constraint}

    # Call availability client
    try:
        response = availability_client.get_service_availability(
            organization_id=organization_id,
            service_id=service_id,
            date=date,
            extra_params=extra_params
        )
    except AttributeError as e:
        raise AttributeError(
            f"availability_client must have get_service_availability method: {e}"
        ) from e

    # Normalize response
    return _normalize_availability_response(response)


def _execute_reservation_availability(
    organization_id: int,
    slots: Dict[str, Any],
    time_constraint: Optional[Dict[str, Any]],
    availability_client: Any
) -> Dict[str, Any]:
    """
    Execute reservation availability search.

    Args:
        organization_id: Organization ID
        slots: Slots dictionary (must include start_date and end_date or date_range)
        time_constraint: Optional time constraint
        availability_client: Availability client instance

    Returns:
        Normalized execution result
    """
    # Extract date range (can be start_date/end_date or date_range)
    start_date, end_date = _extract_date_range_from_slots(slots)
    if not start_date or not end_date:
        raise ValueError(
            "start_date and end_date (or date_range) are required in slots "
            "for reservation availability search"
        )

    # Build extra_params from time_constraint if present
    extra_params: Optional[Dict[str, Any]] = None
    if time_constraint:
        extra_params = {"time_constraint": time_constraint}

    # Call availability client
    try:
        response = availability_client.get_reservation_availability(
            organization_id=organization_id,
            start_date=start_date,
            end_date=end_date,
            extra_params=extra_params
        )
    except AttributeError as e:
        raise AttributeError(
            f"availability_client must have get_reservation_availability method: {e}"
        ) from e

    # Normalize response
    return _normalize_availability_response(response)


def _extract_date_from_slots(slots: Dict[str, Any]) -> Optional[str]:
    """
    Extract date string from slots.

    Checks multiple possible locations:
    1. slots.date
    2. slots.start_date
    3. slots.date_range.start
    4. slots.datetime_range.start (date part)

    Returns:
        Date string in YYYY-MM-DD format, or None if not found
    """
    # Direct date field
    if slots.get("date"):
        return str(slots["date"])

    # start_date field
    if slots.get("start_date"):
        return str(slots["start_date"])

    # date_range.start
    date_range = slots.get("date_range")
    if isinstance(date_range, dict):
        start = date_range.get("start") or date_range.get("start_date")
        if start:
            # Extract date part if it's a datetime string
            date_str = str(start).split("T")[0].split(" ")[0]
            return date_str

    # datetime_range.start (extract date part)
    datetime_range = slots.get("datetime_range")
    if isinstance(datetime_range, dict):
        start = datetime_range.get("start")
        if start:
            # Extract date part if it's a datetime string
            date_str = str(start).split("T")[0].split(" ")[0]
            return date_str

    return None


def _extract_date_range_from_slots(slots: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
    """
    Extract start_date and end_date from slots.

    Checks multiple possible locations:
    1. slots.start_date and slots.end_date
    2. slots.date_range.start and slots.date_range.end
    3. slots.datetime_range.start and slots.datetime_range.end

    Returns:
        Tuple of (start_date, end_date) as strings in YYYY-MM-DD format
    """
    start_date = None
    end_date = None

    # Direct start_date/end_date fields
    if slots.get("start_date"):
        start_date = str(slots["start_date"])
    if slots.get("end_date"):
        end_date = str(slots["end_date"])

    # date_range
    date_range = slots.get("date_range")
    if isinstance(date_range, dict):
        if not start_date:
            start = date_range.get("start") or date_range.get("start_date")
            if start:
                start_date = str(start).split("T")[0].split(" ")[0]
        if not end_date:
            end = date_range.get("end") or date_range.get("end_date")
            if end:
                end_date = str(end).split("T")[0].split(" ")[0]

    # datetime_range
    datetime_range = slots.get("datetime_range")
    if isinstance(datetime_range, dict):
        if not start_date:
            start = datetime_range.get("start")
            if start:
                start_date = str(start).split("T")[0].split(" ")[0]
        if not end_date:
            end = datetime_range.get("end")
            if end:
                end_date = str(end).split("T")[0].split(" ")[0]

    return (start_date, end_date)


def _normalize_availability_response(response: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalize availability client response to standard format.

    Input format (from availability client):
    {
        "slots": [
            {
                "start": "ISO datetime string",
                "end": "ISO datetime string",
                "staff_id": 5,  # optional
                ...  # other fields preserved
            }
        ]
    }

    Output format:
    {
        "type": "availability",
        "status": "success",
        "slots": [
            {
                "starts_at": "ISO datetime string",
                "ends_at": "ISO datetime string"
            }
        ],
        "facts": {
            "availability_resolved": true
        }
    }

    Args:
        response: Raw response from availability client

    Returns:
        Normalized execution result
    """
    if not isinstance(response, dict):
        raise ValueError(
            f"Expected dict response from availability client, got {type(response)}")

    # Extract slots from response
    raw_slots = response.get("slots", [])
    if not isinstance(raw_slots, list):
        raw_slots = []

    # Normalize each slot
    normalized_slots: List[Dict[str, str]] = []
    for slot in raw_slots:
        if not isinstance(slot, dict):
            continue

        # Extract start/end times (handle both "start"/"end" and "starts_at"/"ends_at")
        starts_at = slot.get("starts_at") or slot.get("start")
        ends_at = slot.get("ends_at") or slot.get("end")

        if not starts_at or not ends_at:
            logger.warning(f"Skipping slot missing start/end times: {slot}")
            continue

        normalized_slot = {
            "starts_at": str(starts_at),
            "ends_at": str(ends_at)
        }
        normalized_slots.append(normalized_slot)

    return {
        "type": "availability",
        "status": "success",
        "slots": normalized_slots,
        "facts": {
            "availability_resolved": True
        }
    }
