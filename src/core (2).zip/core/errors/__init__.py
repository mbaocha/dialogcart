"""
Errors Package

Contains custom exceptions for dialogcart-core.
"""

