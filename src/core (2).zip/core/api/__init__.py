"""
FastAPI endpoints for dialogcart-core
"""

