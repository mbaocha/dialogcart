"""
Interactive Integration Test for Orchestrator

Run this script to interactively test booking requests.
No mocks - uses real Luma and business API clients.
"""

import json
import os
import sys
from pathlib import Path

from core.orchestration.orchestrator import handle_message


def check_services():
    """Check if required services are running."""
    import httpx
    
    luma_url = os.getenv("LUMA_BASE_URL", "http://localhost:9001")
    internal_api_url = os.getenv("INTERNAL_API_BASE_URL", "http://localhost:3000")
    
    print("\n" + "="*60)
    print("Service Availability Check")
    print("="*60)
    
    # Check Luma
    try:
        response = httpx.get(f"{luma_url}/health", timeout=2.0)
        if response.status_code == 200:
            print(f"✅ Luma service: {luma_url} - RUNNING")
        else:
            print(f"⚠️  Luma service: {luma_url} - Responded with {response.status_code}")
    except Exception as e:
        print(f"❌ Luma service: {luma_url} - NOT RUNNING")
        print(f"   Error: {str(e)}")
    
    # Check Internal API
    try:
        response = httpx.get(f"{internal_api_url}/health", timeout=2.0)
        if response.status_code == 200:
            print(f"✅ Internal API: {internal_api_url} - RUNNING")
        else:
            print(f"⚠️  Internal API: {internal_api_url} - Responded with {response.status_code}")
    except Exception:
        # Try a different endpoint
        try:
            response = httpx.get(f"{internal_api_url}/api/health", timeout=2.0)
            if response.status_code == 200:
                print(f"✅ Internal API: {internal_api_url} - RUNNING")
            else:
                print(f"❌ Internal API: {internal_api_url} - NOT RUNNING")
                print(f"   (Health check returned {response.status_code})")
        except Exception as e:
            print(f"❌ Internal API: {internal_api_url} - NOT RUNNING")
            print(f"   Error: Connection refused - service not available")
            print(f"   Make sure the booking service is started on port 3000")
    
    print("="*60 + "\n")

# Load environment variables
try:
    from dotenv import load_dotenv
    project_root = Path(__file__).parent.parent.parent
    core_env_file = Path(__file__).parent / ".env"
    env_file = project_root / ".env"
    env_local_file = project_root / ".env.local"

    if env_file.exists():
        load_dotenv(env_file, override=False)
    if core_env_file.exists():
        load_dotenv(core_env_file, override=True)
    if env_local_file.exists():
        load_dotenv(env_local_file, override=True)
except ImportError:
    # Fallback: manually parse .env files
    def load_env_file(env_path: Path, override: bool = False):
        if not env_path.exists():
            return
        try:
            with open(env_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    if '=' in line:
                        key, value = line.split('=', 1)
                        key = key.strip()
                        value = value.strip()
                        if value.startswith('"') and value.endswith('"'):
                            value = value[1:-1]
                        elif value.startswith("'") and value.endswith("'"):
                            value = value[1:-1]
                        if override or key not in os.environ:
                            os.environ[key] = value
        except Exception:
            pass

    project_root = Path(__file__).parent.parent.parent
    core_env_file = Path(__file__).parent / ".env"
    env_file = project_root / ".env"
    env_local_file = project_root / ".env.local"

    if env_file.exists():
        load_env_file(env_file, override=False)
    if core_env_file.exists():
        load_env_file(core_env_file, override=True)
    if env_local_file.exists():
        load_env_file(env_local_file, override=True)


def print_result(result):
    """Pretty print the result."""
    print("\n" + "="*60)
    print("RESULT")
    print("="*60)
    print(json.dumps(result, indent=2))
    print("="*60)
    
    if result.get("success"):
        outcome = result.get("outcome", {})
        outcome_type = outcome.get("type")
        
        if outcome_type == "BOOKING_CREATED":
            print("\n✅ BOOKING CREATED SUCCESSFULLY!")
            print(f"   Booking Code: {outcome.get('booking_code', 'N/A')}")
            print(f"   Status: {outcome.get('status', 'N/A')}")
        elif outcome_type == "BOOKING_CANCELLED":
            print("\n✅ BOOKING CANCELLED SUCCESSFULLY!")
            print(f"   Booking Code: {outcome.get('booking_code', 'N/A')}")
            print(f"   Status: {outcome.get('status', 'N/A')}")
        elif outcome_type == "CLARIFY":
            print("\n❓ CLARIFICATION NEEDED")
            print(f"   Template: {outcome.get('template_key', 'N/A')}")
            print(f"   Reason: {outcome.get('data', {}).get('reason', 'N/A')}")
            if outcome.get('booking'):
                print(f"   Partial Booking: {json.dumps(outcome.get('booking'), indent=6)}")
    else:
        error = result.get("error", "unknown")
        message = result.get("message", "No message")
        print(f"\n❌ ERROR: {error}")
        print(f"   Message: {message}")


def interactive_test():
    """Interactive test loop."""
    print("\n" + "="*60)
    print("Interactive Orchestrator Test")
    print("="*60)
    print("\nEnter booking requests to test the orchestrator.")
    print("Type 'quit' or 'exit' to stop.")
    print("Type 'check' to verify services are running.\n")
    
    # Load customer details from environment (optional)
    phone_number = os.getenv("TEST_CUSTOMER_PHONE")
    email = os.getenv("TEST_CUSTOMER_EMAIL")
    customer_id_str = os.getenv("TEST_CUSTOMER_ID")
    customer_id = int(customer_id_str) if customer_id_str else None
    
    if customer_id or phone_number or email:
        print("Customer Info (from environment):")
        if customer_id:
            print(f"  Customer ID: {customer_id}")
        if phone_number:
            print(f"  Phone: {phone_number}")
        if email:
            print(f"  Email: {email}")
        print()
    
    while True:
        try:
            # Get user input
            user_input = input("Enter booking request (or 'quit' to exit): ").strip()
            
            if not user_input:
                continue
                
            if user_input.lower() in ('quit', 'exit', 'q'):
                print("\nGoodbye!")
                break
            
            if user_input.lower() == 'check':
                check_services()
                continue
            
            # Optional: Get user_id
            user_id = input("User ID (press Enter for default 'test_user'): ").strip()
            if not user_id:
                user_id = "test_user"
            
            # Optional: Get domain
            domain = input("Domain (press Enter for default 'service'): ").strip()
            if not domain:
                domain = "service"
            
            # Optional: Get timezone
            timezone = input("Timezone (press Enter for default 'UTC'): ").strip()
            if not timezone:
                timezone = "UTC"
            
            print(f"\nProcessing: '{user_input}'")
            print(f"User ID: {user_id}, Domain: {domain}, Timezone: {timezone}")
            print("\n[Step 1] Calling Luma service...")
            
            # Call orchestrator
            try:
                result = handle_message(
                    user_id=user_id,
                    text=user_input,
                    domain=domain,
                    timezone=timezone,
                    phone_number=phone_number,
                    email=email,
                    customer_id=customer_id
                )
                
                # Print result
                print_result(result)
                
                # Additional debugging info
                if not result.get("success"):
                    error = result.get("error")
                    if error == "upstream_error":
                        print("\n💡 TROUBLESHOOTING:")
                        print("   The orchestrator successfully called Luma, but failed when")
                        print("   calling the internal booking API.")
                        print("\n   Make sure the internal booking API is running:")
                        print("   - Default URL: http://localhost:3000")
                        print("   - Set INTERNAL_API_BASE_URL env var if different")
                        print("   - Check that the booking service is started")
                    elif error == "luma_error":
                        print("\n💡 TROUBLESHOOTING:")
                        print("   Luma service returned an error.")
                        print("   Make sure Luma service is running:")
                        print("   - Default URL: http://localhost:9001")
                        print("   - Set LUMA_BASE_URL env var if different")
                
            except Exception as e:
                print(f"\n❌ EXCEPTION: {type(e).__name__}: {str(e)}")
                import traceback
                traceback.print_exc()
            
            print("\n")
            
        except KeyboardInterrupt:
            print("\n\nInterrupted. Goodbye!")
            break
        except Exception as e:
            print(f"\n❌ EXCEPTION: {type(e).__name__}: {str(e)}")
            import traceback
            traceback.print_exc()
            print()


def quick_test(text: str, user_id: str = "test_user", domain: str = "service", timezone: str = "UTC"):
    """Quick test with a single request."""
    print(f"\nProcessing: '{text}'")
    print(f"User ID: {user_id}, Domain: {domain}, Timezone: {timezone}")
    print("\n[Step 1] Calling Luma service...")
    
    # Load customer details from environment (optional)
    phone_number = os.getenv("TEST_CUSTOMER_PHONE")
    email = os.getenv("TEST_CUSTOMER_EMAIL")
    customer_id_str = os.getenv("TEST_CUSTOMER_ID")
    customer_id = int(customer_id_str) if customer_id_str else None
    
    try:
        result = handle_message(
            user_id=user_id,
            text=text,
            domain=domain,
            timezone=timezone,
            phone_number=phone_number,
            email=email,
            customer_id=customer_id
        )
        
        print_result(result)
        
        # Additional debugging info
        if not result.get("success"):
            error = result.get("error")
            if error == "upstream_error":
                print("\n💡 TROUBLESHOOTING:")
                print("   The orchestrator successfully called Luma, but failed when")
                print("   calling the internal booking API.")
                print("\n   Make sure the internal booking API is running:")
                print("   - Default URL: http://localhost:3000")
                print("   - Set INTERNAL_API_BASE_URL env var if different")
                print("   - Check that the booking service is started")
            elif error == "luma_error":
                print("\n💡 TROUBLESHOOTING:")
                print("   Luma service returned an error.")
                print("   Make sure Luma service is running:")
                print("   - Default URL: http://localhost:9001")
                print("   - Set LUMA_BASE_URL env var if different")
        
        return result
    except Exception as e:
        print(f"\n❌ EXCEPTION: {type(e).__name__}: {str(e)}")
        import traceback
        traceback.print_exc()
        return None


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Interactive integration test for orchestrator")
    parser.add_argument(
        "--text",
        help="Booking request text (if provided, runs once and exits)")
    parser.add_argument(
        "--user-id",
        default="test_user",
        help="User ID (default: test_user)")
    parser.add_argument(
        "--domain",
        default="service",
        help="Domain (default: service)")
    parser.add_argument(
        "--timezone",
        default="UTC",
        help="Timezone (default: UTC)")
    parser.add_argument(
        "--check-services",
        action="store_true",
        help="Check if required services are running before testing")
    
    args = parser.parse_args()
    
    if args.check_services:
        check_services()
        if not args.text:
            sys.exit(0)
    
    if args.text:
        # Quick test mode
        quick_test(args.text, args.user_id, args.domain, args.timezone)
    else:
        # Interactive mode
        interactive_test()

