"""
NLU API — Flask service serving the `/resolve` contract on port 9002.

Request body (POST /resolve):
    {
        "text": str,                        # user message
        "tenant_context": {
            "aliases": {str: str},          # service alias map
            "booking_mode": "service"|"reservation",
            "booking_id": {                 # optional — booking reference ID format
                "pattern": str,               # full-match regex (default: ^[A-Z]{2,}\\d{3,}$)
                "scan_pattern": str,          # optional text scan regex
                "examples": [str]             # optional Haiku prompt hints only
            }
        },
        "conversation_context": {           # optional — omit for stateless behaviour
            "last_intent": str,             # intent from the previous turn
            "last_search_query": str,       # search_query from the previous turn
            "active_booking_intent": str,     # durable booking session after FAQ detour (optional)
            "turns": [                      # prior turns, max 3 used
                {
                    "user": str,
                    "assistant": str,
                    "intent": str,
                    "search_query": str | null
                }
            ]
        },
        "test_now": str,                    # optional ISO datetime for deterministic tests
        "timezone": str                     # optional, defaults to "UTC"
    }

Response contract (mirrors luma /resolve):
    {
        "intent": {"name": str, "confidence": float},
        "facts": {
            "dates": [],
            "times": [],
            "date_time_pairs": [],
            "service_id": str | null,
            "booking_id": str | null
        },
        "time_constraint": {...} | null,    # only when a time window is present
        "date_constraint": {...} | null,    # only when date mode is flexible
        "search_query": str | null,         # only for RAG intents
        "off_topic_query": str | null,      # only for OFF_TOPIC (canonical question)
        "answerable": bool | null,          # only for OFF_TOPIC (Core digression evidence)
        "answer": str | null,               # only for OFF_TOPIC (brief evidence answer)
        "operation": str | null,            # structured interaction subtype (e.g. browse_next)
        "temporal": {...} | null,           # additive Stage2 canonical temporal (unused by Core yet)
        "turn": {"understanding": "UNDERSTOOD" | "UNRECOGNIZED_INPUT"}
    }

Fields that must NOT appear (luma contract):
    status, missing_slots, issues, clarification_reason, clarification, booking
"""
import logging
import os
from pathlib import Path

from dotenv import load_dotenv

# Load .env from the nlu package directory (dialogcart/src/nlu/.env)
load_dotenv(Path(__file__).parent / ".env")

from flask import Flask, jsonify, request

from .pipeline import NLUPipeline

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger(__name__)

app = Flask(__name__)
_pipeline = NLUPipeline()


@app.route("/resolve", methods=["POST"])
def resolve():
    body = request.get_json(force=True) or {}
    text = body.get("text", "")
    tenant_context = body.get("tenant_context", {})
    test_now = body.get("test_now")
    timezone = body.get("timezone", "UTC")
    conversation_context = body.get("conversation_context") or None

    result = _pipeline.run(
        text, tenant_context, now=test_now, timezone=timezone,
        conversation_context=conversation_context,
    )

    response = {
        "intent": result.intent,
        "facts": result.facts,
    }
    if result.time_constraint is not None:
        response["time_constraint"] = result.time_constraint
    if result.date_constraint is not None:
        response["date_constraint"] = result.date_constraint
    if result.search_query is not None:
        response["search_query"] = result.search_query
    if result.off_topic_query is not None:
        response["off_topic_query"] = result.off_topic_query
    if result.answerable is not None:
        response["answerable"] = result.answerable
    if result.answer is not None:
        response["answer"] = result.answer
    if result.service_candidates:
        response["service_candidates"] = result.service_candidates
    if result.operation is not None:
        response["operation"] = result.operation
    if result.temporal is not None:
        response["temporal"] = result.temporal
    if result.understanding:
        response["turn"] = {"understanding": result.understanding}

    return jsonify(response)


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


def main():
    """Run the Flask development server (canonical NLU service)."""
    port = int(os.getenv("PORT", "9002"))
    logger.info("NLU API starting on http://localhost:%s", port)
    app.run(host="0.0.0.0", port=port)


if __name__ == "__main__":
    main()

